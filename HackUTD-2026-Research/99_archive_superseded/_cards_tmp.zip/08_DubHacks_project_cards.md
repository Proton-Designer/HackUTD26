# DubHacks: project cards (20 projects)

Facts and short paraphrases only; no cross-project analysis. Full records are in the workbook and JSONL.

## DubHacks '26

### Brawlmegle  (DubHacks '26)

- **Prizes:** Chef's Kitchen: 2nd Place [2nd]  (tier: track_winner)
- **Pitch:** Webcam fighting game that scans you into a rigged 3D fighter and lets you box peer-to-peer using body-motion intent detection.
- **Problem / user:** Motion boxing games lack the impact and feel of classic arcade fighters; the team wanted that effect from a camera. / casual gamers with a webcam
- **Domain / idea type:** entertainment_games + creative_media / entertainment_or_game
- **Platforms / hardware / AI:** web / False / vision; generative_media; speech_or_voice; llm_chat
- **Stack:** langs TypeScript; frontend React; Three.js; MediaPipe; backend WebRTC relay on EC2; db ; hosting AWS EC2; AWS GPU
- **Tech/APIs:** MediaPipe (ai_model, core); TRELLIS.2 (ai_model, core); GPT (ai_model, supporting); ElevenLabs (ai_model, supporting); Three.js (framework, core); WebRTC (framework, core); AWS EC2/GPU (cloud, core); Blender (other, supporting)
- **Sponsor APIs:** 
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 14, writeup medium, impact claims False
- **Notes:** Own GPU server runs TRELLIS.2 to make a 3D fighter from a scan in about 40 seconds with a custom Blender auto-rigger; Omegle-style WebRTC matchmaking; ElevenLabs live commentary.
- **Team size:** 4 | **Confidence:** high | unverified: sponsor_apis_used
- **Links:** [Devpost](https://devpost.com/software/brawlmegle)

### Codegraph  (DubHacks '26)

- **Prizes:** Cook Smarter: 2nd Place [2nd]  (tier: track_winner)
- **Pitch:** VS Code extension that graphs a C/C++ codebase, explains nodes with AI, and scores the risk of changing each node.
- **Problem / user:** With more AI-written code, developers lose understanding of large codebases that are hard to navigate, especially beginners. / C/C++ developers and beginners
- **Domain / idea type:** dev_tools + education / dev_tool
- **Platforms / hardware / AI:** other / False / llm_chat; rag_or_search
- **Stack:** langs TypeScript; JavaScript; C; C++; frontend Cytoscape.js; cytoscape-elk; HTML; CSS; backend VS Code extension host; db ; hosting 
- **Tech/APIs:** Cytoscape.js (framework, core); VS Code Language Model API (ai_model, core); GPT-4o / GitHub Copilot Chat (ai_model, core)
- **Sponsor APIs:** 
- **Repo:** public, commits 80 (before/in/after event: 0/80/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 0, writeup medium, impact claims False
- **Notes:** Calls VS Code Language Model API (Copilot Chat or GPT-4o); Ask AI panel highlights and traces affected nodes; change-risk score per node; limited to C/C++ so far.
- **Team size:** 2 | **Confidence:** high | unverified: platforms
- **Links:** [Devpost](https://devpost.com/software/codegraph-1nj2ku) | [GitHub](https://github.com/kx1100/Dubhacks-26)

### Delta  (DubHacks '26)

- **Prizes:** 2nd Place Perceptron: Perception [2nd]  (tier: sponsor_winner)
- **Pitch:** Git-style version control for hardware: an overhead camera logs each bench change as a commit with before/after images and an AI description.
- **Problem / user:** Hardware prototyping has no change history; people lose working states and rely on phone photos and chat messages. / hardware engineers, robotics teams and EE students
- **Domain / idea type:** dev_tools + education / dev_tool
- **Platforms / hardware / AI:** web; hardware / True / vision; llm_chat; rag_or_search
- **Stack:** langs Python; TypeScript; frontend React 19; Vite; Tailwind; shadcn/ui; TanStack Query; backend Python; Supabase Realtime; db Supabase Postgres; Supabase Storage; hosting NVIDIA Jetson Orin Nano
- **Tech/APIs:** Perceptron Mk1.5 (ai_model, core, sponsor); OpenCV (framework, core); NVIDIA Jetson Orin Nano (hardware_part, core); Supabase (database, core); USB webcam (hardware_part, core)
- **Sponsor APIs:** Perceptron | fit: Used Perceptron Mk1.5 with strict JSON schema, low reasoning effort and prior-frame context to identify components and bounding boxes in crops.
- **Repo:** private_or_missing, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live none, screenshots 2, writeup long, impact claims False
- **Notes:** OpenCV pixel pipeline decides if something changed; Perceptron Mk1.5 only names parts; runs on Jetson Orin Nano in a printed enclosure; 61 backend and 12 frontend tests; zero false positives on 100 frames.
- **Team size:** 4 | **Confidence:** high | unverified: repo_clone_failed
- **Links:** [Devpost](https://devpost.com/software/delta-o91du3) | [GitHub](https://github.com/Aditya9246/dh26/tree/final)

### Drone Perceptron Relief System  (DubHacks '26)

- **Prizes:** Winner Community Kitchen: 1st Place [1st]  (tier: track_winner)
- **Pitch:** Semi-automatic disaster-relief drone system: Perceptron model finds people and distance, data lands in TigerData, and an optimizer picks the next drone move.
- **Problem / user:** Disaster drone relief is manual, error-prone under stress and hard to standardize, giving poor emergency response. / disaster response teams
- **Domain / idea type:** safety_security + civic_legal / data_or_analytics
- **Platforms / hardware / AI:** web; other / True / vision; predictive_ml
- **Stack:** langs Python; SQL; HTML; frontend HTML; backend Python; db TigerData; hosting 
- **Tech/APIs:** Perceptron model (ai_model, core, sponsor); TigerData (database, core, sponsor); Drones (telemetry and footage) (hardware_part, core)
- **Sponsor APIs:** Perceptron; TigerData | fit: Used Perceptron's vision model to detect people and distance, and TigerData as the time-series store, in a disaster-response loop.
- **Repo:** public, commits 38 (before/in/after event: 0/37/1), README detailed
- **Demo/writeup:** video True, live none, screenshots 0, writeup short, impact claims True (Says optimization is about 8x faster median response than brute force on benchmarks.)
- **Notes:** Closed loop from drone telemetry to people-detection to 2D map to optimizer; claims about 8x faster median response than brute force on benchmarks; demo video sped up and author asks 0.75x viewing.
- **Team size:** 4 | **Confidence:** high | unverified: has_hardware; platforms; stack_frontend; stack_hosting
- **Links:** [Devpost](https://devpost.com/software/drone-perceptron-relief-system) | [GitHub](https://github.com/ashwin-builds/optimized-drone-search)

### dump  (DubHacks '26)

- **Prizes:** VEYZL: First Place [1st]  (tier: sponsor_winner)
- **Pitch:** Event photo-sharing rooms with no app or account: scan a QR, upload, find yourself by face, search by content, and everything auto-deletes after 24-72 hours.
- **Problem / user:** Collecting everyone's event photos is messy across group chats, AirDrop and shared drives, and finding photos of yourself in hundreds of shots is tedious. / friend groups and event attendees
- **Domain / idea type:** social_community + creative_media / twist_on_known_app
- **Platforms / hardware / AI:** web; bot_or_chat / False / vision; speech_or_voice; rag_or_search; llm_chat; agent_or_tool_use; generative_media
- **Stack:** langs ; frontend Next.js; Tailwind CSS; PWA; backend background worker; Docker Compose; Caddy; db MongoDB; TigerData; Cloudflare R2; hosting Vultr; Cloudflare
- **Tech/APIs:** Perceptron (ai_model, core, sponsor); Photon 2.0 iMessage (telecom, core, sponsor); VEYZL (other, supporting, sponsor); Backboard (ai_model, core, sponsor); InsightFace (ai_model, core); faster-whisper (ai_model, supporting); BiRefNet (ai_model, supporting); MongoDB (database, core, sponsor); TigerData (database, supporting, sponsor); Vultr (cloud, core, sponsor); Cloudflare R2 (cloud, core); Next.js (framework, core)
- **Sponsor APIs:** Perceptron; Photon; VEYZL; Backboard; MongoDB; TigerData; Vultr | fit: Pointed VEYZL audits at its public vision endpoint and reworked refusals, redaction and answer checking based on the findings.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 4, writeup long, impact claims False
- **Notes:** Rooms can be created over iMessage via Photon; VEYZL safety audits were run on the vision endpoint and fed back into fixes; page also lists an MLH Vultr win not in the queue.
- **Team size:** 5 | **Confidence:** high | unverified: n_screenshots; team_size
- **Links:** [Devpost](https://devpost.com/software/dump-imwsvx)

### Formly - the secure, fast form filler  (DubHacks '26)

- **Prizes:** T-Mobile: 1st Place [1st]  (tier: sponsor_winner)
- **Pitch:** A drop-in 'Fill with Formly' button that builds a private data profile from the user's files and accounts and fills any form with per-field source and approval.
- **Problem / user:** Forms repeatedly ask for the same personal details, and browser autofill misses sensitive or document-based fields like SSNs, IDs and VINs. / people filling long forms and businesses hosting them
- **Domain / idea type:** productivity_workplace + safety_security / automation_or_agent
- **Platforms / hardware / AI:** web / False / llm_chat; vision; agent_or_tool_use
- **Stack:** langs TypeScript; JavaScript; frontend Next.js; React; Tailwind CSS; backend Node.js; Next.js API; db SQLite; hosting Docker
- **Tech/APIs:** Gemini API (ai_model, core); Next.js (framework, core); SQLite (database, supporting); Nemotron-Personas-USA (data_source, supporting); T-Mobile synthetic data (data_source, supporting, sponsor); Claude (fallback) (ai_model, token)
- **Sponsor APIs:**  | fit: T-Mobile signup form is one of four demo forms and T-Mobile synthetic data was used for testing; no T-Mobile API used.
- **Repo:** public, commits 114 (before/in/after event: 0/114/0), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 6, writeup long, impact claims True (Reports 107 of 108 field checks correct on its synthetic test set.)
- **Notes:** Short written answers must quote facts that code verifies against the profile; blank fields preferred over guesses; four demo forms styled after T-Mobile, SpaceXAI, Chase and DMV; test set from synthetic personas.
- **Team size:** 3 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/formly-the-secure-fast-form-filler) | [GitHub](https://github.com/salvobonsma/DubHacks2026)

### Kill-Switch  (DubHacks '26)

- **Prizes:** T-Mobile: 3rd Place [3rd]  (tier: sponsor_winner)
- **Pitch:** ESP32 breadboard device that flags risky websites with LEDs and a buzzer using an AI screen check and URL risk score, with a button that texts a caregiver.
- **Problem / user:** Screen-based fraud warnings fail users with cognitive, visual or motor impairments, leaving them exposed to scams. / older or disabled users and their caregivers
- **Domain / idea type:** safety_security + accessibility / hardware_gadget
- **Platforms / hardware / AI:** hardware / True / vision; llm_chat
- **Stack:** langs C; Python; frontend ; backend FreeRTOS; Python; db ; hosting 
- **Tech/APIs:** ESP32 (hardware_part, core); Gemini API (ai_model, core); APIVoid (data_source, core); Twilio (telecom, supporting); FreeRTOS (framework, supporting)
- **Sponsor APIs:**  | fit: Page does not name T-Mobile; uses Twilio for the caregiver text alert.
- **Repo:** public, commits 2 (before/in/after event: 0/2/0), README none
- **Demo/writeup:** video True, live none, screenshots 1, writeup long, impact claims True (Cites $7.7 billion lost to internet fraud by Americans 60+ in 2025.)
- **Notes:** Runs FreeRTOS tasks on an ESP32 that calls APIs over Wi-Fi; Python and C talk over a COM port; built from parts left from university hardware classes; breadboard only.
- **Team size:** 2 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/kill-switch-sb82du) | [GitHub](https://github.com/turboz23/killSwitch)

### KO.rbit  (DubHacks '26)

- **Prizes:** SpaceXAI: 1st Place [1st]  (tier: sponsor_winner)
- **Pitch:** Full-body lightsaber duel using laptop pose tracking and a phone gyro as the blade, plus a 3D explorer of 31,266 real space objects and an AI voice guide.
- **Problem / user:** Wanted a physical living-room saber duel on real planetary terrain with space data that is real, built quickly with AI tools. / gamers and space enthusiasts
- **Domain / idea type:** entertainment_games + education / entertainment_or_game
- **Platforms / hardware / AI:** web; mobile_ios / False / speech_or_voice; vision; generative_media; agent_or_tool_use
- **Stack:** langs TypeScript; JavaScript; Python; frontend React; Vite; React Three Fiber; Three.js; MediaPipe; backend Node.js; Socket.IO; db ; hosting 
- **Tech/APIs:** Grok Voice (ai_model, core, sponsor); Grok Imagine (ai_model, supporting, sponsor); Grok text-to-speech (ai_model, supporting, sponsor); Perceptron Mk1.5 (ai_model, core, sponsor); MediaPipe Pose (ai_model, core); Three.js (framework, core); NASA/JPL/CelesTrak/HYG data (data_source, core); Cursor (other, supporting)
- **Sponsor APIs:** Grok Voice; Grok Imagine; Grok TTS; Perceptron | fit: Used Grok Voice for the live LYRA guide, Grok Imagine for her look, and Grok agents for research and design; Perceptron also powers replays.
- **Repo:** public, commits 175 (before/in/after event: 0/164/11), README detailed
- **Demo/writeup:** video True, live none, screenshots 9, writeup long, impact claims False
- **Notes:** Server is authoritative for hits and stamina; Mars arena uses NASA MOLA heightmap; opt-in Perceptron KO replay recut; writeup details an AI agent crew used for research, sound and audits.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots; team_size
- **Links:** [Devpost](https://devpost.com/software/space-battles-aei3wz) | [GitHub](https://github.com/alnnguyen/Dubhacks26)

### Lapse  (DubHacks '26)

- **Prizes:** Visa: Reimagine Shopping [n/a]; SideShift: 3rd Place [3rd]  (tier: sponsor_winner)
- **Pitch:** Browser extension that collects rewards from a dedicated inbox and uses a constraint solver to stack coupons, memberships and card cashback at checkout.
- **Problem / user:** Shoppers collect loyalty rewards and coupons but forget or misuse them, losing savings. / online shoppers and merchants running loyalty programs
- **Domain / idea type:** retail_consumer + fintech_finance / twist_on_known_app
- **Platforms / hardware / AI:** browser_extension; web / False / predictive_ml; recommendation; rag_or_search
- **Stack:** langs Python; TypeScript; frontend React; WXT; Chrome extension; backend FastAPI; Pydantic; Postmark; db PostgreSQL; pgvector; pgcrypto; hosting Docker
- **Tech/APIs:** Google OR-Tools CP-SAT (framework, core); SetFit (ai_model, core); GLiNER (ai_model, supporting); Presidio (framework, supporting); pgvector (database, supporting); Postmark (other, supporting)
- **Sponsor APIs:**  | fit: Framed around Visa's loyalty-rewards statistics and card-benefit stacking for the shopping track; no Visa API listed.
- **Repo:** public, commits 54 (before/in/after event: 0/53/1), README detailed
- **Demo/writeup:** video True, live none, screenshots 7, writeup long, impact claims True (Cites Visa figures of 17.4 memberships held vs 8.8 used and up to $10 billion missed annually; labels benefits as potential, not measured.)
- **Notes:** OR-Tools CP-SAT stacking with 200ms budget and greedy fallback; locally trained SetFit email classifier plus JSON-LD, regex and GLiNER extraction; encrypted reward codes; claims no outside service calls.
- **Team size:** 4 | **Confidence:** high | unverified: sponsor_apis_used
- **Links:** [Devpost](https://devpost.com/software/vouch-ld4voh) | [GitHub](https://github.com/asyaafv/DubHacks26)

### Noxen  (DubHacks '26)

- **Prizes:** SideShift: 2nd Place [2nd]; DubHacks Next: 1st Place [1st]  (tier: sponsor_winner)
- **Pitch:** Autonomous nightly facility inspection: LiDAR scans diffed against a baseline, a vision-language model triages changes, and a camera-only drone is dispatched by text.
- **Problem / user:** Facility and construction inspections are manual, costly and infrequent, so small defects go unnoticed between visits. / facility operators and construction managers
- **Domain / idea type:** safety_security + productivity_workplace / hardware_gadget
- **Platforms / hardware / AI:** web; hardware; bot_or_chat / True / vision; agent_or_tool_use; predictive_ml
- **Stack:** langs Python; TypeScript; frontend React; Vite; backend FastAPI; ROS 2; WebSockets; db SQLite; hosting Raspberry Pi
- **Tech/APIs:** Perceptron vision-language model (ai_model, core, sponsor); Photon messaging agent (telecom, core, sponsor); Unitree L2 LiDAR (hardware_part, core); Open3D (framework, core); Depth Anything V2 (ai_model, core); YOLO (ai_model, supporting); ROS 2 (framework, core); OpenAI (ai_model, unclear)
- **Sponsor APIs:** Perceptron; Photon | fit: Used Perceptron's vision-language model to triage before/after changes and a Photon agent to text alerts and dispatch the drone; page also ties itself to the Cook Smarter theme.
- **Repo:** public, commits 1 (before/in/after event: 0/1/0), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 0, writeup long, impact claims False (States customer calls with construction directors and a planned paid pilot, no numeric market claims.)
- **Notes:** Scout drone localizes in a LiDAR-built map using only its camera; monocular depth scaled via the map; hot-swap battery mechanism; change detection tuned to measured 2 cm sensor noise; SMS dispatch via Photon.
- **Team size:** 2 | **Confidence:** high | unverified: team_size
- **Links:** [Devpost](https://devpost.com/software/noxen) | [GitHub](https://github.com/RonRastorguev/noxendh)

### Octaby  (DubHacks '26)

- **Prizes:** SideShift: 1st Place [1st]  (tier: sponsor_winner)
- **Pitch:** Fabric wristband with four haptic motors that cues blind and low-vision users which direction to move their hand to reach an object.
- **Problem / user:** Assistive tools focus on navigation, with few helping blind users locate and reach small objects such as items on a table. / blind and low-vision users
- **Domain / idea type:** accessibility + health_wellness / hardware_gadget
- **Platforms / hardware / AI:** hardware; mobile_ios / True / vision; speech_or_voice; agent_or_tool_use
- **Stack:** langs Swift; Python; frontend iOS app; ARKit; backend Uvicorn; db ; hosting 
- **Tech/APIs:** Perceptron (ai_model, core, sponsor); ARKit / LiDAR (hardware_part, core); OpenAI (ai_model, unclear); Haptic vibration motors with Arduino (hardware_part, core)
- **Sponsor APIs:** Perceptron | fit: No explicit SideShift tie; the page describes a working assistive-wearable prototype built end to end in a day.
- **Repo:** public, commits 120 (before/in/after event: 14/106/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 9, writeup medium, impact claims False
- **Notes:** Pivoted a few hours in from a 3D-printed servo bracelet to a sewn fabric band with conductive thread and Arduino; audio goes to Perceptron to produce guidance; ARKit/LiDAR iOS side; stores remembered objects.
- **Team size:** 4 | **Confidence:** high | unverified: tech_items.is_sponsor; sponsor_fit_note; stack_backend
- **Links:** [Devpost](https://devpost.com/software/octaby) | [GitHub](https://github.com/Eddwal/haptic-reach-demo)

### OpenCanopy  (DubHacks '26)

- **Prizes:** DubHacks Next: 2nd Place [2nd]; 1st Place Perceptron: Perception [1st]  (tier: sponsor_winner)
- **Pitch:** One-click satellite check of a land plot for post-2020 deforestation, combining loss maps with a vision model and producing a printable case file.
- **Problem / user:** EU deforestation rules need per-plot verification, but checking requires GIS expertise and multiple datasets, so approvals rely on self-declared claims. / EU regulators, importers and forest-adjacent communities
- **Domain / idea type:** sustainability_climate + civic_legal / data_or_analytics
- **Platforms / hardware / AI:** web / False / vision
- **Stack:** langs Python; JavaScript; HTML; CSS; frontend MapLibre GL; HTML/CSS/JS; backend Python server; rasterio; shapely; NumPy; db ; hosting Slurm (UW Hyak)
- **Tech/APIs:** Perceptron Mk1.5 (ai_model, core, sponsor); Sentinel-2 via Microsoft Planetary Computer (data_source, core); Hansen Global Forest Change (data_source, core); JRC Global Forest Cover 2020 (data_source, core); MapLibre GL (maps_geo, supporting); Cursor (other, token)
- **Sponsor APIs:** Perceptron | fit: Used Perceptron Mk1.5 on before/after Sentinel-2 pairs and year-by-year video to box converted regions, then cross-checked them against loss pixels.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 7, writeup long, impact claims True (Cites EUR 126 billion annual covered imports, 6.7 million hectares tropical primary forest lost in 2024, and 880 ha cleared on the sample plot.)
- **Notes:** Region confirmed only if at least 25% shows post-2020 loss, else inconclusive; global sweep of clearings run on a university cluster; reported 100% precision and 67% recall on a 48-chip test.
- **Team size:** 3 | **Confidence:** high | unverified: stack_database
- **Links:** [Devpost](https://devpost.com/software/clearcut-p5hmfx)

### Pollensight  (DubHacks '26)

- **Prizes:** Winner Community Kitchen: 2nd Place [2nd]  (tier: track_winner)
- **Pitch:** Turns fixed-camera video into per-flower insect visit records, forecasts insect paths and plans a pollinator robot route, with an RL bee simulation.
- **Problem / user:** Pollinators are declining and crops depend on them; growers lack actionable data on which flowers get visited and how a robot could help. / growers and agricultural robotics researchers
- **Domain / idea type:** sustainability_climate + ai_agents_infra / data_or_analytics
- **Platforms / hardware / AI:** web / False / vision; predictive_ml; rag_or_search; other
- **Stack:** langs Python; TypeScript; frontend React 19; Vite; three.js; Canvas 2D; SVG; backend Node.js; Python; db ; hosting 
- **Tech/APIs:** Perceptron Mk1.5 (ai_model, core, sponsor); OpenCV (framework, core); scikit-learn (framework, supporting); Stable-Baselines3 / Gymnasium (framework, core); MuJoCo (Crazyflie 2 model) (framework, supporting); Monash insect datasets (data_source, core); three.js (framework, supporting)
- **Sponsor APIs:** Perceptron | fit: Used Perceptron Mk1.5 for box detection, JSON-schema output and Files API to verify insects and locate flowers in video.
- **Repo:** public, commits 66 (before/in/after event: 0/66/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 13, writeup long, impact claims True (Cites a third of food depending on pollinators and reports accuracy figures such as 90% tracking coverage and 79% top-3 next-flower accuracy.)
- **Notes:** Cheap OpenCV tracker confirmed by Perceptron Mk1.5 crops (visit precision 64% to 90%); cached API client replays offline; RL bee replayed in MuJoCo with Crazyflie model; 48 clips from public datasets.
- **Team size:** 4 | **Confidence:** high | unverified: stack_database; stack_hosting; domain_secondary
- **Links:** [Devpost](https://devpost.com/software/beebot-zbaxvy) | [GitHub](https://github.com/b-ananya/pollensight)

### ReMind  (DubHacks '26)

- **Prizes:** 2nd Place Perceptron: Robotics [2nd]; [MLH] Best Use of Backboard [unknown]  (tier: sponsor_winner)
- **Pitch:** Voice memory-game companion for dementia care that starts a robot-arm keychain shuffle game and texts caregivers if the resident says something worrying.
- **Problem / user:** Nursing home residents with dementia lack staff-led cognitive activities, and existing digital tools are hard for older adults to use. / dementia residents and caregivers
- **Domain / idea type:** mental_health + health_wellness / hardware_gadget
- **Platforms / hardware / AI:** web; hardware / True / speech_or_voice; llm_chat; agent_or_tool_use; vision; predictive_ml
- **Stack:** langs Python; TypeScript; frontend Next.js; backend FastAPI; Node service; db ; hosting 
- **Tech/APIs:** Gemini Live API (ai_model, core, sponsor); Backboard (other, core, sponsor); Photon (iMessage SDK) (telecom, supporting, sponsor); Perceptron cloud training (ai_model, supporting, sponsor); SO-101 arm with LeRobot (hardware_part, core)
- **Sponsor APIs:** Gemini; Backboard; Photon; Perceptron | fit: Used Backboard for long-term voice memory and Perceptron's cloud to train arm policies, though the page says the learned policy could not reliably grasp.
- **Repo:** public, commits 188 (before/in/after event: 0/188/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 4, writeup long, impact claims True (Says nearly half of nursing home residents live with dementia; reports honest robot results such as 5 of 7 re-picks working.)
- **Notes:** AI can only call a short allowlisted tool set enforced by server and robot code; SO-101 arm trained from 60 demos but demo runs taught positions with camera verification; Photon iMessage alerts.
- **Team size:** 4 | **Confidence:** high | unverified: stack_database; stack_hosting
- **Links:** [Devpost](https://devpost.com/software/remind-y8kg9s) | [GitHub](https://github.com/remind-dubhacks/dubhacks-2026)

### Robo-view  (DubHacks '26)

- **Prizes:** 1st Place Perceptron: Robotics [1st]  (tier: sponsor_winner)
- **Pitch:** Voice- or text-commanded SO-101 robot arm with a camera that films products from dynamic cinematic angles using a trained movement policy.
- **Problem / user:** Dynamic-angle product videos are laborious to shoot; the team wanted algorithmic robot cinematography that is smooth and efficient. / product marketers and video creators
- **Domain / idea type:** creative_media + retail_consumer / hardware_gadget
- **Platforms / hardware / AI:** hardware; mobile_cross / True / vision; speech_or_voice; agent_or_tool_use; predictive_ml
- **Stack:** langs Python; frontend ; backend ; db ; hosting 
- **Tech/APIs:** SO-101 robotic arm (hardware_part, core); Isaac 0.5 model (ai_model, core, sponsor); Perceptron Mk1.5 API (ai_model, supporting, sponsor)
- **Sponsor APIs:** Perceptron | fit: Trained a robot arm policy on Perceptron's Isaac model and used the Perceptron API to relabel bounding boxes, matching the Robotics track.
- **Repo:** public, commits 54 (before/in/after event: 0/53/1), README solid
- **Demo/writeup:** video True, live none, screenshots 1, writeup medium, impact claims False
- **Notes:** About 75 teleoperated demonstrations (25 per movement) used to train with Isaac 0.5; Perceptron used to relabel data with bounding boxes; app returns recorded video to the user.
- **Team size:** 4 | **Confidence:** high | unverified: platforms; stack_frontend; tech_items.is_sponsor
- **Links:** [Devpost](https://devpost.com/software/robo-view) | [GitHub](https://github.com/kaleturner/dubhacks_2026/tree/main)

### SonoRocky  (DubHacks '26)

- **Prizes:** 3rd Place Perceptron: Perception [3rd]  (tier: sponsor_winner)
- **Pitch:** Phone-camera scene narration plus an ultrasonic cane attachment that turns obstacle distance into beeps, helping visually impaired people navigate.
- **Problem / user:** Mobility canes give limited information, and visually impaired people suffer frequent injuries from hazards and head-level obstacles. / blind and low-vision pedestrians
- **Domain / idea type:** accessibility + safety_security / hardware_gadget
- **Platforms / hardware / AI:** web; hardware / True / vision; speech_or_voice; llm_chat
- **Stack:** langs Python; JavaScript; C; frontend HTML5; JavaScript; backend Python server; db ; hosting 
- **Tech/APIs:** Perceptron mk1.5 (ai_model, core, sponsor); ElevenLabs TTS (ai_model, core, sponsor); ESP8266 with ultrasonic sensor (hardware_part, core); Fusion 360 / Prusa MK4 printed housing (hardware_part, supporting)
- **Sponsor APIs:** Perceptron; ElevenLabs | fit: Used Perceptron's vision model for live frame descriptions and hazard alerts in an accessibility assistant.
- **Repo:** public, commits 17 (before/in/after event: 0/17/0), README thin
- **Demo/writeup:** video True, live none, screenshots 9, writeup long, impact claims True (Cites a study: 7% of respondents had non-superficial injuries monthly and 13% head-level injuries; claims hardware under $15.)
- **Notes:** Perceptron mk1.5 describes camera frames with under 2s latency, ElevenLabs streams speech; ESP8266 ultrasonic sensor on a 3D-printed cane clamp posts distances over WiFi; hardware under $15.
- **Team size:** 4 | **Confidence:** high | unverified: stack_database; stack_hosting; tech_items.is_sponsor
- **Links:** [Devpost](https://devpost.com/software/walk-safer) | [GitHub](https://github.com/tsengjohn44-lgtm/dh26-project)

### Starward  (DubHacks '26)

- **Prizes:** T-Mobile: 2nd Place [2nd]  (tier: sponsor_winner)
- **Pitch:** Hiking planner that estimates where satellite messaging will work along a trail, recommends check-in spots, and texts trip plans to an emergency contact.
- **Problem / user:** Hikers lose cell service in remote areas and do not know where satellite messaging would work or whether they need paid satellite service. / hikers and their emergency contacts
- **Domain / idea type:** safety_security + telecom_networking / data_or_analytics
- **Platforms / hardware / AI:** web; bot_or_chat / False / False
- **Stack:** langs Python; JavaScript; HTML; frontend HTML; JavaScript; Folium; backend Flask; Node.js; db ; hosting Render
- **Tech/APIs:** CelesTrak (data_source, core); Skyfield/SGP4 (other, core); OpenStreetMap (maps_geo, core); Folium (maps_geo, core); Photon Spectrum (telecom, supporting, sponsor); T-Mobile T-Satellite (telecom, supporting, sponsor); Cursor (other, token); Claude Code (other, token)
- **Sponsor APIs:** Photon | fit: Recommendation engine compares phone, carrier and satellite plans including T-Mobile T-Satellite; Photon carries trip sharing and check-ins.
- **Repo:** public, commits 16 (before/in/after event: 0/16/0), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots None, writeup long, impact claims False
- **Notes:** Coverage is an estimate from orbit calculations plus terrain; recommendation engine can advise buying nothing; Photon check-in bridge built in Node alongside a Flask app.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots; ai_used
- **Links:** [Devpost](https://devpost.com/software/starward) | [GitHub](https://github.com/eva032/Starward)

### Tenant  (DubHacks '26)

- **Prizes:** Photon: Track Winner [unknown]  (tier: sponsor_winner)
- **Pitch:** Scan a QR in a room to get a ten-minute chat-controlled lease on nearby devices (phone flashlight, laptop music and voice), via web or iMessage.
- **Problem / user:** Shared spaces like hospital rooms and hotels have controllable devices that guests are not allowed to operate, forcing awkward workarounds. / guests and hosts in shared rooms (hospital, hotel)
- **Domain / idea type:** ai_agents_infra + accessibility / automation_or_agent
- **Platforms / hardware / AI:** web; bot_or_chat / True / llm_chat; agent_or_tool_use
- **Stack:** langs Python; JavaScript; AppleScript; HTML; CSS; frontend HTML; CSS; JavaScript; backend FastAPI; WebSockets; db ; hosting 
- **Tech/APIs:** Photon 2.0 iMessage (telecom, core, sponsor); OpenAI Codex (ai_model, core); FastAPI (framework, core); WebSockets (framework, core); AppleScript (other, supporting)
- **Sponsor APIs:** Photon | fit: Used Photon 2.0 to give the room a real phone number and carry iMessage conversations to the agent.
- **Repo:** public, commits 52 (before/in/after event: 0/51/1), README detailed
- **Demo/writeup:** video True, live none, screenshots 6, writeup long, impact claims False
- **Notes:** Access is a time-limited lease checked at each command with version stamps so stale commands are refused; host reset rotates the room code; devices are plain web pages plus AppleScript.
- **Team size:** 2 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/tenant-lpy96k) | [GitHub](https://github.com/owen-tsao/tenant)

### tensormew  (DubHacks '26)

- **Prizes:** Winner Chef's Kitchen: 1st Place [1st]  (tier: track_winner)
- **Pitch:** Reinforcement-learning agent plays Pokemon Crystal to the first gym badge, calling an LLM only for stuck or hard moments.
- **Problem / user:** Calling an LLM on every game frame is slow and costly; most steps are mechanical and need no language reasoning. / AI/RL researchers and game-agent builders
- **Domain / idea type:** ai_agents_infra + entertainment_games / automation_or_agent
- **Platforms / hardware / AI:** desktop; cli / False / agent_or_tool_use; vision; llm_chat; predictive_ml
- **Stack:** langs Python; frontend Streamlit; backend PyBoy; Gymnasium; Pydantic; db SQLite; hosting 
- **Tech/APIs:** PyBoy (framework, core); PyTorch (framework, core); PPO (NumPy/PyTorch) (framework, core); Gemini tool calling (ai_model, core); Gymnasium (framework, supporting); Streamlit (framework, supporting); SQLite (database, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 134 (before/in/after event: 0/130/4), README solid
- **Demo/writeup:** video True, live none, screenshots 15, writeup long, impact claims False
- **Notes:** 13.2M-parameter vision plus RAM GRU policy in PyBoy; Gemini tool calls only on triggers with logged reasons and dollar cost; reward shaped on story event flags; 34 test modules.
- **Team size:** 4 | **Confidence:** high | unverified: sponsor_apis_used; is_sponsor_flags; stack_hosting
- **Links:** [Devpost](https://devpost.com/software/tensor-mew) | [GitHub](https://github.com/AvinashD24/tensormew)

### Tool Distill  (DubHacks '26)

- **Prizes:** Winner Cook Smarter: 1st Place [1st]  (tier: track_winner)
- **Pitch:** Python library and Claude Code plugin that records agent tool calls and turns expensive successful runs into verified single-call tools.
- **Problem / user:** Agents rediscover the same long tool-call sequences every run, wasting tokens and time, and generated tools are hard to trust. / developers running AI agents in production
- **Domain / idea type:** dev_tools + ai_agents_infra / dev_tool
- **Platforms / hardware / AI:** cli; other / False / agent_or_tool_use; llm_chat
- **Stack:** langs Python; frontend ; backend Typer; MCP SDK; db SQLite; hosting PyPI
- **Tech/APIs:** Anthropic SDK / Claude (ai_model, core); Claude Code plugin and hooks (framework, core); MCP SDK (framework, core); SQLite (WAL) (database, supporting); pytest (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 34 (before/in/after event: 0/34/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 0, writeup long, impact claims True (Demo claim of a 20-30 call discovery run reduced to one distilled call with four inside; business-model reasoning without market numbers.)
- **Notes:** Published to PyPI (0.1.0) and installable as Claude Code plugin; proposals pass AST static, replay and efficiency checks with a draft-to-deprecated lifecycle; 338 offline tests.
- **Team size:** 2 | **Confidence:** high | unverified: sponsor_apis_used
- **Links:** [Devpost](https://devpost.com/software/tool-distill) | [GitHub](https://github.com/irtaza-kashif/tool-distill/tree/main)
