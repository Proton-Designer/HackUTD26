# Cal Hacks: project cards (10 projects)

Facts and short paraphrases only; no cross-project analysis. Full records are in the workbook and JSONL.

## Cal Hacks 11.0 (2024)

### Duet: Brainwaves -> Live Music  (Cal Hacks 11.0 (2024))

- **Prizes:** Winner Cal Hacks: 1st Overall [1st]  (tier: overall_top3)
- **Pitch:** EEG headset reads focus and relaxation and a Gemini-driven live composer turns them into adaptive Sonic Pi music, aimed at kids with developmental disabilities.
- **Problem / user:** Children with developmental disabilities, especially non-verbal ones, lack tools to express emotion and creativity through music. / children with developmental disabilities, music therapists
- **Domain / idea type:** accessibility + creative_media / creative_tool
- **Platforms / hardware / AI:** web; hardware / True / llm_chat; generative_media
- **Stack:** langs Python; Ruby; JavaScript; frontend Next.js; three.js; backend Python; Emotiv Cortex library; Sonic Pi; db SingleStore; hosting 
- **Tech/APIs:** Emotiv EEG headset (hardware_part, core); Google Gemini (ai_model, core); Sonic Pi (framework, core); SingleStore (database, supporting, sponsor); Next.js (framework, supporting); three.js (framework, supporting)
- **Sponsor APIs:** SingleStore
- **Repo:** public, commits 12 (before/in/after event: 12/0/0), README solid
- **Demo/writeup:** video None, live none, screenshots 5, writeup long, impact claims True (Cites 1 in 10 US children with developmental disabilities and a 15.59% projected music therapy market growth rate.)
- **Notes:** LLM acts as a live composer each few seconds using recent EEG state, available instruments and its prior output; Sonic Pi plays it; Three.js 3D brain visualiser.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; n_screenshots; SingleStore is_sponsor; ui_polish; event dates from memory
- **Links:** [Devpost](https://devpost.com/software/duet-0tbkxe) | [GitHub](https://github.com/daniel04wawng/duet-frontend ; https://github.com/soapantelope/duet-backend)

### GhostWriter  (Cal Hacks 11.0 (2024))

- **Prizes:** Winner Cal Hacks: 2nd Overall [2nd]  (tier: overall_top3)
- **Pitch:** Listens to live office-hour conversation and automatically inserts the useful points into the right lines of course notes using transcription, retrieval and LLM edits.
- **Problem / user:** Short-staffed teaching assistants struggle to keep course notes and documentation updated while helping students. / teaching assistants and instructors
- **Domain / idea type:** education + productivity_workplace / automation_or_agent
- **Platforms / hardware / AI:** web / False / llm_chat; rag_or_search; speech_or_voice
- **Stack:** langs Python; frontend Reflex; React; backend Reflex; Python; db ChromaDB; hosting 
- **Tech/APIs:** Deepgram live transcription (ai_model, core); Google Gemini (summaries, embeddings) (ai_model, core); ChromaDB (database, core); Groq (llama3-70b) (ai_model, core); Reflex (framework, core)
- **Sponsor APIs:** 
- **Repo:** public, commits 24 (before/in/after event: 24/0/0), README solid
- **Demo/writeup:** video None, live none, screenshots 4, writeup long, impact claims False
- **Notes:** Inserts generated markdown at line-level points using unique tokens in the source text; embedding distance thresholds decide whether to skip, append or create a note.
- **Team size:** 2 | **Confidence:** medium | unverified: has_demo_video; ui_polish; event dates from memory; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/ghostwriter-491kuy) | [GitHub](https://github.com/rqchao/calhacks24)

### SnackSnap - recycle to feed your pet  (Cal Hacks 11.0 (2024))

- **Prizes:** Winner Cal Hacks: 3rd Overall [3rd]  (tier: overall_top3)
- **Pitch:** iOS app where you photograph yourself recycling, Gemini validates the photo, and you feed a digital pet and earn XP rewards.
- **Problem / user:** Recycling feels inconvenient so people throw recyclables in the trash; a pet game makes it rewarding. / everyday consumers, recycling-minded phone users
- **Domain / idea type:** sustainability_climate + entertainment_games / twist_on_known_app
- **Platforms / hardware / AI:** mobile_ios / False / vision
- **Stack:** langs Swift; frontend SwiftUI; backend Firebase; db Firebase; hosting Firebase Storage
- **Tech/APIs:** Google Gemini 1.5 Pro (ai_model, core); Firebase (cloud, supporting); Firebase Storage (cloud, supporting); SwiftUI (framework, core)
- **Sponsor APIs:** 
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live none, screenshots 5, writeup medium, impact claims False
- **Notes:** Gemini image recognition gates the pet-feeding mechanic; XP redeemable for rewards such as early product access.
- **Team size:** 2 | **Confidence:** medium | unverified: has_demo_video; ui_polish; event dates from memory; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/snacksnap-lw4b9q)


## Cal Hacks 12.0 (2025)

### FaceTimeOS: AI Mac Agent  (Cal Hacks 12.0 (2025))

- **Prizes:** Winner Cal Hacks: 1st Overall [1st]  (tier: overall_top3)
- **Pitch:** Call or iMessage your Mac and a Claude-orchestrated agent answers, runs computer-use tasks, speaks progress back and texts a confirming screenshot.
- **Problem / user:** Remote desktop tools are clunky and visual; people away from their Mac need quick conversational access to files, apps and scripts. / Mac users away from their computer, developers running long scripts
- **Domain / idea type:** ai_agents_infra + productivity_workplace / automation_or_agent
- **Platforms / hardware / AI:** desktop / False / llm_chat; agent_or_tool_use; speech_or_voice
- **Stack:** langs Python; JavaScript; frontend Electron; React; Tailwind CSS; backend Flask; REST; db ; hosting 
- **Tech/APIs:** Claude (ai_model, core, sponsor); Fish Audio (ai_model, core, sponsor); Fetch.ai (other, core, sponsor); Groq (ai_model, supporting, sponsor); Electron (framework, core); Flask (framework, supporting); Hugging Face (ai_model, token)
- **Sponsor APIs:** Claude; Fish Audio; Fetch.ai; Groq
- **Repo:** public, commits 114 (before/in/after event: 0/101/13), README detailed
- **Demo/writeup:** video None, live none, screenshots 4, writeup long, impact claims False
- **Notes:** Uses Fish Audio virtual mic and speaker devices to pipe live FaceTime call audio to the agent and speak replies back, with no official FaceTime API.
- **Team size:** 3 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates from memory; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/facetime-macos-ai-agent) | [GitHub](https://github.com/ThePickleGawd/calhacks-25)

### Ted.AI  (Cal Hacks 12.0 (2025))

- **Prizes:** Winner Cal Hacks: 2nd Overall [2nd]; Winner LiveKit: Most Creative Project [unknown]  (tier: overall_top3)
- **Pitch:** Sensor-laden teddy bear that senses hugs, motion and heart rate, talks with an LLM to calm children, and feeds a clinician dashboard.
- **Problem / user:** Children with anxiety, ADHD or loneliness lack an empathetic companion that helps regulate emotions; parents and clinicians lack visibility. / children with emotional struggles, parents, educators, clinicians
- **Domain / idea type:** mental_health + education / hardware_gadget
- **Platforms / hardware / AI:** hardware; web / True / llm_chat; speech_or_voice; predictive_ml
- **Stack:** langs Python; frontend React; D3.js; backend Flask; LangChain; MQTT; db MongoDB; InfluxDB; Firebase; hosting AWS; Docker
- **Tech/APIs:** ESP32 with pulse, touch and MPU6050 sensors (hardware_part, core); OpenAI Whisper (ai_model, core); OpenAI GPT (ai_model, core); RoBERTa (ai_model, supporting); LangChain (framework, supporting); MQTT (other, supporting); Fetch.ai (other, unclear, sponsor); Gemini (ai_model, unclear); LiveKit (other, unclear, sponsor); AWS (cloud, unclear)
- **Sponsor APIs:** LiveKit; Fetch.ai | fit: LiveKit prize listed; the writeup does not describe LiveKit use, though Fetch.ai appears in Built With.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live none, screenshots None, writeup long, impact claims False
- **Notes:** ESP32 bear with pulse, touch and accelerometer sensors; fuses sensor data over MQTT; dashboard shows simulated brain-region activations. Long stack list incl. TensorFlow Lite Micro, InfluxDB.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; n_screenshots; ui_polish; sponsor_apis_used; event dates from memory
- **Links:** [Devpost](https://devpost.com/software/ted-ai-x8537t)


## Cal Hacks 13.0 (2026)

### half full  (Cal Hacks 13.0 (2026))

- **Prizes:** Winner Cal Hacks Third Overall [3rd]  (tier: overall_top3)
- **Pitch:** Mobile-first PWA delivering a small daily edition of hopeful news with AI illustrations, narration, source receipts and a reaction jar.
- **Problem / user:** Doom-framed news and chopped-up social clips overwhelm young people, who stop following current events. / Gen Z news readers
- **Domain / idea type:** creative_media + social_community / twist_on_known_app
- **Platforms / hardware / AI:** web / False / llm_chat; rag_or_search; generative_media; speech_or_voice
- **Stack:** langs TypeScript; frontend Next.js; React; Motion; GSAP; PWA; backend Node.js; Apify Actor; db Firestore; hosting Vercel
- **Tech/APIs:** Anthropic Claude (ai_model, core, sponsor); Apify (data_source, core, sponsor); Recraft (ai_model, core); Cartesia (ai_model, core, sponsor); Firebase Auth and Firestore (auth, supporting); Runway (ai_model, supporting); Vercel (cloud, supporting); Next.js (framework, core)
- **Sponsor APIs:** Anthropic Claude; Apify; Cartesia
- **Repo:** public, commits 50 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video None, live not_checked, screenshots 10, writeup long, impact claims False
- **Notes:** Custom Apify Actor gathers evidence per story and the pipeline can reject under-supported stories; finite 3-5 story edition ends with a 'caught up' screen, plus crossword and illustrated reactions.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates
- **Links:** [Devpost](https://devpost.com/software/half-full) | [GitHub](https://github.com/rainazab/half-full)

### Orbit Health  (Cal Hacks 13.0 (2026))

- **Prizes:** Cal Hacks Best Planet-First Social Impact Hack [unknown]  (tier: track_winner)
- **Pitch:** Village pod with camera, mic and pulse oximeter runs a nurse-style voice triage, then a satellite-aware planner ships medicines to rural Zambian clinics before roads flood.
- **Problem / user:** Rural Zambian villages cannot signal what medicine they need and stock does not reach clinics before rainy-season road closures. / rural villagers in Zambia, clinic staff, health logistics planners
- **Domain / idea type:** health_wellness + sustainability_climate / data_or_analytics
- **Platforms / hardware / AI:** web; hardware / True / llm_chat; speech_or_voice; vision; predictive_ml
- **Stack:** langs TypeScript; Python; frontend Next.js 15; backend SpacetimeDB reducers; Next.js API routes; TensorFlow; db SpacetimeDB; hosting local laptop
- **Tech/APIs:** SpacetimeDB (database, core, sponsor); Grok Voice (xAI) (ai_model, core); Jev (TypeSafe) (ai_model, core); Claude (ai_model, supporting, sponsor); NASA and Copernicus satellite data (data_source, core); OpenStreetMap / OSRM (maps_geo, core); Seeed XIAO nRF52840 with MAX30101 and Grove Vision AI V2 (hardware_part, core); HumBug mosquito models (ai_model, supporting)
- **Sponsor APIs:** SpacetimeDB; Claude | fit: Planet-First track win; the only sponsor mentions are SpacetimeDB as the full backend and Claude for wording and second-opinion camera checks.
- **Repo:** public, commits 86 (before/in/after event: None/None/None), README solid
- **Demo/writeup:** video None, live none, screenshots 3, writeup long, impact claims True (Cites Zambia malaria cases and clinic stockout statistics, and simulated planner savings of 833 to 83 movements and 112,849 km.)
- **Notes:** Solo build; maps 23,206 villages from satellite roof counts, uses keyless satellite data, SpacetimeDB reducers as the whole backend, firmware on real boards, mosquito wingbeat classifier.
- **Team size:** 1 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates
- **Links:** [Devpost](https://devpost.com/software/orbit-health) | [GitHub](https://github.com/philiprmocanu-cell/triage-pod)

### Silent Voice  (Cal Hacks 13.0 (2026))

- **Prizes:** Cal Hacks Second Overall [2nd]; [Cartesia] Best Use of Cartesia [unknown]  (tier: overall_top3)
- **Pitch:** Reads silent mouthing via camera lip reading and face EMG, uses Claude to predict dialogue, and speaks in the user's cloned voice over a live phone call.
- **Problem / user:** People who lose their voice box after laryngectomy cannot speak in their own voice; existing devices give robotic sound. / laryngectomy patients and their families
- **Domain / idea type:** accessibility + health_wellness / hardware_gadget
- **Platforms / hardware / AI:** hardware; desktop / True / llm_chat; speech_or_voice; vision; predictive_ml
- **Stack:** langs Python; frontend dashboard; backend PyTorch; MediaPipe; KenLM; ZeroMQ; Twilio; db ; hosting local laptop with RTX 5060
- **Tech/APIs:** Cartesia Sonic and Ink (ai_model, core, sponsor); Claude (Haiku and Opus) (ai_model, core, sponsor); Auto-AVSR (ai_model, core); EMG sensor pads with Arduino (hardware_part, core); Twilio (telecom, core); PyTorch (framework, supporting); MediaPipe (framework, supporting)
- **Sponsor APIs:** Cartesia; Claude | fit: Used Cartesia Sonic for streaming cloned-voice output with emotion and Cartesia Ink for caller transcription over a live phone call.
- **Repo:** public, commits 129 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video None, live none, screenshots 6, writeup long, impact claims True (Cites ~190,000 yearly voice-box cancer cases and measured error rates, latency and accuracy figures from its own tests.)
- **Notes:** Fuses a retrained lip reader, a custom EMG model on four face pads, and Claude next-word prediction every 100 ms; claims 9.8% word error on a new session and ~0.7 s latency; runs on one laptop with Twilio call demo.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates
- **Links:** [Devpost](https://devpost.com/software/silent-voice-s1f74p) | [GitHub](https://github.com/thaimtl/Silent-Voice)

### Sophi - The Physical Augmentation Walker  (Cal Hacks 13.0 (2026))

- **Prizes:** Winner Cal Hacks First Overall [1st]  (tier: overall_top3)
- **Pitch:** Walker with a voice agent, distance-sensing haptics, robotic arms, lift and GPS, plus a caregiver companion app.
- **Problem / user:** Falls and mobility limits threaten independence of elderly and disabled people, and caregivers lack ways to check in. / elderly and mobility-impaired people, blind users, caregivers
- **Domain / idea type:** accessibility + health_wellness / hardware_gadget
- **Platforms / hardware / AI:** hardware; web; mobile_cross / True / llm_chat; agent_or_tool_use; speech_or_voice
- **Stack:** langs TypeScript; Python; C++; frontend Next.js; React; Leaflet.js; backend Node.js; Zod; PlatformIO; db PostgreSQL; Supabase; SpacetimeDB; hosting Render
- **Tech/APIs:** Claude (Anthropic) (ai_model, core, sponsor); Cartesia (ai_model, core, sponsor); SpacetimeDB (database, core, sponsor); Raspberry Pi 5 and ESP32 modules (hardware_part, core); SO-101 robot arms (hardware_part, core); Supabase (database, supporting); OpenStreetMap / Leaflet (maps_geo, supporting); Stripe (payments, token); Piper TTS (ai_model, unclear)
- **Sponsor APIs:** Claude; Cartesia; SpacetimeDB
- **Repo:** public, commits 331 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video None, live not_checked, screenshots 14, writeup long, impact claims True (Cites 340 million blind or low-vision people and 1.7 billion people with mobility restrictions as the addressable population.)
- **Notes:** Raspberry Pi 5 plus three ESP32s, four soldered boards and 30+ 3D-printed parts; SO-101 arms driven by a custom iPhone-based harness after other control options proved unreliable.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates
- **Links:** [Devpost](https://devpost.com/software/sophi) | [GitHub](https://github.com/mzhao1599/sophi)

### Standard Response  (Cal Hacks 13.0 (2026))

- **Prizes:** Cal Hacks Best People-First Social Impact Hack [unknown]; [Microsoft] Built for the Real World (1st), Customer Impact Award (2nd) [unknown]; [Convex] Best use of Convex [unknown]; [Apify] Best Use of Apify [unknown]; [Moss] Best Use of Moss [unknown]; [Anthropic] Claude for Public Benefit [unknown]  (tier: track_winner)
- **Pitch:** Voice agent phones every home in a wildfire evacuation zone, triages who cannot leave, and dispatches accessible vehicles or neighbors, promising help only once a driver accepts.
- **Problem / user:** Disabled residents were left behind in the Eaton Fire because no one had staff to call everyone and coordinate available vans. / paratransit agencies, dispatchers, disabled and elderly residents, neighbors
- **Domain / idea type:** safety_security + accessibility / automation_or_agent
- **Platforms / hardware / AI:** web; bot_or_chat / False / llm_chat; agent_or_tool_use; speech_or_voice; rag_or_search; predictive_ml
- **Stack:** langs TypeScript; Python; frontend Next.js; React; Tailwind CSS; backend Node.js; Convex; OR-Tools; SimPy; OSMnx; Twilio; WebSockets; db Convex; hosting Fly.io; DigitalOcean; Vercel
- **Tech/APIs:** Claude (Haiku, Sonnet, Opus) (ai_model, core, sponsor); Cartesia Ink and Sonic (ai_model, core, sponsor); Moss (data_source, core, sponsor); Convex (database, core, sponsor); Apify Actor (data_source, core, sponsor); Twilio (telecom, core); Mana (other, supporting, sponsor); OR-Tools and custom ALNS solver (other, core); OSMnx / OpenStreetMap (maps_geo, core); DigitalOcean (cloud, supporting); Fly.io (cloud, supporting)
- **Sponsor APIs:** Claude; Cartesia; Moss; Convex; Apify; Mana | fit: Social impact track win; writeup has a per-sponsor section describing Claude, Cartesia, Moss, Convex, Apify and Mana each doing a specific job.
- **Repo:** public, commits 300 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video None, live not_checked, screenshots 16, writeup long, impact claims True (Simulation results on Eaton Fire night (641 of 662 on time vs 39), voice-exam scores, 0.86 s median turn latency, and firefighter quotes.)
- **Notes:** Eaton Fire night simulation over real records (claims 641 of 662 households out on time vs 39 modeled today); promise guard enforced in code; custom Apify Actor; Mana-written tests; team visited fire stations.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates
- **Links:** [Devpost](https://devpost.com/software/standard-response) | [GitHub](https://github.com/Imhaohao/calhacks)
