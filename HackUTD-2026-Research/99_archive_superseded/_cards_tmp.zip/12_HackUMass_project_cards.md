# HackUMass: project cards (28 projects)

Facts and short paraphrases only; no cross-project analysis. Full records are in the workbook and JSONL.

## HackUMass XII

### Ai-Companion  (HackUMass XII)

- **Prizes:** Wolfram Award [unknown]  (tier: sponsor_winner)
- **Pitch:** Unity desktop pet companion using Whisper, GPT and ElevenLabs voice, with a JSON memory profile and desktop assistant actions.
- **Problem / user:** People feel isolated and overloaded by screens and want a personalised companion that adapts over time. / desktop users wanting a companion
- **Domain / idea type:** ai_agents_infra + mental_health / new_category
- **Platforms / hardware / AI:** desktop / False / llm_chat; speech_or_voice; agent_or_tool_use
- **Stack:** langs C#; Python; frontend Unity; backend ; db ; hosting 
- **Tech/APIs:** OpenAI GPT-4o-mini (ai_model, core); Whisper (ai_model, core); ElevenLabs (ai_model, core); Unity (framework, core); OpenWeatherMap (data_source, supporting); NewsAPI (data_source, supporting); Figma (other, token)
- **Sponsor APIs:** 
- **Repo:** public, commits 97 (before/in/after event: 94/0/3), README detailed
- **Demo/writeup:** video False, live none, screenshots 10, writeup long, impact claims False
- **Notes:** Two-layer GPT calls maintain a locally stored profile/memory JSON; keyword-triggered news and weather injection; Windows DLL actions like calendar; GitHub link is a third-party Unity package, not the project repo.
- **Team size:** 2 | **Confidence:** medium | unverified: github_url_is_dependency_not_project_repo
- **Links:** [Devpost](https://devpost.com/software/ai-companion-d3681a) | [GitHub](https://github.com/srcnalt/OpenAI-Unity)

### Braille Assist  (HackUMass XII)

- **Prizes:** Wolfram Award [unknown]  (tier: sponsor_winner)
- **Pitch:** Arduino-driven motor device that converts typed English text into physical braille output.
- **Problem / user:** Translating text into braille is more useful when delivered on a physical device rather than a screen. / braille readers
- **Domain / idea type:** accessibility / hardware_gadget
- **Platforms / hardware / AI:** hardware / True / False
- **Stack:** langs Python; C++; frontend ; backend ; db ; hosting 
- **Tech/APIs:** Arduino (hardware_part, core); Motors (hardware_part, core); 3D printing (other, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 1 (before/in/after event: 0/1/0), README none
- **Demo/writeup:** video False, live none, screenshots 14, writeup short, impact claims False
- **Notes:** Team had no prior hardware experience; used motors and a 3D-printed box; Python and C++ code; photos of wiring and backend code.
- **Team size:** 5 | **Confidence:** high
- **Links:** [Devpost](https://devpost.com/software/braille-assist-1683ru) | [GitHub](https://github.com/ImaMinh/HackUMass-2024)

### FoundU  (HackUMass XII)

- **Prizes:** Wolfram Award [unknown]  (tier: sponsor_winner)
- **Pitch:** Mobile app that reads a found UMass UCard via OCR, looks up the owner's email and automatically emails them.
- **Problem / user:** Lost UCards rarely reach owners because finders cannot easily identify or contact them. / UMass students
- **Domain / idea type:** social_community + productivity_workplace / automation_or_agent
- **Platforms / hardware / AI:** mobile_cross / False / vision
- **Stack:** langs TypeScript; JavaScript; frontend React Native; Expo; backend Node.js; Express; db ; hosting 
- **Tech/APIs:** Google Cloud Vision API (ai_model, core); Puppeteer (framework, core); Nodemailer (other, core); Expo (framework, supporting); Multer (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video False, live none, screenshots 6, writeup long, impact claims False
- **Notes:** Chains OCR name extraction, Puppeteer scraping of the campus people directory behind a session cookie, and automated email; writeup states a $1,700 Wolfram award; only link is a LinkedIn post.
- **Team size:** 2 | **Confidence:** high | unverified: github_url_absent_on_page
- **Links:** [Devpost](https://devpost.com/software/foundu)

### Loopwise  (HackUMass XII)

- **Prizes:** Best Use of ML/AI [unknown]  (tier: track_winner)
- **Pitch:** Recommends driving loops to rideshare drivers using DBSCAN clustering and LSTM demand forecasts over historical ride data.
- **Problem / user:** Rideshare drivers waste time and fuel idling or searching for passengers. / rideshare drivers
- **Domain / idea type:** mobility_transport + ai_agents_infra / data_or_analytics
- **Platforms / hardware / AI:** web / False / predictive_ml; recommendation
- **Stack:** langs Python; JavaScript; frontend React; Next.js; backend Flask; FastAPI; db ; hosting 
- **Tech/APIs:** LSTM (PyTorch/TensorFlow) (ai_model, core); DBSCAN (scikit-learn) (ai_model, core); Folium/Leaflet (maps_geo, supporting); Pandas/NumPy (framework, supporting)
- **Sponsor APIs:**  | fit: Trained demand-forecasting and clustering models are the core of the product.
- **Repo:** public, commits 12 (before/in/after event: 0/12/0), README detailed
- **Demo/writeup:** video False, live none, screenshots 26, writeup long, impact claims False
- **Notes:** Many charts and maps of ride data in gallery (26 images); writeup claims real-time GPS but describes historical datasets; open-source routing builds the loop.
- **Team size:** 2 | **Confidence:** high | unverified: real_time_claim
- **Links:** [Devpost](https://devpost.com/software/loopwise) | [GitHub](https://github.com/devger04/Loopwise)

### magic algorithms  (HackUMass XII)

- **Prizes:** Wolfram Award [unknown]  (tier: sponsor_winner)
- **Pitch:** Interactive web visualizer for Dijkstra, minimum spanning tree and network flow algorithms on user-built graphs.
- **Problem / user:** Graph algorithms taught in CS courses are hard to grasp without seeing them step by step. / CS students
- **Domain / idea type:** education / creative_tool
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs TypeScript; JavaScript; frontend Vue; HTML Canvas; backend ; db ; hosting Netlify
- **Tech/APIs:** Vue (framework, core); HTML Canvas (framework, core)
- **Sponsor APIs:** 
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 7, writeup short, impact claims False
- **Notes:** Course-tied (UMass CS311) teaching tool on Netlify; short writeup; no repo link listed.
- **Team size:** 3 | **Confidence:** high
- **Links:** [Devpost](https://devpost.com/software/magic-w453qf)

### NekoPix  (HackUMass XII)

- **Prizes:** Wolfram Award [unknown]  (tier: sponsor_winner)
- **Pitch:** Web tool where users sketch a level layout and give a theme; DALL-E 3 generates textures for a playable game.
- **Problem / user:** Game development is hard to start because it needs many tools and CS knowledge. / beginners in game development
- **Domain / idea type:** creative_media + education / creative_tool
- **Platforms / hardware / AI:** web / False / generative_media
- **Stack:** langs JavaScript; frontend Next.js; React; backend ; db ; hosting 
- **Tech/APIs:** DALL-E 3 (ai_model, core); Next.js (framework, core); React (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 46 (before/in/after event: 0/46/0), README solid
- **Demo/writeup:** video True, live not_checked, screenshots 7, writeup medium, impact claims False
- **Notes:** Drawing pad feeds a prebuilt game engine; texture generation runs async on a separately hosted backend so play continues while images load.
- **Team size:** 5 | **Confidence:** high
- **Links:** [Devpost](https://devpost.com/software/gameify) | [GitHub](https://github.com/waiwasabi/game2024)

### qSound  (HackUMass XII)

- **Prizes:** Nord Security Add-On [unknown]  (tier: sponsor_winner)
- **Pitch:** Live music audio drives a 12-qubit quantum simulation rendered as waves and particles, with a small neural net scoring intensity.
- **Problem / user:** Experimental project with no practical problem; merges quantum mechanics and neural networks to visualize sound. / music and quantum-computing enthusiasts
- **Domain / idea type:** creative_media + entertainment_games / creative_tool
- **Platforms / hardware / AI:** desktop / False / predictive_ml
- **Stack:** langs Python; frontend OpenGL; backend ; db ; hosting 
- **Tech/APIs:** Qiskit (framework, core); PyTorch (framework, core); OpenGL (framework, core)
- **Sponsor APIs:**  | fit: Entered for the Nord Security add-on prize; the writeup does not tie the project to security.
- **Repo:** public, commits 81 (before/in/after event: 0/81/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 3, writeup medium, impact claims False
- **Notes:** Maps amplitude, frequency and phase to qubit rotations; custom 60-song dataset for intensity model; custom FFT feature extraction; OpenGL particles.
- **Team size:** 4 | **Confidence:** high | unverified: sponsor_fit_note
- **Links:** [Devpost](https://devpost.com/software/q-sound) | [GitHub](https://github.com/odepoint/qSound)

### RealityPaint  (HackUMass XII)

- **Prizes:** Third Prize [3rd]  (tier: overall_top3)
- **Pitch:** Projector plus Kinect depth camera that maps generated art onto physical surfaces and masks out objects in front of them.
- **Problem / user:** Blending digital art with real spaces needs reliable object masking under projection, which webcams struggled to provide. / artists, presenters, people decorating spaces
- **Domain / idea type:** creative_media / creative_tool
- **Platforms / hardware / AI:** desktop; hardware / True / generative_media; vision
- **Stack:** langs Python; frontend ; backend ; db ; hosting 
- **Tech/APIs:** Microsoft Kinect (hardware_part, core); OpenCV (framework, core); DALL-E 3 (ai_model, supporting); Projector (hardware_part, core)
- **Sponsor APIs:** 
- **Repo:** public, commits 97 (before/in/after event: 0/96/1), README solid
- **Demo/writeup:** video False, live none, screenshots 2, writeup medium, impact claims False
- **Notes:** Switched from webcam to Kinect overnight after a projection feedback loop; patched unfinished Python Kinect wrappers; team says it did not fully work.
- **Team size:** 3 | **Confidence:** high | unverified: ai_types
- **Links:** [Devpost](https://devpost.com/software/realitypaint) | [GitHub](https://github.com/beaverbois/RealityPaint)

### SpeedPUB  (HackUMass XII)

- **Prizes:** Grand Prize [1st]  (tier: overall_top3)
- **Pitch:** Python tool that converts EPUBs into syntax-highlighted versions, colouring words by part of speech (English and Chinese) and optionally bolding for speed reading, with a Tkinter GUI.
- **Problem / user:** Reading is time-consuming for avid readers and language learners; highlighting word function could speed reading and aid comprehension. / avid readers and language learners
- **Domain / idea type:** education + productivity_workplace / creative_tool
- **Platforms / hardware / AI:** desktop / False / other
- **Stack:** langs Python; frontend Tkinter; backend ; db ; hosting 
- **Tech/APIs:** NLTK (framework, core); HanLP (ai_model, core); EbookLib (framework, core); BeautifulSoup (framework, supporting); Tkinter (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 37 (before/in/after event: 0/37/0), README solid
- **Demo/writeup:** video None, live none, screenshots 6, writeup medium, impact claims False
- **Notes:** Pipeline uses EbookLib and BeautifulSoup to rewrite EPUB XHTML, NLTK for English and HanLP for Chinese part-of-speech tagging; team plans to keep using it themselves.
- **Team size:** 2 | **Confidence:** medium | unverified: has_demo_video; placement_tier
- **Links:** [Devpost](https://devpost.com/software/untitled-project-03byqsepgkdf) | [GitHub](https://github.com/theokrueger/speedpub)

### StoryBytes  (HackUMass XII)

- **Prizes:** Best Use of GenAI [unknown]  (tier: track_winner)
- **Pitch:** Kids' story generator producing text, illustrations and spoken narration from a description, with poem mode and clickable vocabulary.
- **Problem / user:** Children want to turn their ideas into stories, at suitable reading levels and in various languages. / children, parents, language learners
- **Domain / idea type:** education + creative_media / creative_tool
- **Platforms / hardware / AI:** web / False / llm_chat; generative_media; speech_or_voice
- **Stack:** langs TypeScript; JavaScript; frontend React; backend Node.js; Express; db ; hosting 
- **Tech/APIs:** OpenAI GPT-4o (ai_model, core); getimg.ai (ai_model, core); Black Forest Labs (ai_model, supporting); ElevenLabs (ai_model, core); Free Dictionary API (data_source, supporting)
- **Sponsor APIs:**  | fit: Multi-step generative pipeline covering text, images and audio fits the GenAI category.
- **Repo:** public, commits 142 (before/in/after event: 0/139/3), README solid
- **Demo/writeup:** video False, live none, screenshots 16, writeup long, impact claims False
- **Notes:** Chains GPT-4o, getimg.ai/Black Forest Labs images and ElevenLabs TTS; DALL-E access failed so image model was swapped; backend caches files to cut latency.
- **Team size:** 6 | **Confidence:** high
- **Links:** [Devpost](https://devpost.com/software/storybytes) | [GitHub](https://github.com/Citrus216/storybytes)

### The Miraculous Bits and Bytes Fuzzer  (HackUMass XII)

- **Prizes:** Nord Security Add-On [unknown]  (tier: sponsor_winner)
- **Pitch:** A Go fuzzer that mutates bytes of an input file, feeds it to a target program and logs the crashing byte and error.
- **Problem / user:** Developers lack an easy, efficient way to find vulnerabilities in their programs. / software developers
- **Domain / idea type:** safety_security + dev_tools / dev_tool
- **Platforms / hardware / AI:** cli / False / False
- **Stack:** langs Go; frontend ; backend ; db ; hosting 
- **Tech/APIs:** Go (framework, core); VS Code (other, token)
- **Sponsor APIs:**  | fit: Security-themed byte-mutation fuzzer submitted for the Nord Security add-on prize; no Nord product is named.
- **Repo:** private_or_missing, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video False, live none, screenshots 0, writeup medium, impact claims False
- **Notes:** Team was new to Go and fuzzing; tested against public GitHub projects; page has no screenshots; GitHub link points to a branch.
- **Team size:** 4 | **Confidence:** high | unverified: sponsor_fit_note; repo_clone_failed
- **Links:** [Devpost](https://devpost.com/software/a-miraculous-fuzzer) | [GitHub](https://github.com/azb0222/Fuzzer/tree/final)

### Tomo  (HackUMass XII)

- **Prizes:** Second Prize [2nd]  (tier: overall_top3)
- **Pitch:** Space Invaders-style Python game where OpenAI generates per-round twists such as bosses, portals and black holes, controllable with a Leap Motion hand tracker.
- **Problem / user:** No problem stated; aims to bring AI into a favourite hobby, retro gaming. / gamers
- **Domain / idea type:** entertainment_games / entertainment_or_game
- **Platforms / hardware / AI:** desktop / True / llm_chat; generative_media
- **Stack:** langs Python; C++; frontend pygame; backend ; db ; hosting 
- **Tech/APIs:** OpenAI API (ai_model, core); Leap Motion controller (hardware_part, core, sponsor); pygame (framework, core)
- **Sponsor APIs:** Leap Motion (hardware provided by HackUMass)
- **Repo:** public, commits 74 (before/in/after event: 0/70/4), README solid
- **Demo/writeup:** video None, live none, screenshots 3, writeup medium, impact claims False
- **Notes:** LLM responses are converted into executable Python that alters gameplay; Leap Motion input comes from a C++ script piped in as keyboard events; hardware loaned by the hackathon.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; ai_types
- **Links:** [Devpost](https://devpost.com/software/tomo-dmajc3) | [GitHub](https://github.com/Ben-Santana/AI-Space-Invaders)


## HackUMass XIII

### 3D Printing Kiosk  (HackUMass XIII)

- **Prizes:** Winner Second Prize [2nd]  (tier: overall_top3)
- **Pitch:** Makerspace kiosk where students scan an ID on a custom ESP32 RFID reader to authorize and start a sliced 3D print.
- **Problem / user:** Makerspace 3D printing had no checks on print length, printer count, training status or ownership of failed prints. / makerspace staff and CICS students
- **Domain / idea type:** productivity_workplace + education / hardware_gadget
- **Platforms / hardware / AI:** desktop; hardware / True / False
- **Stack:** langs C++; QML; frontend Qt Quick; backend ; db SQL (database software switched during build); hosting 
- **Tech/APIs:** ESP32 (hardware_part, core); PN5180 RFID module (hardware_part, core); Qt Quick (framework, core); OrcaSlicer (other, core); PlatformIO (other, supporting); Fusion (CAD) (other, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 123 (before/in/after event: 0/11/112), README thin
- **Demo/writeup:** video True, live none, screenshots 9, writeup long, impact claims False
- **Notes:** Solo build: custom PN5180 RFID reader with 3D-printed case, Qt/QML kiosk app, OrcaSlicer integration by mimicking OctoPrint API, derives stable ID from encrypted campus cards. Second repo: card-reader-firmware.
- **Team size:** 1 | **Confidence:** high | unverified: stack_database
- **Links:** [Devpost](https://devpost.com/software/pcm-3d-printing-kiosk) | [GitHub](https://github.com/Atyrnal/PCMakerspace3DPKiosk ; https://github.com/Atyrnal/card-reader-firmware)

### Amby  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [Hardware] Best Circuit Hack [unknown]  (tier: track_winner)
- **Pitch:** ESP32 noise-level monitor with LED indicators and a dashboard showing quiet spots over time.
- **Problem / user:** People want quiet places to hang out and ways to avoid noise complaints without costly decibel meters. / students, gamers, partygoers
- **Domain / idea type:** social_community / hardware_gadget
- **Platforms / hardware / AI:** hardware; web / True / False
- **Stack:** langs Python; C++; HTML; frontend Jinja; HTML; backend FastAPI; db ; hosting 
- **Tech/APIs:** ESP32 (hardware_part, core); Microphone (hardware_part, core); FastAPI (framework, supporting); Plotly (framework, supporting); Pandas (framework, supporting)
- **Sponsor APIs:**  | fit: Circuit built around an ESP32 microphone input and LEDs.
- **Repo:** private_or_missing, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live none, screenshots 11, writeup medium, impact claims False
- **Notes:** LED colors indicate threshold states; dashboard charts are static Plotly/Matplotlib; multi-location WiFi data collection listed as future work.
- **Team size:** 2 | **Confidence:** high | unverified: repo_clone_failed
- **Links:** [Devpost](https://devpost.com/software/amby) | [GitHub](https://github.com/HumanAri/Amby)

### AR Cube Cannon  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [Hardware] Best Hardware Hack [unknown]  (tier: track_winner)
- **Pitch:** Handheld device with a transparent OLED showing a virtual grid where cubes can be placed or removed, like a block tool gun.
- **Problem / user:** Playful take on placing blocks in real life; no practical problem stated. / makers and gamers
- **Domain / idea type:** entertainment_games + creative_media / hardware_gadget
- **Platforms / hardware / AI:** hardware / True / False
- **Stack:** langs C++; frontend ; backend ; db ; hosting 
- **Tech/APIs:** Arduino (hardware_part, core); Transparent OLED display (hardware_part, core); IMU (hardware_part, core)
- **Sponsor APIs:**  | fit: Physical device with custom body, display and sensors.
- **Repo:** public, commits 2 (before/in/after event: 0/2/0), README none
- **Demo/writeup:** video False, live none, screenshots 12, writeup short, impact claims False
- **Notes:** Built from scrap makerspace parts; IMU position drift forced a pivot to button-based position with orientation; custom 3D cube rendering pipeline.
- **Team size:** 4 | **Confidence:** high | unverified: tech_items_details
- **Links:** [Devpost](https://devpost.com/software/ar-cube-cannon) | [GitHub](https://github.com/Magirush/AR-Cube-Cannon)

### Atlas  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [Software] Best Web Hack [unknown]  (tier: track_winner)
- **Pitch:** Upload images, embed with CLIP, project to 3D with PCA, cluster with k-means and explore the result in an interactive 3D map.
- **Problem / user:** Seeing how images relate semantically is hard in a flat gallery. / people exploring image collections
- **Domain / idea type:** creative_media + ai_agents_infra / data_or_analytics
- **Platforms / hardware / AI:** web / False / vision; predictive_ml; rag_or_search
- **Stack:** langs Python; JavaScript; frontend React; Vite; React Three Fiber; Tailwind CSS; Zustand; backend FastAPI; db Supabase PostgreSQL; hosting 
- **Tech/APIs:** OpenAI CLIP (ai_model, core); scikit-learn (framework, core); React Three Fiber (framework, core); Supabase (database, supporting); Gemini (ai_model, supporting); FastAPI (framework, supporting)
- **Sponsor APIs:**  | fit: Full-stack web app with a Python backend and 3D React frontend.
- **Repo:** public, commits 32 (before/in/after event: 0/22/10), README solid
- **Demo/writeup:** video True, live none, screenshots 1, writeup medium, impact claims False
- **Notes:** Combines kNN graph with an MST for connectivity; chose PCA over UMAP for speed; Gemini mentioned for image descriptions; JWT auth through Supabase.
- **Team size:** 4 | **Confidence:** high
- **Links:** [Devpost](https://devpost.com/software/atlas-5pzm69) | [GitHub](https://github.com/c-aly/Atlas)

### HALO  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [PIT] Best Accessibility Hack [unknown]  (tier: sponsor_winner)
- **Pitch:** A Chrome extension that pauses videos on detecting seizure-risk flashing and offers Gemini summaries with ElevenLabs read-aloud for hard-to-read pages.
- **Problem / user:** Flashing video can trigger photosensitive seizures and dense web text is hard for people with ADHD or dyslexia. / People with photosensitive epilepsy, ADHD, dyslexia or visual impairments
- **Domain / idea type:** accessibility + health_wellness / social_good
- **Platforms / hardware / AI:** browser_extension / False / llm_chat; speech_or_voice
- **Stack:** langs JavaScript; HTML; CSS; frontend Vanilla JS; Manifest V3; backend ; db Chrome storage; hosting 
- **Tech/APIs:** Google Gemini (ai_model, core); ElevenLabs (ai_model, core); Chrome extension API (framework, core); WCAG 2.1 luminance (other, core)
- **Sponsor APIs:**  | fit: Accessibility prize: flash-seizure protection and reading/TTS assistance in one extension.
- **Repo:** public, commits 67 (before/in/after event: 0/60/7), README detailed
- **Demo/writeup:** video False, live none, screenshots 8, writeup long, impact claims True (Cites about 3% of people having photosensitive epilepsy and 12-48x performance gains.)
- **Notes:** Implements WCAG luminance flash detection locally on several video sites, plus a four-strategy text extractor; vanilla JS with no dependencies.
- **Team size:** 3 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/halo-u73r9j) | [GitHub](https://github.com/athulya-anil/Halo)

### healthNET  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [Ethical AI] Most Impactful AI Hack [unknown]  (tier: track_winner)
- **Pitch:** Federated-learning platform letting hospitals train shared models via Flower without sharing raw patient data.
- **Problem / user:** Privacy rules stop hospitals pooling data, leaving models biased and less accurate. / hospitals and medical institutions
- **Domain / idea type:** health_wellness + ai_agents_infra / dev_tool
- **Platforms / hardware / AI:** web / False / predictive_ml
- **Stack:** langs Python; JavaScript; frontend React; backend FastAPI; db ; hosting Vultr
- **Tech/APIs:** Flower (framework, core); Vultr (cloud, core, sponsor); FastAPI (framework, supporting); React (framework, supporting)
- **Sponsor APIs:** Vultr | fit: Used Vultr cloud credits to host the aggregator and train models.
- **Repo:** public, commits 54 (before/in/after event: 0/53/1), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 11, writeup long, impact claims True (Cites an estimate that about 30% of world data volume comes from healthcare.)
- **Notes:** Node servers plus aggregator using FedAvg; dashboards for client training/inference and aggregator; hosted on Vultr credits; cites a market-share statistic.
- **Team size:** 5 | **Confidence:** high
- **Links:** [Devpost](https://devpost.com/software/healthnet-h5o0dx) | [GitHub](https://github.com/HenryLiu714/healthnet)

### Interdict.  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [Software] Best Software Hack [unknown]  (tier: track_winner)
- **Pitch:** SOCKS5 proxy that silently throttles connections to blocklisted sites the longer you use them, to discourage doomscrolling.
- **Problem / user:** Screen-time blockers are visible and easy to dodge; covert slowdowns could build frustration that reduces use. / people trying to cut screen time
- **Domain / idea type:** mental_health + productivity_workplace / new_category
- **Platforms / hardware / AI:** web; other / False / False
- **Stack:** langs Python; frontend Tailwind CSS; backend Flask; db ; hosting 
- **Tech/APIs:** SOCKS5 proxy (other, core); Flask (framework, supporting); Tailwind CSS (framework, supporting)
- **Sponsor APIs:**  | fit: Pure software networking tool, fits the Software track.
- **Repo:** public, commits 52 (before/in/after event: 0/52/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 9, writeup long, impact claims False
- **Notes:** Uses aversive conditioning idea with a configurable throttle formula; only inspects destination, not content; hosted externally so iPhones can connect; pivoted from HTTP/S proxy to SOCKS5.
- **Team size:** 5 | **Confidence:** high | unverified: platforms
- **Links:** [Devpost](https://devpost.com/software/interdict) | [GitHub](https://github.com/theokrueger/interdict)

### minutemesh  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [Cybersecurity] Most Impactful Cybersecurity Hack [unknown]  (tier: sponsor_winner)
- **Pitch:** A pentest tool built on MeshTNC firmware that crafts Meshtastic packets impersonating any sender in channels where the key is known.
- **Problem / user:** Meshtastic channel messages are not signed, so sender identity rests on a spoofable MAC address, enabling undetectable impersonation. / Security researchers and pentesters of Meshtastic mesh radios
- **Domain / idea type:** safety_security + telecom_networking / dev_tool
- **Platforms / hardware / AI:** cli; hardware / True / False
- **Stack:** langs C; C++; JavaScript; frontend ; backend ; db ; hosting 
- **Tech/APIs:** Meshtastic (other, core); MeshTNC firmware (hardware_part, core); LoRa radio (hardware_part, core); AES (other, supporting); Protobuf (framework, supporting); PlatformIO (framework, supporting)
- **Sponsor APIs:**  | fit: Targets the cybersecurity track by demonstrating a working impersonation attack on a mesh radio protocol.
- **Repo:** public, commits 1389 (before/in/after event: 1349/37/3), README detailed
- **Demo/writeup:** video False, live none, screenshots 3, writeup medium, impact claims False
- **Notes:** Integrates a previously published mesh-poisoning cryptography into radio firmware with a CLI; had to preserve protobuf structure when forging packets.
- **Team size:** 2 | **Confidence:** high | unverified: n_screenshots; team_size
- **Links:** [Devpost](https://devpost.com/software/minutemesh) | [GitHub](https://github.com/jordaeday/minutemesh)

### Obscurafy  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [Cybersecurity] Best Data Protection [unknown]  (tier: sponsor_winner)
- **Pitch:** An iOS app that scans your photo library on-device for IDs and cards, letting you swipe to keep, blur or delete each flagged image.
- **Problem / user:** People share or keep photos exposing personal documents without noticing, risking data leaks. / iPhone users with sensitive photos in their library
- **Domain / idea type:** safety_security / twist_on_known_app
- **Platforms / hardware / AI:** mobile_ios / False / vision; llm_chat
- **Stack:** langs Swift; Python; frontend SwiftUI; backend Swift server layer; db ; hosting 
- **Tech/APIs:** YOLOv11 (ai_model, core); CoreML (framework, core); PyTorch (framework, supporting); Gemini API (ai_model, supporting); Apple Photos API (other, core); VisionKit (framework, supporting)
- **Sponsor APIs:**  | fit: Fits the data protection prize via fully on-device detection and redaction before any cloud call.
- **Repo:** public, commits 48 (before/in/after event: 0/47/1), README detailed
- **Demo/writeup:** video False, live not_checked, screenshots 7, writeup long, impact claims False
- **Notes:** Custom YOLOv11 detector trained from eight merged open datasets and converted to CoreML; Tinder-style swipe review; redacts before sending to Gemini for explanations.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish; live_demo_url classification (site link, also a Canva link listed)
- **Links:** [Devpost](https://devpost.com/software/vaulteye) | [GitHub](https://github.com/AlexanderMcGreevy/Obscurafy)

### OceanEye  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [PIT] Best Sustainability Hack [unknown]  (tier: sponsor_winner)
- **Pitch:** A dashboard that detects floating ocean trash with YOLOv8, maps it with satellite data, and plans smoothed cleanup boat routes with Gemini insights.
- **Problem / user:** Ocean plastic cleanup is manual and inefficient, lacking detection, mapping and route planning. / Marine cleanup organizations and researchers
- **Domain / idea type:** sustainability_climate / data_or_analytics
- **Platforms / hardware / AI:** web / False / vision; rag_or_search; llm_chat
- **Stack:** langs Python; TypeScript; frontend Next.js; React; Tailwind CSS; Three.js; backend Flask; db vector store; hosting Netlify; Vultr
- **Tech/APIs:** YOLOv8 (ai_model, core); Google Gemini (ai_model, core); Google Earth Engine (data_source, core); Sentinel-2 (data_source, supporting); OpenCV (framework, supporting); Vultr (cloud, supporting); Netlify (cloud, supporting)
- **Sponsor APIs:**  | fit: Sustainability prize: detection and route planning aimed at reducing cleanup fuel use.
- **Repo:** public, commits 26 (before/in/after event: 0/19/7), README detailed
- **Demo/writeup:** video False, live none, screenshots 5, writeup long, impact claims True (Cites millions of tons of plastic and over 100,000 marine animals harmed yearly as motivation.)
- **Notes:** Combines YOLOv8 segmentation, Earth Engine satellite data, a Gemini RAG pipeline and 2-opt plus Catmull-Rom route optimisation in one dashboard.
- **Team size:** 5 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/oceanhub) | [GitHub](https://github.com/Tirth2116/OceanEye)

### OnePen  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [Ethical AI] Most Novel Use of AI [unknown]  (tier: track_winner)
- **Pitch:** Handwriting note-taking web app where a TensorFlow.js gesture model turns underlines, boxes and circles into formatting and tool actions.
- **Problem / user:** Switching to toolbars interrupts note-taking flow. / students and heavy note-takers
- **Domain / idea type:** productivity_workplace + education / twist_on_known_app
- **Platforms / hardware / AI:** web / False / vision; predictive_ml
- **Stack:** langs JavaScript; Python; frontend HTML Canvas; TensorFlow.js; backend Flask; db IndexedDB; hosting GitHub Pages
- **Tech/APIs:** TensorFlow.js (ai_model, core); Keras (framework, core); Pix2Text (ai_model, supporting); Google Drive API (other, supporting); Flask (framework, supporting)
- **Sponsor APIs:**  | fit: Custom-trained gesture recognition model drives the interface.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 1, writeup long, impact claims False
- **Notes:** Team hand-wrote about 4,000 gesture samples, augmented to 36,000+; includes Pix2Text math recognition, Google Drive sync, IndexedDB autosave; no repo listed.
- **Team size:** 4 | **Confidence:** high
- **Links:** [Devpost](https://devpost.com/software/onepen)

### Pacific  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [Ethical AI] Best Theory and Plan [unknown]  (tier: track_winner)
- **Pitch:** Real-time 2D global-illumination renderer implementing radiance cascades with wgpu compute shaders on a Rust engine.
- **Problem / user:** Real-time ray tracing is noisy and costly; radiance cascades aim for sharp global illumination. / graphics programmers
- **Domain / idea type:** dev_tools + creative_media / other
- **Platforms / hardware / AI:** desktop / False / False
- **Stack:** langs Rust; WGSL; frontend ; backend ; db ; hosting 
- **Tech/APIs:** wgpu (framework, core); V4-Engine (framework, core); WGSL shaders (framework, core)
- **Sponsor APIs:** 
- **Repo:** public, commits 35 (before/in/after event: 0/34/1), README thin
- **Demo/writeup:** video False, live none, screenshots 0, writeup medium, impact claims False
- **Notes:** Implements a recent rendering technique from sparse technical papers; built on a teammate's V4-Engine; currently 2D with 3D in progress; no screenshots on page.
- **Team size:** 3 | **Confidence:** high | unverified: domain_primary
- **Links:** [Devpost](https://devpost.com/software/pacific) | [GitHub](https://github.com/gabefork/pacific)

### PixelParty  (HackUMass XIII)

- **Prizes:** Winner Third Prize [3rd]  (tier: overall_top3)
- **Pitch:** 64x64 LED matrix on a Raspberry Pi that mirrors a shared web drawing canvas in real time.
- **Problem / user:** Online interaction with friends feels remote; a physical shared display makes it feel present. / friends sharing a room display
- **Domain / idea type:** creative_media + social_community / hardware_gadget
- **Platforms / hardware / AI:** web; hardware / True / False
- **Stack:** langs Python; JavaScript; C++; frontend HTML; CSS; JavaScript; backend Flask; db ; hosting 
- **Tech/APIs:** Raspberry Pi 3 B+ (hardware_part, core); Adafruit 64x64 LED matrix (hardware_part, core); rpi-led-matrix (framework, core); Flask (framework, core)
- **Sponsor APIs:** 
- **Repo:** public, commits 8 (before/in/after event: 0/8/0), README detailed
- **Demo/writeup:** video False, live not_checked, screenshots 5, writeup medium, impact claims False
- **Notes:** Drives the Adafruit panel without the usual HAT via rpi-led-matrix; Flask server spawns a separate panel process linked by a pipe; first hackathon for team.
- **Team size:** 4 | **Confidence:** high
- **Links:** [Devpost](https://devpost.com/software/pixelparty) | [GitHub](https://github.com/AshwinSarma21/PixelParty)

### Racing Sim Pedal Set  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [Hardware] Best Mechanical Hack [unknown]  (tier: track_winner)
- **Pitch:** Custom machined racing-sim pedals with hall-effect sensors and load-cell brake feeding a Pico microcontroller.
- **Problem / user:** Makers wanted self-built racing pedals that work as game input. / sim racers
- **Domain / idea type:** entertainment_games / hardware_gadget
- **Platforms / hardware / AI:** hardware / True / False
- **Stack:** langs C; frontend ; backend ; db ; hosting 
- **Tech/APIs:** Raspberry Pi Pico (hardware_part, core); Hall effect sensors (hardware_part, core); Load cells (hardware_part, core)
- **Sponsor APIs:**  | fit: Machined mechanical pedal assembly.
- **Repo:** public, commits 3 (before/in/after event: 0/2/1), README solid
- **Demo/writeup:** video False, live none, screenshots 2, writeup short, impact claims False
- **Notes:** Aluminum and steel parts machined by the team at an ECE makerspace; 20kg load cells noted as too small; finished set works in racing games.
- **Team size:** 2 | **Confidence:** high
- **Links:** [Devpost](https://devpost.com/software/racing-sim-pedal-set) | [GitHub](https://github.com/audtheshaud/racing-sim-pedals)

### Soundbrush  (HackUMass XIII)

- **Prizes:** Winner Grand Prize [1st]  (tier: overall_top3)
- **Pitch:** Drawing web app that plays a synth note and shows a color name for the selected hue, aimed at visually impaired artists.
- **Problem / user:** People with visual impairments cannot easily identify the color they are drawing with. / visually impaired artists
- **Domain / idea type:** accessibility + creative_media / creative_tool
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs JavaScript; CSS; frontend Next.js; React; p5.js; Tone.js; backend ; db ; hosting 
- **Tech/APIs:** p5.js (framework, core); Tone.js (framework, core); Next.js (framework, supporting); Figma (other, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 23 (before/in/after event: 0/23/0), README solid
- **Demo/writeup:** video False, live none, screenshots 8, writeup medium, impact claims False
- **Notes:** Eight synth notes mapped to hue; undo/redo and save/load of sketches; Figma prototype by one member, implemented by the other. Placement 1st inferred from Grand Prize name.
- **Team size:** 2 | **Confidence:** high | unverified: placement
- **Links:** [Devpost](https://devpost.com/software/sound-art-app) | [GitHub](https://github.com/maxdopp/SoundBrush)

### Vault  (HackUMass XIII)

- **Prizes:** [HACKUMASS] [Software] Best Mobile Hack [unknown]  (tier: track_winner)
- **Pitch:** iOS app that blocks chosen apps based on geofenced locations like gyms and dining halls.
- **Problem / user:** People stay glued to their phones in public places. / phone users wanting fewer distractions
- **Domain / idea type:** mental_health + productivity_workplace / twist_on_known_app
- **Platforms / hardware / AI:** mobile_ios / False / False
- **Stack:** langs Swift; frontend ; backend ; db SQLite; hosting 
- **Tech/APIs:** MapKit (maps_geo, core); SQLite (database, supporting)
- **Sponsor APIs:**  | fit: Native iOS app.
- **Repo:** private_or_missing, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live none, screenshots 7, writeup short, impact claims False
- **Notes:** Very short writeup of a few lines; native Swift with MapKit geofencing and SQLite; solo entry.
- **Team size:** 1 | **Confidence:** high | unverified: repo_clone_failed
- **Links:** [Devpost](https://devpost.com/software/vault-mk1l65) | [GitHub](https://github.com/BraedenTurner22/Vault)
