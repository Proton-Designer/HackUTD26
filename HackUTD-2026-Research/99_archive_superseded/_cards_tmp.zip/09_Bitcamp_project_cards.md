# Bitcamp: project cards (19 projects)

Facts and short paraphrases only; no cross-project analysis. Full records are in the workbook and JSONL.

## Bitcamp 2025

### CarbonQapture  (Bitcamp 2025)

- **Prizes:** Best Hack Promoting Public Health - Bloomberg [unknown]  (tier: sponsor_winner)
- **Pitch:** Uses a variational quantum eigensolver simulation plus a neural network to propose metal-organic frameworks for carbon dioxide capture.
- **Problem / user:** The huge design space of porous materials makes finding good CO2-capturing frameworks hard. / materials and climate researchers
- **Domain / idea type:** sustainability_climate + health_wellness / data_or_analytics
- **Platforms / hardware / AI:** web / False / predictive_ml; generative_media
- **Stack:** langs Python; JavaScript; frontend React; backend PyTorch; PennyLane; pandas; NumPy; db ; hosting Vercel
- **Tech/APIs:** PennyLane (framework, core); PyTorch (framework, core); CUDA (other, supporting); React (framework, supporting)
- **Sponsor APIs:**  | fit: Bloomberg public-health framing: page frames impact via carbon capture and climate; no Bloomberg tool used.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 7, writeup long, impact claims True (Claims 98.3 percent ground-state energy prediction accuracy and better CO2 selectivity and uptake than existing frameworks.)
- **Notes:** Quantum VQE (PennyLane, simplified 2-qubit Hamiltonian) feeds a generative neural net; claims 98.3 percent energy prediction accuracy; no GitHub link listed; prize named Public Health though topic is carbon capture.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/carbonqapture)

### Hiding in Plain Sight  (Bitcamp 2025)

- **Prizes:** Best Cybersecurity Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Fast batch tool that detects hidden data in images from LSB and DCT steganography using statistical tests like chi-square and histograms.
- **Problem / user:** Data hidden inside ordinary image files is hard to detect at scale. / security analysts and forensics investigators
- **Domain / idea type:** safety_security / dev_tool
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs Python; JavaScript; frontend ; backend Flask; Pillow; NumPy; SciPy; db ; hosting 
- **Tech/APIs:** Pillow (other, core); NumPy (other, core); SciPy (other, core); Flask (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 46 (before/in/after event: 0/46/0), README solid
- **Demo/writeup:** video True, live none, screenshots 2, writeup short, impact claims False
- **Notes:** Short writeup; includes UI easter eggs; pure statistical analysis with no ML mentioned.
- **Team size:** 3 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/hiding-in-plain-sight) | [GitHub](https://github.com/braynguyen/Hiding-in-Plain-Sight)

### Lighthouse  (Bitcamp 2025)

- **Prizes:** Best Machine Learning Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Solo project that restarts a pretrained diffusion model from a real noisy image to denoise it or generate creative variations via re-noising.
- **Problem / user:** Photos taken in low light are too noisy to use and hard to edit creatively. / photographers and hobbyists
- **Domain / idea type:** creative_media / creative_tool
- **Platforms / hardware / AI:** other / False / generative_media
- **Stack:** langs Python; frontend ; backend PyTorch; db ; hosting 
- **Tech/APIs:** DDPM (ai_model, core); PyTorch (framework, core)
- **Sponsor APIs:** 
- **Repo:** public, commits 15 (before/in/after event: 0/10/5), README detailed
- **Demo/writeup:** video True, live none, screenshots 2, writeup long, impact claims False
- **Notes:** Skips early diffusion timesteps and uses a custom noise scheduler; trained nothing from scratch, ran on a single consumer GPU.
- **Team size:** 1 | **Confidence:** high | unverified: n_screenshots; platforms
- **Links:** [Devpost](https://devpost.com/software/lighthouse-p1cb0k) | [GitHub](https://github.com/dswl/lighthouse/tree/main)

### NeuroScan.AI  (Bitcamp 2025)

- **Prizes:** Best First Time Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Streamlit app that classifies brain tumors from MRI scans with a fine-tuned MobileNetV2 and generates PDF reports with Gemini treatment suggestions.
- **Problem / user:** Early brain tumor diagnosis matters, and clinicians could use accessible AI support for classification and report writing. / medical professionals and patients
- **Domain / idea type:** health_wellness / data_or_analytics
- **Platforms / hardware / AI:** web / False / vision; predictive_ml; llm_chat
- **Stack:** langs Python; frontend Streamlit; backend TensorFlow; OpenCV; FPDF2; db ; hosting Render
- **Tech/APIs:** TensorFlow MobileNetV2 (ai_model, core); Gemini (ai_model, supporting); Streamlit (framework, core); OpenCV (other, supporting); FPDF2 (other, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 19 (before/in/after event: 0/19/0), README detailed
- **Demo/writeup:** video False, live not_checked, screenshots 7, writeup medium, impact claims True (States 92 percent tumor classification accuracy; no independent validation shown.)
- **Notes:** Combines a trained image classifier with an LLM for treatment text and a doctor review section in a generated PDF; claims 92 percent accuracy.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/neuroscan-ai) | [GitHub](https://github.com/anshulg614/NeuroScan.AI)

### QAOA for the kidney exchange problem  (Bitcamp 2025)

- **Prizes:** Best Advanced Quantum Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Solves the kidney exchange (donor chain) optimization with QAOA simulated in PennyLane and compares against classical integer-programming solvers.
- **Problem / user:** Kidney donation chain matching is an integer-programming problem; the team asked whether a quantum algorithm could help. / quantum optimization researchers
- **Domain / idea type:** health_wellness / data_or_analytics
- **Platforms / hardware / AI:** cli / False / False
- **Stack:** langs Python; frontend ; backend OpenQAOA; PennyLane; PuLP; CPLEX; CBC; Matplotlib; db ; hosting 
- **Tech/APIs:** PennyLane (framework, core); OpenQAOA (framework, core); PuLP (other, core); CPLEX (other, supporting); Classiq (other, token)
- **Sponsor APIs:** 
- **Repo:** public, commits 22 (before/in/after event: 0/17/5), README solid
- **Demo/writeup:** video False, live none, screenshots 2, writeup medium, impact claims True (Asserts possible exponential speedup; no numbers given.)
- **Notes:** Limited to datasets under 30 donor-recipient pairs because of simulation cost; claims possible exponential speedup without showing evidence on the page; slides linked instead of a demo.
- **Team size:** 2 | **Confidence:** high | unverified: platforms; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/kidney-donation-chain-integer-programming-with-qaoa) | [GitHub](https://github.com/9t8/quantum_kidney)

### Quanta  (Bitcamp 2025)

- **Prizes:** Best Advanced Quantum Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Simulates stress on thin materials by solving a finite-element system with a quantum HHL algorithm and a classical fallback, rendered as 3D.
- **Problem / user:** CAD tools like Fusion 360 are slow and cannot model nanomaterials for structural stress prediction. / materials engineers and designers
- **Domain / idea type:** other + education / data_or_analytics
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs Python; TypeScript; frontend React; Vite; Tailwind CSS; Three.js; backend Flask; NumPy; Classiq SDK; db ; hosting 
- **Tech/APIs:** Classiq (other, core); Materials Project API (data_source, core); Three.js (framework, supporting); Blender (other, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 61 (before/in/after event: 0/58/3), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 6, writeup long, impact claims False
- **Notes:** Pulls properties from the Materials Project API; quantum part limited to small matrices so a classical solver is also provided; site includes dinosaur-themed easter eggs.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/quanta-obvusa) | [GitHub](https://github.com/chemystery09/quanta)

### Riffs  (Bitcamp 2025)

- **Prizes:** Best App Dev Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Browser tool that turns a hummed melody into notes, maps them to guitar strings and frets, and shows them in an editable piano roll.
- **Problem / user:** Learning guitar and composing feels intimidating because tools rely on robotic MIDI, confusing tabs or studio setups. / beginner guitarists and music creators
- **Domain / idea type:** creative_media + education / creative_tool
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs TypeScript; frontend Next.js; React; Tailwind CSS; backend ; db ; hosting Vercel
- **Tech/APIs:** pitchy (other, core); Next.js (framework, core); FL Studio samples (other, token)
- **Sponsor APIs:** 
- **Repo:** public, commits 78 (before/in/after event: 0/77/1), README solid
- **Demo/writeup:** video True, live not_checked, screenshots 5, writeup medium, impact claims False
- **Notes:** Entirely client-side with no backend; pitch detection in browser; playback not yet integrated though guitar samples were recorded.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/riffs) | [GitHub](https://github.com/cataladev/riffs)


## Bitcamp 2026

### Arcane Shell  (Bitcamp 2026)

- **Prizes:** Best Bitcamp Game Jam Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** First-person wizard game using a Wii Remote as a gesture wand and a 7-inch tablet as a spellbook for crafting spells and mini-games.
- **Problem / user:** Wizard games reduce spellcasting to button presses and lose the feeling of actually casting. / gamers
- **Domain / idea type:** entertainment_games / entertainment_or_game
- **Platforms / hardware / AI:** web; hardware / True / False
- **Stack:** langs TypeScript; frontend Vite; Three.js; backend WebSockets; UDP; db ; hosting 
- **Tech/APIs:** Three.js (framework, core); Wii Remote (hardware_part, core); WiimoteHook (other, core); XInput (other, supporting); Raspberry Pi touchscreen (hardware_part, supporting); MediaPipe (ai_model, unclear)
- **Sponsor APIs:** 
- **Repo:** public, commits 67 (before/in/after event: 0/67/0), README solid
- **Demo/writeup:** video True, live none, screenshots 6, writeup long, impact claims False
- **Notes:** All props, maps, enemies and effects are procedural code with no 3D assets; WiimoteHook UDP bridge for gyro and haptics; 3D-printed grimoire case; builders' first game.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/arcane-shell) | [GitHub](https://github.com/victorliu15/Arcane-Shell)

### BlindSight  (Bitcamp 2026)

- **Prizes:** Best App Dev Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** iPhone indoor navigation for blind users that splits a destination into subgoals with Gemini and guides with LiDAR haptics and spatial audio.
- **Problem / user:** Canes and guide dogs are costly or reactive and lack context to guide someone through complex indoor buildings. / blind and low-vision people
- **Domain / idea type:** accessibility + mobility_transport / social_good
- **Platforms / hardware / AI:** mobile_ios / False / vision; llm_chat
- **Stack:** langs Swift; Python; frontend SwiftUI; backend ARKit; CoreML; PyTorch; db ; hosting 
- **Tech/APIs:** Gemini 3 (ai_model, core); YOLOE (ai_model, core); ARKit (framework, core); CoreHaptics (framework, supporting); AVFoundation (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 3 (before/in/after event: 0/2/1), README detailed
- **Demo/writeup:** video True, live none, screenshots 8, writeup long, impact claims True (Cites roughly 40 million blind people worldwide.)
- **Notes:** Runs on an iPhone 15 Pro with ARKit SLAM, YOLOE exported to CoreML, LiDAR obstacle alerts; thermal throttling handled by sampling frames every second or two.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/blindnav-yzd8fh) | [GitHub](https://github.com/aidenjcheng/blindsight)

### CrisisMatch  (Bitcamp 2026)

- **Prizes:** Best Beginner Data Science Track Hack [unknown]  (tier: track_winner)
- **Pitch:** Live world map of ships and aircraft near disasters, with Claude and Gemini agents assessing severity and auto-matching volunteers to needs.
- **Problem / user:** Crisis news leaves viewers passive; there is no tool turning live disaster data into concrete volunteer action. / volunteers and crisis responders
- **Domain / idea type:** civic_legal + safety_security / automation_or_agent
- **Platforms / hardware / AI:** web / False / llm_chat; agent_or_tool_use
- **Stack:** langs TypeScript; frontend React; Vite; Leaflet; backend Node.js; Express; db ; hosting 
- **Tech/APIs:** Claude (ai_model, core); Gemini (ai_model, core); AISStream (data_source, core); OpenSky (data_source, core); Open-Meteo (data_source, supporting); Yahoo Finance (data_source, token); Auth0 (auth, supporting); Leaflet.js (maps_geo, core); CARTO (maps_geo, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 7 (before/in/after event: 0/7/0), README detailed
- **Demo/writeup:** video False, live none, screenshots 0, writeup medium, impact claims False
- **Notes:** Multiple LLM agents run in parallel to score situation severity; AISStream WebSocket ship feed; volunteer names masked; falls back to backup data when feeds lag.
- **Team size:** 4 | **Confidence:** high | unverified: sponsor flags; n_screenshots; has_demo_video; "three AI models" claim vs listed two
- **Links:** [Devpost](https://devpost.com/software/crisismatch) | [GitHub](https://github.com/Bharathisthe/habibi/tree/crisis-match)

### cryptX by Moonshot  (Bitcamp 2026)

- **Prizes:** Best Financial Hack - Capital One; Best App Dev Track Hack - Bitcamp [unknown]  (tier: sponsor_winner)
- **Pitch:** Arduino hardware crypto wallet for Solana testnet with PIN, seed backup and on-device approval, plus a Gemini fraud monitor and live dashboard.
- **Problem / user:** Hardware wallets cost around $150 and the team wanted secure transaction signing and fraud detection on cheap constrained hardware. / crypto users wanting low-cost hardware signing
- **Domain / idea type:** fintech_finance + safety_security / hardware_gadget
- **Platforms / hardware / AI:** hardware; web / True / agent_or_tool_use; predictive_ml
- **Stack:** langs C++; TypeScript; frontend Next.js; React; Tailwind CSS; backend Web Serial API; Web3.js; db MongoDB; hosting Vercel
- **Tech/APIs:** Arduino Uno (hardware_part, core); Solana (payments, core); Gemini (ai_model, core); Web3.js (framework, core); MongoDB (database, supporting)
- **Sponsor APIs:**  | fit: Capital One financial prize: builds a self-custody wallet and fraud-risk layer; no Capital One API named.
- **Repo:** public, commits 48 (before/in/after event: 0/43/5), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 4, writeup long, impact claims False
- **Notes:** Arduino Uno firmware with SipHash challenge-response, EEPROM state and three-attempt wipe; dashboard talks over Web Serial; Gemini agent auto-blacklists suspicious devices.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/cryptx-zceo69) | [GitHub](https://github.com/navincodesalot/cryptx/)

### Crystal Forge  (Bitcamp 2026)

- **Prizes:** Best Computational Quantum Track Hack [unknown]  (tier: track_winner)
- **Pitch:** Routes quantum lattice simulations to classical or quantum solvers with an ML classifier and plans measurements focused on superconductivity observables.
- **Problem / user:** Lattice simulations need huge computation and much of the measurement budget is wasted on unimportant observables. / quantum materials researchers
- **Domain / idea type:** other + ai_agents_infra / dev_tool
- **Platforms / hardware / AI:** web / False / predictive_ml
- **Stack:** langs Python; JavaScript; frontend React; Vite; backend FastAPI; db ; hosting 
- **Tech/APIs:** FastAPI (framework, supporting); React (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 18 (before/in/after event: 0/14/4), README detailed
- **Demo/writeup:** video False, live none, screenshots None, writeup medium, impact claims True (Reports 85 percent routing accuracy and more than triple hard-sector coverage versus a naive approach.)
- **Notes:** Two components named CorrMap (routing, 85 percent accuracy) and QProbe (measurement planning); pivoted from generic planner to superconductivity-specific channels.
- **Team size:** 3 | **Confidence:** medium | unverified: n_screenshots; domain_primary
- **Links:** [Devpost](https://devpost.com/software/crystal-forge) | [GitHub](https://github.com/Pvphantom/bitcamp2026-crystal-forge)

### eleQt  (Bitcamp 2026)

- **Prizes:** Best Computational Quantum Track Hack [unknown]  (tier: track_winner)
- **Pitch:** Quantum-secure voting protocol using quantum oblivious transfer, QKD and GMW with zero-knowledge proofs, tested on IBM hardware and Qiskit simulation.
- **Problem / user:** Future quantum attacks could break classical election cryptography, so vote tallying needs a trustless, verifiable quantum-safe scheme. / election systems researchers
- **Domain / idea type:** civic_legal + safety_security / new_category
- **Platforms / hardware / AI:** web / False / llm_chat
- **Stack:** langs Python; JavaScript; frontend React; Vite; Tailwind CSS; backend FastAPI; Qiskit; db ; hosting 
- **Tech/APIs:** Qiskit (framework, core); IBM Quantum (cloud, core); Gemini (ai_model, unclear); Claude (ai_model, unclear); FastAPI (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 51 (before/in/after event: 0/49/2), README detailed
- **Demo/writeup:** video True, live none, screenshots 4, writeup medium, impact claims False
- **Notes:** Research-style writeup with motivation, challenges, breakthrough and conclusion; claims implementation on IBM hardware; web demo and slides pictured.
- **Team size:** 3 | **Confidence:** medium | unverified: ai_used; ai_types; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/qrypt) | [GitHub](https://github.com/prakriti-shahi/bitcamp)

### Methods for Computing the ANNNI Model Phase Diagram  (Bitcamp 2026)

- **Prizes:** Best Scientific Quantum Track Hack [unknown]  (tier: track_winner)
- **Pitch:** Quantum-physics project on computing the ANNNI spin-model phase diagram; page only links an external paper-style writeup.
- **Problem / user:** Computing the ANNNI model phase diagram with classical and quantum methods; the page gives no further problem detail. / quantum physics researchers
- **Domain / idea type:** other / data_or_analytics
- **Platforms / hardware / AI:** cli / False / False
- **Stack:** langs Python; frontend ; backend ; db ; hosting 
- **Sponsor APIs:** 
- **Repo:** public, commits 3 (before/in/after event: 0/3/0), README detailed
- **Demo/writeup:** video False, live none, screenshots 1, writeup short, impact claims False
- **Notes:** Devpost page has almost no text and points to an Overleaf writeup; one member notes raising classically solvable size from 8 to 12 spins.
- **Team size:** 2 | **Confidence:** medium | unverified: one_line_pitch; problem_statement; platforms; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/methods-of-computing-the-annni-model-phase-diagram) | [GitHub](https://github.com/9t8/Bitcamp-2026-Quantum)

### MindMirror  (Bitcamp 2026)

- **Prizes:** Best Advanced Data Science Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Analyzes exported ChatGPT/Claude histories with Gemini into a cognitive profile and maps topics to predicted brain activation using Meta's TRIBE v2 model.
- **Problem / user:** People rely heavily on AI chat but have no view of what that dependence reveals about, or does to, their thinking. / heavy AI chat users
- **Domain / idea type:** mental_health + health_wellness / data_or_analytics
- **Platforms / hardware / AI:** web / False / llm_chat; predictive_ml
- **Stack:** langs TypeScript; JavaScript; Python; frontend Next.js; React; Tailwind; Three.js; D3; Recharts; backend FastAPI; Node.js; PyTorch; db ; hosting 
- **Tech/APIs:** Google Gemini (ai_model, core); TRIBE v2 (ai_model, core); Claude (ai_model, token); Next.js (framework, supporting); FastAPI (framework, supporting); PyTorch (framework, supporting); Three.js (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 41 (before/in/after event: 0/20/21), README detailed
- **Demo/writeup:** video True, live none, screenshots 10, writeup long, impact claims False
- **Notes:** Runs text-only TRIBE v2 fMRI-prediction inference in a separate Python service and renders a 3D cortical heatmap; chat export parsed in-browser; also radar chart and topic bubble map.
- **Team size:** 4 | **Confidence:** high | unverified: sponsor flags; n_screenshots; Claude depth
- **Links:** [Devpost](https://devpost.com/software/mindmirror-2aizuh) | [GitHub](https://github.com/Raghav-Chakravarthy/MindMirror)

### QuantumQuest QCNN  (Bitcamp 2026)

- **Prizes:** Best Scientific Quantum Track Hack [unknown]  (tier: track_winner)
- **Pitch:** Quantum convolutional neural network that classifies Hamiltonian parameters into phases, built with JAX and PennyLane.
- **Problem / user:** Classify quantum many-body phases from Hamiltonian parameters; the writeup is sparse and points to a separate document. / quantum physics researchers
- **Domain / idea type:** other + ai_agents_infra / data_or_analytics
- **Platforms / hardware / AI:** cli / False / predictive_ml
- **Stack:** langs Python; frontend ; backend JAX; PennyLane; Optax; db ; hosting 
- **Tech/APIs:** PennyLane (framework, core); JAX (framework, core); Optax (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live none, screenshots 12, writeup short, impact claims False
- **Notes:** Writeup is placeholder-style and tells readers to read an external linked document; code is on Codeberg, not GitHub.
- **Team size:** 3 | **Confidence:** medium | unverified: one_line_pitch; problem_statement; platforms; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/quantumquest-qcnn)

### Sleeply  (Bitcamp 2026)

- **Prizes:** Best First Time Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Interactive sleep visualizer that models a night from user inputs and shows stage timeline, 3D brain activity, brainwave graphs and a sleep score.
- **Problem / user:** Brain activity during sleep is hard to picture, and sleep visualization tools are not intuitive or free. / general users curious about sleep and brainwaves
- **Domain / idea type:** health_wellness + education / creative_tool
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs ; frontend React; Vite; Three.js; React Three Fiber; backend ; db ; hosting Vercel
- **Tech/APIs:** Three.js (framework, core); React Three Fiber (framework, core); React (framework, core)
- **Sponsor APIs:** 
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 6, writeup long, impact claims False
- **Notes:** Solo build with 18 color themes and a tutorial; sleep is simulated from questionnaire inputs rather than measured; no repo listed.
- **Team size:** 1 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/sleeply)

### Terrametric  (Bitcamp 2026)

- **Prizes:** Real World Prize - Ambrook; Best Champion of Open Source w/ Featherless - Featherless; Best Intermediate Data Science Track Hack - Bitcamp [unknown]  (tier: sponsor_winner)
- **Pitch:** Farm console that scores crop stress from satellite signals, forecasts yield and losses, and prescribes irrigation, with a Qwen-based agronomy copilot.
- **Problem / user:** Satellite data can flag crop stress weeks early but does not reach farmers as timely, actionable decisions. / farmers and agronomists
- **Domain / idea type:** sustainability_climate + fintech_finance / data_or_analytics
- **Platforms / hardware / AI:** web / False / predictive_ml; llm_chat; agent_or_tool_use; rag_or_search
- **Stack:** langs Python; TypeScript; GLSL; frontend Next.js; React; backend FastAPI; Uvicorn; XGBoost; db SQLite; hosting Vercel
- **Tech/APIs:** XGBoost (ai_model, core); Qwen 2.5 (ai_model, core, sponsor); NASA SMAP (data_source, core); USDA extension reports (data_source, supporting); FastAPI (framework, supporting)
- **Sponsor APIs:** Featherless | fit: Open-source Qwen 2.5 powers the agronomy copilot (Featherless prize); page does not name Featherless itself.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots None, writeup medium, impact claims False
- **Notes:** Fuses optical indices with NASA SMAP radar-based soil moisture to handle cloud cover; XGBoost stress model then a dollar-loss model; 3D globe; copilot has 11 tools. No repo listed.
- **Team size:** 3 | **Confidence:** medium | unverified: n_screenshots; sponsor_apis_used
- **Links:** [Devpost](https://devpost.com/software/terrametric)

### Tseda  (Bitcamp 2026)

- **Prizes:** Best Machine Learning Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Generates novel drug-candidate compounds from a described disease or molecule, then scores candidates for risk with a fine-tuned ML model and an in-browser chemical editor.
- **Problem / user:** Preclinical drug design and synthesis planning is slow, repetitive and costly, with no guarantee a candidate is useful. / drug discovery researchers
- **Domain / idea type:** health_wellness + ai_agents_infra / dev_tool
- **Platforms / hardware / AI:** web / False / llm_chat; predictive_ml
- **Stack:** langs TypeScript; Python; frontend React; Next.js; Tailwind; ChemDoodle; backend Python; db ; hosting 
- **Tech/APIs:** Anthropic Claude API (ai_model, core); Google Gemini (ai_model, supporting); MLM-FG (ai_model, core); ChemBERTa (ai_model, unclear); ChemDoodle (other, core); Google Stitch (other, token); Next.js (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 89 (before/in/after event: 0/89/0), README detailed
- **Demo/writeup:** video False, live none, screenshots 8, writeup long, impact claims True (Says one drug costs billions and decades, with over a third of resources going to preclinical work.)
- **Notes:** Pairs LLM compound generation with MLM-FG risk indicators and a ChemDoodle drawing canvas with MOL import; team swapped from ChemBERTa after it lacked needed indicators.
- **Team size:** 4 | **Confidence:** high | unverified: sponsor flags; n_screenshots; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/tseda) | [GitHub](https://github.com/LittleWhole/Tseda)
