# UC Berkeley AI Hackathon: project cards (13 projects)

Facts and short paraphrases only; no cross-project analysis. Full records are in the workbook and JSONL.

## UC Berkeley AI Hackathon 2025

### Cameron  (UC Berkeley AI Hackathon 2025)

- **Prizes:** GRAND PRIZE - Creativity Track [unknown]; Nobel Era Group: Best Projects Leveraging LLM Agents Supported by Nobel Era Group & Berkeley RDI [unknown]  (tier: track_winner)
- **Pitch:** No-code camera orchestration: describe what to watch for, and a node-graph workflow with in-browser vision models and LLM reasoning sends alerts or voice calls.
- **Problem / user:** Cameras only record; monitoring tasks need a loop of observe, interpret and act without constant human review. / operators of cameras in warehouses, retail, elder care
- **Domain / idea type:** ai_agents_infra + safety_security / automation_or_agent
- **Platforms / hardware / AI:** web / False / vision; agent_or_tool_use; llm_chat; speech_or_voice
- **Stack:** langs TypeScript; frontend React 19; Tailwind CSS; React Router; ONNX Runtime Web; backend ; db LocalStorage; hosting 
- **Tech/APIs:** YOLOv8 (ONNX) (ai_model, core); ArcFace (ONNX) (ai_model, supporting); Google Gemini (ai_model, core); Letta + Groq (ai_model, core); Claude MCP (ai_model, supporting); Vapi (telecom, supporting); EmailJS (other, supporting); OpenCV (framework, supporting)
- **Sponsor APIs:** Letta; Groq; Vapi; Claude / MCP | fit: Uses Letta and Groq for LLM control flow and Claude MCP to coordinate multiple agents, matching the Nobel Era Group/Berkeley RDI LLM-agents prize theme.
- **Repo:** private_or_missing, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live none, screenshots 9, writeup long, impact claims False
- **Notes:** Runs YOLOv8 and ArcFace via ONNX in the browser; workflows are visual node graphs generated from natural language or speech; alerts through Vapi voice calls and EmailJS.
- **Team size:** 4 | **Confidence:** medium | unverified: sponsor_apis_used; has_demo_video; repo_clone_failed
- **Links:** [Devpost](https://devpost.com/software/cameron-9biv60) | [GitHub](https://github.com/ezpedersen/smartcam)

### ChipChat  (UC Berkeley AI Hackathon 2025)

- **Prizes:** GRAND PRIZE - Productivity and Dev Tools Track [unknown]  (tier: track_winner)
- **Pitch:** Natural-language or sketch-to-chip tool: Gemini and a Letta agent write Verilog, then Yosys, OpenLane and DigitalJS produce schematics and a fab-ready GDS file.
- **Problem / user:** Hardware design is slow and hard to learn; students and engineers struggle with Verilog and abstract diagrams. / electronics students and chip designers
- **Domain / idea type:** dev_tools + education / dev_tool
- **Platforms / hardware / AI:** web / False / llm_chat; agent_or_tool_use; vision
- **Stack:** langs TypeScript; Python; Verilog; JavaScript; frontend React; Vite; DigitalJS; backend Node.js; Python; db ; hosting Vercel; Render
- **Tech/APIs:** Google Gemini (ai_model, core); Letta (framework, core); Yosys (framework, core); OpenLane (framework, core); DigitalJS (framework, core); KLayout (framework, supporting); Docker (cloud, supporting)
- **Sponsor APIs:** Letta
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live not_checked, screenshots 2, writeup long, impact claims False
- **Notes:** Takes the whole flow from prompt or hand-drawn sketch to GDS layout; the team wrote a custom parser from synthesized Verilog to DEF; chat assistant explains the generated design.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; sponsor_apis_used; team_size
- **Links:** [Devpost](https://devpost.com/software/chitchat-5omgjw)

### pFOG: Parkinson's Medical Aid Device  (UC Berkeley AI Hackathon 2025)

- **Prizes:** GRAND PRIZE - Social Impact Track [unknown]; Cal Hacks: Hacker's Choice [unknown]  (tier: track_winner)
- **Pitch:** Wearable that predicts Parkinson's freezing of gait from IMU data with a CNN-LSTM and triggers a servo 'poke' stimulation, plus a web tool to label data and fine-tune.
- **Problem / user:** Parkinson's patients suffer sudden freezing of gait; a family's manual leg poke helped, inspiring an automated version. / Parkinson's patients with freezing of gait
- **Domain / idea type:** health_wellness + accessibility / hardware_gadget
- **Platforms / hardware / AI:** hardware; web / True / predictive_ml
- **Stack:** langs Python; frontend Next.js; React; backend Flask; db ; hosting Google Cloud
- **Tech/APIs:** PyTorch 1D-CNN + LSTM (ai_model, core); Adafruit MPU-6050 IMU (hardware_part, core); ESP32 (hardware_part, core); Servo-actuated arm (hardware_part, core); Flask (framework, supporting); Google Cloud (cloud, unclear)
- **Sponsor APIs:** 
- **Repo:** public, commits 58 (before/in/after event: 0/57/1), README detailed
- **Demo/writeup:** video None, live none, screenshots 3, writeup medium, impact claims True (Claims over 90% accuracy detecting freezing episodes on the prototype.)
- **Notes:** Working prototype with MPU-6050 sensor, ESP32 and servo-actuated arm; team 3D-printed parts using another team's printer; per-patient fine-tuning via a web labeling interface.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; stack_hosting
- **Links:** [Devpost](https://devpost.com/software/foggy) | [GitHub](https://github.com/harryyuncheng/parkinsons-fog-device)


## UC Berkeley AI Hackathon 2026

### FirstResponder-Relay  (UC Berkeley AI Hackathon 2026)

- **Prizes:** Finalist [unknown]  (tier: honorable_or_finalist)
- **Pitch:** Multilingual AI overflow dispatcher: callers speak any language, Claude triages urgency and checks wildfire perimeters, dispatchers reply in English that is translated back as voice.
- **Problem / user:** Emergency dispatchers cannot cover many languages during disasters when call volume spikes. / 911 dispatchers and non-English-speaking callers
- **Domain / idea type:** safety_security + accessibility / automation_or_agent
- **Platforms / hardware / AI:** web / False / llm_chat; speech_or_voice; agent_or_tool_use
- **Stack:** langs Python; TypeScript; frontend Next.js; React; Tailwind CSS; Mapbox GL JS; backend FastAPI; WebSockets; db Redis Cloud; hosting Vercel; ngrok
- **Tech/APIs:** Claude Sonnet 4.6 (ai_model, core); Deepgram Nova-3 (ai_model, core); Deepgram Aura-2 (ai_model, supporting); Mapbox (maps_geo, core); Shapely (framework, supporting); Redis (database, supporting); Arize AX (other, supporting)
- **Sponsor APIs:** 
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video False, live not_checked, screenshots 2, writeup medium, impact claims True (Cites 2018 Camp Fire call volume and Bay Area language statistics, plus its own eval accuracy numbers.)
- **Notes:** Reports a 30-case eval (90% urgency, 100% language and address accuracy) and tests 13 languages; Claude traces streamed to Arize; callers join via QR code.
- **Team size:** 1 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/firstresponder-relay)

### Inspector  (UC Berkeley AI Hackathon 2026)

- **Prizes:** Finalist [unknown]; Hacker's Choice Award [unknown]  (tier: honorable_or_finalist)
- **Pitch:** MCP server that lets coding agents autonomously test their own apps via computer use in cloud sandboxes, with parallel region agents and verified bug reports.
- **Problem / user:** AI coding agents hand back untested code, leaving developers to act as QA and report bugs manually. / developers using coding agents such as Claude Code or Cursor
- **Domain / idea type:** dev_tools + ai_agents_infra / dev_tool
- **Platforms / hardware / AI:** web; cli; desktop / False / agent_or_tool_use; vision; llm_chat
- **Stack:** langs Python; TypeScript; frontend Next.js; React; Tailwind CSS; Framer Motion; backend FastMCP; httpx; Pydantic; db ; hosting E2B sandboxes
- **Tech/APIs:** Anthropic Claude API (ai_model, core); FastMCP (framework, core); E2B Desktop sandbox (cloud, core); OmniParser (YOLOv8 + Florence-2) (ai_model, core); Replicate API (ai_model, supporting); Devin (other, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 95 (before/in/after event: 0/60/35), README detailed
- **Demo/writeup:** video True, live none, screenshots 8, writeup long, impact claims True (Cites a claimed 41% rise in bug rates with AI coding agents as motivation; no measured results.)
- **Notes:** Splits the UI into regions with OmniParser, runs one agent per region, and confirms each finding by independent replay; supports web, Electron, Android and iOS; dashboard can hand bugs to Devin.
- **Team size:** 2 | **Confidence:** high | unverified: ui_polish; team_size
- **Links:** [Devpost](https://devpost.com/software/inspector-23ser6) | [GitHub](https://github.com/wlu03/LoopBack)

### IronBook  (UC Berkeley AI Hackathon 2026)

- **Prizes:** GRAND PRIZE - Ddoski's Toolbox Track [unknown]; Finalist [unknown]  (tier: track_winner)
- **Pitch:** Photograph a machine from many angles to build a 3D Gaussian splat, then ask a Claude agent that flies the camera and highlights parts, to capture retiring experts' knowledge.
- **Problem / user:** Retiring skilled manufacturing workers take undocumented know-how with them, and apprenticeships are too slow. / manufacturing technicians and shop-floor trainers
- **Domain / idea type:** productivity_workplace + ai_agents_infra / new_category
- **Platforms / hardware / AI:** web / False / vision; agent_or_tool_use; speech_or_voice
- **Stack:** langs Python; TypeScript; frontend React 18; Vite; WebGL2; backend FastAPI; Uvicorn; db MongoDB; hosting 
- **Tech/APIs:** Claude (vision, structured output) (ai_model, core); COLMAP (framework, core); msplat (Metal 3DGS) (framework, core); Deepgram (ai_model, supporting); Sentry (other, supporting); Langfuse (other, supporting); depth-anything ONNX (ai_model, supporting)
- **Sponsor APIs:** Deepgram; Sentry; Langfuse
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live none, screenshots None, writeup long, impact claims True (Cites retirement and workforce-gap statistics (e.g. 4.1M workers retiring by 2027, 584,000 unfilled jobs).)
- **Notes:** Custom WebGL2 Gaussian-splat renderer; Claude sees a live viewport screenshot and returns camera actions; three-tier reconstruction fallback (COLMAP/msplat, MLX, depth-anything); 77 tests claimed.
- **Team size:** 3 | **Confidence:** medium | unverified: sponsor_apis_used; stack_database; has_demo_video; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/ironbook)

### Lucid Voice  (UC Berkeley AI Hackathon 2026)

- **Prizes:** GRAND PRIZE - Ddoski's World Track [unknown]; Finalist [unknown]  (tier: track_winner)
- **Pitch:** Offline AAC tool that turns two or three tapped words into a full sentence in the user's own cloned voice, using an on-device knowledge graph and local Gemma model.
- **Problem / user:** People with ALS, stroke or aphasia have slow, robotic communication tools that do not know who they are talking to. / people who cannot rely on their own speech (AAC users)
- **Domain / idea type:** accessibility + health_wellness / social_good
- **Platforms / hardware / AI:** web; desktop / False / llm_chat; speech_or_voice; rag_or_search; recommendation
- **Stack:** langs Python; TypeScript; JavaScript; frontend React; Vite; Tailwind CSS; Framer Motion; react-force-graph; backend FastAPI; db Kuzu; Redis; hosting 
- **Tech/APIs:** Gemma via MLX (ai_model, core); Coqui XTTS (ai_model, core); Whisper / faster-whisper (ai_model, core); Kuzu graph database (database, core); Redis (database, supporting); Deepgram (ai_model, token); Sentry (other, token); Arize Phoenix (other, supporting); Claude Code (other, token)
- **Sponsor APIs:** Redis; Deepgram; Sentry; Arize Phoenix
- **Repo:** public, commits 42 (before/in/after event: 0/42/0), README detailed
- **Demo/writeup:** video None, live none, screenshots 5, writeup long, impact claims True (Cites about 5 million Americans and nearly 100 million people worldwide who cannot rely on their own voice.)
- **Notes:** Runs fully on-device and offline on Apple Silicon: Kuzu knowledge graph, Gemma via MLX, XTTS voice cloning, Whisper; visible learning graph; interview mode to cold-start the profile.
- **Team size:** 2 | **Confidence:** medium | unverified: sponsor_apis_used; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/lucid-voice) | [GitHub](https://github.com/dbhargav-uw/Lucid-Voice)

### Paper Cuts  (UC Berkeley AI Hackathon 2026)

- **Prizes:** GRAND PRIZE - Ddoski's Playground Track [unknown]; Finalist [unknown]; Best UI/UX [unknown]  (tier: track_winner)
- **Pitch:** Draw on an iPad or browser and your doodles are recognized, restyled into sprites and given game mechanics, then dropped into a live phone-controlled platform fighter.
- **Problem / user:** Most people only consume games; making one requires a complex engine, so the team wanted creation to feel like drawing on paper. / kids and casual creators
- **Domain / idea type:** entertainment_games + creative_media / creative_tool
- **Platforms / hardware / AI:** web; mobile_cross / False / vision; generative_media; rag_or_search; llm_chat
- **Stack:** langs Python; JavaScript; frontend React; Vite; tldraw; HTML5 Canvas; backend FastAPI; Node.js; db Redis Stack (RediSearch HNSW); hosting AWS Trainium
- **Tech/APIs:** Redis Stack vector search (database, core, sponsor); Stable Diffusion / InstructPix2Pix (ai_model, core); Pika via fal.ai (ai_model, supporting); AWS Trainium (cloud, supporting); rembg / BiRefNet (ai_model, supporting); OpenAI (ai_model, unclear); tldraw (framework, supporting)
- **Sponsor APIs:** Redis; fal.ai; AWS Trainium | fit: Page labels Redis as a sponsor track and uses RediSearch HNSW as the doodle memory powering retrieval-augmented recognition.
- **Repo:** public, commits 148 (before/in/after event: 0/148/0), README detailed
- **Demo/writeup:** video None, live none, screenshots 7, writeup long, impact claims False
- **Notes:** Multi-model stack: CNN plus VLM plus Redis vector retrieval for recognition, a trained image-to-image sprite model, neuro-symbolic mechanic composer, generative KO videos; phones act as gamepads or pens via QR.
- **Team size:** 3 | **Confidence:** medium | unverified: sponsor_apis_used; has_demo_video; stack_hosting
- **Links:** [Devpost](https://devpost.com/software/paper-cuts) | [GitHub](https://github.com/Jeremyliu-621/paper-cuts)

### Percept  (UC Berkeley AI Hackathon 2026)

- **Prizes:** Finalist [unknown]  (tier: honorable_or_finalist)
- **Pitch:** Self-improving video ad loop: researches, generates short ads with Pika, predicts attention with TRIBE v2, and rewrites one creative lever per round using Redis memory.
- **Problem / user:** Small businesses spend ad budget before learning which video works; dashboards show failure but not why attention dropped. / small business owners running short-form video ads
- **Domain / idea type:** creative_media + retail_consumer / creative_tool
- **Platforms / hardware / AI:** web / False / generative_media; agent_or_tool_use; predictive_ml; rag_or_search; vision
- **Stack:** langs TypeScript; Python; frontend ; backend Node.js; db Redis; Supabase; hosting Vercel
- **Tech/APIs:** Pika MCP (ai_model, core, sponsor); Redis (database, core, sponsor); TRIBE v2 (ai_model, core); Claude (ai_model, supporting); FFmpeg (framework, supporting); OpenCV (framework, supporting); YOLO (ai_model, unclear); Supabase (database, unclear)
- **Sponsor APIs:** Pika; Redis
- **Repo:** public, commits 113 (before/in/after event: 0/113/0), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 4, writeup long, impact claims False
- **Notes:** Scores ads from a predicted neural-response time series (TRIBE v2) turned into a custom attention score; limits each rewrite to one lever; admits score is a proxy not campaign performance.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/cerebra-diqop9) | [GitHub](https://github.com/edrlu/Percept)

### Sentinel  (UC Berkeley AI Hackathon 2026)

- **Prizes:** Finalist [unknown]  (tier: honorable_or_finalist)
- **Pitch:** Multi-agent security scanner for AI-built apps that reproduces exploits in sandboxes, explains findings plainly, and opens pull requests with fixes.
- **Problem / user:** Founders shipping AI-generated apps do not know if they are secure, and traditional scanners give jargon and false positives. / indie hackers, founders and student developers
- **Domain / idea type:** safety_security + dev_tools / dev_tool
- **Platforms / hardware / AI:** web / False / agent_or_tool_use; llm_chat
- **Stack:** langs TypeScript; JavaScript; Shell; HTML; CSS; frontend Next.js; backend Cloudflare Workers; Durable Objects; Prisma; db PostgreSQL; Upstash Redis; hosting Cloudflare; Vercel
- **Tech/APIs:** Browserbase (cloud, core, sponsor); Anthropic models (ai_model, core); OpenAI models (ai_model, supporting); Fetch.ai (other, unclear, sponsor); Redis (database, supporting, sponsor); Sentry (other, token, sponsor); Arize AI (other, token, sponsor); Cloudflare Workers (cloud, supporting)
- **Sponsor APIs:** Browserbase; Fetch.ai; Redis; Sentry; Arize
- **Repo:** public, commits 12 (before/in/after event: 0/12/0), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 0, writeup long, impact claims False
- **Notes:** Only escalates findings that are reproduced in an isolated Browserbase sandbox; specialized agents (secrets, auth, injection, rate limit, supply chain) plus coordinator and validator; auto-PR patches.
- **Team size:** 2 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/sentinel-poyh3v) | [GitHub](https://github.com/sudarshan-krishnan/Sentinel_AIHackathon_Berkley_2026)

### SnapCycle  (UC Berkeley AI Hackathon 2026)

- **Prizes:** Finalist [unknown]  (tier: honorable_or_finalist)
- **Pitch:** Photo-based app that identifies a bulky item, ranks local disposal options, and has an agent schedule donation, pickup or hauler quotes.
- **Problem / user:** Students moving out cannot easily find cheap, legitimate ways to dispose of bulky items. / college students moving out
- **Domain / idea type:** sustainability_climate + retail_consumer / automation_or_agent
- **Platforms / hardware / AI:** web; mobile_cross / False / vision; rag_or_search; agent_or_tool_use
- **Stack:** langs Python; frontend ; backend Node.js; db Redis; vector store; hosting 
- **Tech/APIs:** Gemini 2.5 Flash (ai_model, core, sponsor); Browserbase (cloud, core, sponsor); Simular (other, core, sponsor); Twilio (telecom, core, sponsor); Redis (database, supporting, sponsor); Arize (other, supporting, sponsor); Sentry (other, token, sponsor); Playwright (framework, supporting)
- **Sponsor APIs:** Browserbase; Simular; Twilio; Redis; Arize; Sentry
- **Repo:** public, commits 32 (before/in/after event: 0/32/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 2, writeup long, impact claims True (Own survey of 87 people: 89% unaware of disposal services, 58% would use one if aware.)
- **Notes:** Browserbase crawls local ordinances into a RAG store; Simular action agent fills forms and Twilio messages three haulers whose quotes stream in sorted; team cites its own 87-person survey.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/rrr-s98zwc) | [GitHub](https://github.com/prithsk/RRR)

### StudForge  (UC Berkeley AI Hackathon 2026)

- **Prizes:** Finalist [unknown]  (tier: honorable_or_finalist)
- **Pitch:** Turns a text or voice prompt into a validated, brick-based multi-robot simulation scene, exported to USD and other formats, with observer agents feeding memory back.
- **Problem / user:** Multi-robot sim scenes are hand-built or hallucinated by generative models with no guarantee they are collision-free or connected. / robotics researchers and simulation designers
- **Domain / idea type:** ai_agents_infra + creative_media / dev_tool
- **Platforms / hardware / AI:** web; cli / False / llm_chat; agent_or_tool_use; speech_or_voice; generative_media; other
- **Stack:** langs Python; frontend ; backend FastAPI; Pydantic; Typer; db Redis Cloud; hosting AWS EC2
- **Tech/APIs:** Claude (ai_model, core); Midjourney MCP (ai_model, supporting, sponsor); Deepgram Nova-3 (ai_model, supporting, sponsor); Redis Cloud (database, core, sponsor); Qwen2.5-1.5B (ai_model, supporting); PyTorch (framework, supporting); AWS EC2 / Trainium (cloud, supporting, sponsor)
- **Sponsor APIs:** Midjourney; Deepgram; Redis; AWS
- **Repo:** public, commits 62 (before/in/after event: 0/62/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 2, writeup long, impact claims False
- **Notes:** Generative models (Claude, Midjourney, Deepgram) are strictly advisory behind a validator; fine-tuned Qwen2.5-1.5B with LoRA after a Trainium instance shut down mid-event; Redis-backed agent memory.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/studforge) | [GitHub](https://github.com/kokonut121/studsim)

### Theracat  (UC Berkeley AI Hackathon 2026)

- **Prizes:** GRAND PRIZE - Ddoski's Lab Track [unknown]; Finalist [unknown]; SkyDeck Grand Prize Winner [unknown]  (tier: track_winner)
- **Pitch:** Wristband with accelerometer detects rising agitation and delivers paced haptic breathing, paired with a plush cat that moves its ears and speaks grounding prompts.
- **Problem / user:** During panic attacks people cannot operate phones or apps, so help needs to arrive without any action from them. / people with anxiety and panic attacks, including children
- **Domain / idea type:** mental_health + health_wellness / hardware_gadget
- **Platforms / hardware / AI:** hardware / True / predictive_ml; llm_chat; speech_or_voice
- **Stack:** langs Python; C++/Arduino; frontend ; backend ; db ; hosting 
- **Tech/APIs:** ESP32 (hardware_part, core); MPU6050 IMU (hardware_part, core); Haptic and ear motors (hardware_part, core); Bluetooth Low Energy (other, core); Claude (ai_model, core); ElevenLabs (ai_model, core); Random Forest classifier (ai_model, core)
- **Sponsor APIs:** ElevenLabs
- **Repo:** public, commits 26 (before/in/after event: 0/19/7), README detailed
- **Demo/writeup:** video None, live none, screenshots 14, writeup long, impact claims True (Cites prevalence stats (about 40M adults with anxiety, 1 in 11 with a panic attack yearly) and published model accuracies.)
- **Notes:** Built by a former clinician; ESP32 plus MPU6050 over BLE; classifier prototype uses synthetic accelerometer data and Random Forest; ElevenLabs voice with Claude and routing to 988; ear-moving plush.
- **Team size:** 4 | **Confidence:** medium | unverified: stack_languages; sponsor_apis_used; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/theracat) | [GitHub](https://github.com/emilyLi2020/Theracat)
