# UNIHACK: project cards (12 projects)

Facts and short paraphrases only; no cross-project analysis. Full records are in the workbook and JSONL.

## UNIHACK 2025

### Crevo  (UNIHACK 2025)

- **Prizes:** First Timers' Prize [unknown]  (tier: track_winner)
- **Pitch:** AI video editor that detects who is speaking, auto-frames the video on them and adds live captions and translation.
- **Problem / user:** Manually editing speaker framing, cuts and subtitles takes creators hours. / podcasters, creators, educators
- **Domain / idea type:** creative_media + accessibility / creative_tool
- **Platforms / hardware / AI:** web / False / vision; speech_or_voice
- **Stack:** langs Python; TypeScript; frontend Next.js; Figma; backend Flask; db ; hosting 
- **Tech/APIs:** MediaPipe (ai_model, core); PyAnnote (ai_model, core); Vosk / Kaldi (ai_model, core); MoviePy (framework, supporting); Flask (framework, core)
- **Sponsor APIs:** 
- **Repo:** None, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live none, screenshots 9, writeup long, impact claims False
- **Notes:** Combines MediaPipe mouth-movement detection with PyAnnote speaker labels to cut false speaker detections; Vosk/Kaldi for real-time subtitles; exports mp4 plus .srt. Page link slot shows Figma, no live site.
- **Team size:** 5 | **Confidence:** high | unverified: github_url (page lists a repo but URL not captured); tech_items.is_sponsor; prize placement n/a; demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/ocuvid)

### Growth Garden  (UNIHACK 2025)

- **Prizes:** First place [1st]  (tier: overall_top3)
- **Pitch:** Habit app where an AI assistant sets personal routines and finished tasks grow items in a 3D planet garden.
- **Problem / user:** Habit tools are siloed by domain or just block bad habits; users lack a personalised plan toward their own goals. / people building personal habits
- **Domain / idea type:** mental_health + productivity_workplace / twist_on_known_app
- **Platforms / hardware / AI:** web / False / llm_chat; agent_or_tool_use
- **Stack:** langs TypeScript; frontend Next.js; React; three.js; backend Langflow (DataStax); db ; hosting Jenkins CI/CD
- **Tech/APIs:** Langflow / DataStax (ai_model, core); Next.js (framework, core); three.js (framework, core); Jenkins (other, supporting)
- **Sponsor APIs:** 
- **Repo:** None, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live not_checked, screenshots 5, writeup long, impact claims True (Cites a fivefold rise in mental illness among preteen girls since Snapchat as motivation.)
- **Notes:** Three.js planet garden with items snapping to the surface using hand-written vector maths, dynamic ambient audio mixing, Langflow (DataStax) backend; half the team first-timers.
- **Team size:** 6 | **Confidence:** high | unverified: github_url (page lists a repo but URL not captured); ai_types; domain_secondary; tech_items.is_sponsor; event dates from Monash/DigitalReviews articles; demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/growth-garden)

### Shuffl  (UNIHACK 2025)

- **Prizes:** Second place [2nd]  (tier: overall_top3)
- **Pitch:** Smart card-game table mixing in-person and online players, with Arduino NFC card scanning, voice input and an AI strategy advisor, built accessibility-first.
- **Problem / user:** Friends can't always play together, beginners feel intimidated, and visually impaired players are poorly served by card games. / card-game players incl. visually impaired
- **Domain / idea type:** accessibility + entertainment_games / hardware_gadget
- **Platforms / hardware / AI:** web; hardware / True / llm_chat; speech_or_voice
- **Stack:** langs Java; TypeScript; C; frontend Next.js 14; Tailwind CSS; ShadCN; backend Spring Boot; WebSocket/STOMP; db ; hosting Azure Container Apps; Docker; GitHub Actions
- **Tech/APIs:** Azure Speech Recognition (ai_model, core); GPT-4o mini (ai_model, core); Arduino Uno (hardware_part, core); PN532 NFC module (hardware_part, core); Spring Boot (framework, core); Azure (cloud, supporting); Docker (other, supporting)
- **Sponsor APIs:** 
- **Repo:** None, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live not_checked, screenshots 6, writeup long, impact claims False
- **Notes:** Arduino Uno with PN532 NFC readers mapping card UIDs; Azure custom speech; Spring Boot WebSocket backend; tested screen reader support with a visually impaired friend. Monash article lists Weave as 2nd and Shuffl 3rd; Devpost badge says Second.
- **Team size:** 6 | **Confidence:** high | unverified: github_url (page lists a repo but URL not captured); tech_items.is_sponsor; placement order conflicts with Monash article; demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/shuffl-4rzu3c)

### Weave  (UNIHACK 2025)

- **Prizes:** Third place [3rd]  (tier: overall_top3)
- **Pitch:** Upload your wardrobe and see outfits on a mannequin or your own photo via AI virtual try-on, then save and share looks.
- **Problem / user:** Trying on clothes is a hassle, especially for people with mobility limits, and picking outfits causes decision fatigue. / people planning outfits, incl. those with mobility limits
- **Domain / idea type:** retail_consumer + accessibility / twist_on_known_app
- **Platforms / hardware / AI:** web / False / generative_media; vision
- **Stack:** langs Go; TypeScript; frontend Next.js; Tailwind CSS; ShadCN; backend Go; db Amazon S3; hosting Coolify; Docker; AWS Lambda
- **Tech/APIs:** FashnAI virtual try-on API (ai_model, core); AWS Lambda (cloud, supporting); Amazon S3 (cloud, supporting); CloudFormation (cloud, token); Coolify (cloud, supporting); Next.js (framework, core)
- **Sponsor APIs:** 
- **Repo:** None, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live not_checked, screenshots 8, writeup long, impact claims False
- **Notes:** FashnAI handles one garment per call, so team chained calls to layer a full outfit; AWS Lambda strips backgrounds from uploads; Go backend; self-hosted on Coolify. Monash article lists it 2nd; Devpost says Third.
- **Team size:** 6 | **Confidence:** high | unverified: github_url (page lists a repo but URL not captured); tech_items.is_sponsor; placement order conflicts with Monash article; demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/weave-vn2xdk)


## UNIHACK 2026

### Antrum MK 1  (UNIHACK 2026)

- **Prizes:** FIRST PLACE [1st]  (tier: overall_top3)
- **Pitch:** Pair of leg-worn ESP32 devices that track cave partners by dead reckoning, show partner direction by LED and guide the way back; paths shown on a web dashboard.
- **Problem / user:** Cavers and miners get lost or separated in low-visibility, low-comms underground environments. / cave explorers and miners
- **Domain / idea type:** safety_security / hardware_gadget
- **Platforms / hardware / AI:** web; hardware / True / False
- **Stack:** langs C; C++; TypeScript; frontend Angular; backend Hono; db MongoDB; hosting Google Cloud VM; Vercel
- **Tech/APIs:** ESP32 (hardware_part, core); ICM20948 IMU (hardware_part, core); XC4508 2.4GHz radio (hardware_part, core); PlatformIO (other, supporting); Angular (framework, core); Hono (framework, core); MongoDB (database, supporting); Google Cloud (cloud, supporting)
- **Sponsor APIs:** 
- **Repo:** None, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live not_checked, screenshots 9, writeup long, impact claims False
- **Notes:** Custom PCB and 3D-printed enclosures; IMU dead reckoning with ZUPT; 2.4 GHz RF24-style radio master-slave exchange; Angular dashboard and Hono API; team drove for 3D prints at 3am.
- **Team size:** 4 | **Confidence:** high | unverified: github_url (page lists a repo but URL not captured); tech_items.is_sponsor; demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/antrum-mk-1)

### Cowdar  (UNIHACK 2026)

- **Prizes:** THIRD PLACE [3rd]  (tier: overall_top3)
- **Pitch:** iPhone app estimating a cow's weight from a LiDAR scan plus photo, using a custom pose model and a livestock weight formula.
- **Problem / user:** Livestock weighing tools are expensive, subscription-based or poor; small farmers need a free option on phones they own. / small-scale cattle farmers
- **Domain / idea type:** other / data_or_analytics
- **Platforms / hardware / AI:** mobile_ios / False / vision; predictive_ml
- **Stack:** langs Swift; Python; frontend Swift; ARKit; backend FastAPI; db ; hosting 
- **Tech/APIs:** YOLOv8 pose (ai_model, core); ARKit LiDAR (hardware_part, core); Roboflow (data_source, supporting); FastAPI (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** None, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live none, screenshots 10, writeup medium, impact claims False
- **Notes:** Custom YOLOv8m-pose trained on 1042 labelled cow images; LiDAR points projected to 2D to get body distances; Schaeffer-style formula; open source; team notes dark Angus hides were hard.
- **Team size:** 5 | **Confidence:** high | unverified: github_url (page lists a repo but URL not captured); domain_primary (agriculture not in list); team_size (one private member counted); demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/cowdar)

### Guardia  (UNIHACK 2026)

- **Prizes:** SOCIAL IMPACT PRIZE, 3rd [3rd]  (tier: track_winner)
- **Pitch:** Safety-first walking navigation for women at night: scores routes against crime incidents, voice-alerts near hotspots, adds AI companion call and SOS.
- **Problem / user:** Navigation apps show the fastest route, not the safest, leaving women walking alone at night anxious. / women walking home alone at night (Melbourne)
- **Domain / idea type:** safety_security + mobility_transport / social_good
- **Platforms / hardware / AI:** web / False / llm_chat; speech_or_voice; predictive_ml
- **Stack:** langs Python; TypeScript; frontend React; Mapbox; backend FastAPI; db Elasticsearch; hosting AWS App Runner; Vercel
- **Tech/APIs:** Elasticsearch (database, core, sponsor); Elastic Web Crawler (data_source, core, sponsor); HeyGen (ai_model, supporting); Mapbox (maps_geo, core); FastAPI (framework, core); AWS App Runner (cloud, supporting)
- **Sponsor APIs:** Elastic
- **Repo:** None, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live not_checked, screenshots 9, writeup long, impact claims False
- **Notes:** Elastic web crawler gathered over 10,000 incident records into Elasticsearch; FastAPI route scorer on AWS App Runner; HeyGen AI companion; Mapbox map.
- **Team size:** 6 | **Confidence:** high | unverified: github_url (page lists a repo but URL not captured); ai_types; prize not shown as badge on Devpost page; confirmed via UNIHACK Medium winners list; demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/guardia-9ghij1)

### HABITMON  (UNIHACK 2026)

- **Prizes:** BEST DESIGN, 2nd [2nd]  (tier: track_winner)
- **Pitch:** Skill-learning app where an AI fairy gives small tasks, and each completion yields a gacha monster that roams a field and quizzes you.
- **Problem / user:** New learners get overwhelmed, fall into tutorial hell and lose motivation; productivity apps feel like chores. / people learning a new skill
- **Domain / idea type:** education + entertainment_games / twist_on_known_app
- **Platforms / hardware / AI:** web / False / llm_chat; rag_or_search
- **Stack:** langs Python; JavaScript; frontend React; backend Flask; db Elasticsearch; hosting 
- **Tech/APIs:** Elasticsearch (database, core, sponsor); OpenAI ChatGPT API (ai_model, core); React (framework, core); Flask (framework, core)
- **Sponsor APIs:** Elastic
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live not_checked, screenshots 9, writeup long, impact claims False
- **Notes:** Pixel-art monsters as GIFs, CSS gacha reel, localStorage game state; Elasticsearch retrieves roadmaps and ChatGPT API writes quiz questions; most members first-time hackers. No Winner badge on page.
- **Team size:** 5 | **Confidence:** high | unverified: prize not shown as badge on Devpost page; confirmed via UNIHACK Medium winners list; demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/habit-habitat)

### Peersuade  (UNIHACK 2026)

- **Prizes:** BEST DESIGN, 3rd [3rd]; MOST FUN IDEA [unknown]  (tier: track_winner)
- **Pitch:** Jackbox-style 1v1 voice debate game on political topics, judged by five AI voters with personalities, including an OBJECTION button.
- **Problem / user:** Young voters are politically disengaged and traditional debates feel boring and jargon-heavy. / young Australians and friends playing party games
- **Domain / idea type:** entertainment_games + civic_legal / entertainment_or_game
- **Platforms / hardware / AI:** web / False / llm_chat; speech_or_voice
- **Stack:** langs TypeScript; frontend Next.js 15; React 19; Tailwind v4; backend Express.js; Socket.io; db ; hosting Vercel
- **Tech/APIs:** Gemini Flash (ai_model, core); Groq Whisper (ai_model, core); Agora RTC (other, core); Socket.io (framework, core)
- **Sponsor APIs:** 
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live not_checked, screenshots 8, writeup long, impact claims True (Cites Gen Z disengagement stats: 55% globally and about 47% of Australian Gen Z voting mainly to avoid a fine.)
- **Notes:** Server-authoritative Socket.io game state; Agora RTC voice with parallel-chunk Groq Whisper transcription; Gemini Flash voter personas; reconnect state sync.
- **Team size:** 6 | **Confidence:** high | unverified: demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/peersuade)

### Sentinel AI  (UNIHACK 2026)

- **Prizes:** SECOND PLACE [2nd]  (tier: overall_top3)
- **Pitch:** Web app that turns a DJI drone into a natural-language agent via an Android bridge, with live telemetry, vision models and footage analysis.
- **Problem / user:** Flying drones takes skill or paid operators; users want to describe tasks in plain language instead. / landowners, industry and government drone users
- **Domain / idea type:** ai_agents_infra + safety_security / automation_or_agent
- **Platforms / hardware / AI:** web; mobile_android; hardware / True / agent_or_tool_use; vision; speech_or_voice; rag_or_search
- **Stack:** langs Kotlin; TypeScript; frontend Next.js; React; backend Express.js; WebSockets; db Elastic; hosting Vercel; RunPod
- **Tech/APIs:** OpenAI API (ai_model, core); DJI Mobile SDK (hardware_part, core); YOLO (ai_model, supporting); Elastic (database, supporting, sponsor); FFmpeg (other, supporting); RunPod (cloud, token); Arduino (hardware_part, supporting)
- **Sponsor APIs:** Elastic
- **Repo:** None, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live not_checked, screenshots 5, writeup long, impact claims False
- **Notes:** Kotlin app on DJI MSDK streams RTMP video via FFmpeg; OpenAI agent loop with GPS/telemetry tools; Arduino telemetry bridge; Elastic stores video-analysis timestamps; simulated Android test environment.
- **Team size:** 4 | **Confidence:** high | unverified: github_url (page lists a repo but URL not captured); ai_types; demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/sentinel-ai-rzp29l)

### SlothMotion  (UNIHACK 2026)

- **Prizes:** SOCIAL IMPACT PRIZE, 2nd [2nd]  (tier: track_winner)
- **Pitch:** Webcam exercise coach for people 65+ that compares live pose to a reference routine and gives real-time feedback, with large high-contrast UI.
- **Problem / user:** Most Australians over 65 miss activity guidelines; mobility limits and gym discomfort block exercise. / older adults in Australia
- **Domain / idea type:** health_wellness + accessibility / social_good
- **Platforms / hardware / AI:** web / False / vision
- **Stack:** langs TypeScript; frontend React; Vite; backend Supabase; db Supabase; hosting 
- **Tech/APIs:** MediaPipe Pose (ai_model, core); React (framework, core); Supabase (database, supporting)
- **Sponsor APIs:** 
- **Repo:** None, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live none, screenshots 5, writeup long, impact claims True (States 57% of Australians aged 65+ do not meet physical activity guidelines.)
- **Notes:** MediaPipe Pose landmarks normalised and compared to a recorded reference with tolerance thresholds; routines personalised to ailments; no team member had prior computer vision experience.
- **Team size:** 6 | **Confidence:** high | unverified: github_url (page lists a repo but URL not captured); prize not shown as badge on Devpost page; confirmed via UNIHACK Medium winners list; demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/slothmotion)

### StepFlow  (UNIHACK 2026)

- **Prizes:** FIRST TIMERS PRIZE (by Atlassian) [unknown]  (tier: track_winner)
- **Pitch:** Gamified study scheduler: tasks as shooting targets or a spin wheel, RAG-generated quizzes, and Q-learning to time revision.
- **Problem / user:** Students struggle with task indecision, self-pressure and knowing when to revise. / university students
- **Domain / idea type:** education + productivity_workplace / twist_on_known_app
- **Platforms / hardware / AI:** web / False / llm_chat; rag_or_search; predictive_ml
- **Stack:** langs Python; TypeScript; frontend React; Vite; Tailwind; backend FastAPI; LangChain; db ChromaDB; SQLite; Firebase; hosting 
- **Tech/APIs:** Ollama / Llama 3 (ai_model, core); ChromaDB (database, core); LangChain (framework, supporting); FastAPI (framework, core); Firebase (cloud, supporting); Cursor (other, token)
- **Sponsor APIs:** 
- **Repo:** None, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live none, screenshots 7, writeup long, impact claims False
- **Notes:** Ebbinghaus forgetting-curve scheduler tuned by Q-learning on simulated schedules; local Llama 3 via Ollama for quizzes; end-of-day reflection step.
- **Team size:** 5 | **Confidence:** high | unverified: github_url (page lists a repo but URL not captured); placement n/a; Firebase role; demo_video_url; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/stepflow)
