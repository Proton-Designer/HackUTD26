
# ConUHacks X prizes (source: https://conuhacks-x.devpost.com/ , fetched 2026-11-02)
- General Challenge: 1st CAD 7,359 + MacBook Air; 2nd CAD 3,220 + Steam Deck; 3rd CAD 1,380 + Sony WH-1000XM4. (no separate descriptive text)
- HackConcordia Best Hardware: CAD 1,150 + Raspberry Pi 5 AI kit (no description).
- HackConcordia Best Beginner: all team members must be first-time hackers.
- Desjardins sponsor challenge: 5 winners, prepaid cards (page gives no problem text).
- MLH Best Use of Gemini API: push boundaries of AI using Google Gemini.
- MLH Best Use of Solana: Solana fast execution/low cost for games, DEXs, payment prototypes.
- MLH Best Use of Vultr: use Vultr cloud infrastructure (one-click deploy, GPU instances).
- MLH Best Use of ElevenLabs: add realistic AI voice/audio to an app.
- MLH Best Use of Snowflake API: use Snowflake REST APIs to access LLMs, e.g. RAG chatbots.
- MLH Best .Tech Domain Name: register a .Tech domain for the project.
