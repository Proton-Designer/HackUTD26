
## DubHacks '26 (dd_chunk_018 notes) - source https://dubhacks-2026.devpost.com/
- Title tracks Chef's Kitchen, Community Kitchen, Cook Smarter: no per-track text published; page says each team picks exactly one title track, most tracks are open ended. Judging criteria listed on page (Functionality 30% etc).
- Prize lines only (no challenge text): Visa Reimagine Shopping ($5,000), SideShift 1st/2nd/3rd (cash, work trial or interview), DubHacks Next 1st/2nd (interview for batch 6), Perceptron Perception 1-3 and Perceptron Robotics 1-2, T-Mobile 1-3, SpaceXAI 1st, VEYZL 1st ($500 + Pro), Photon track/runner-up/best voice agent.
- MLH Backboard text: AI APIs are stateless; Backboard is one API for long-term memory, RAG, embeddings, tool calls and model routing; examples travel guide, fitness coach, smart home.
- MLH Vultr text: cloud compute and GPUs for hosting AI projects.
