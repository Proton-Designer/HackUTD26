
# ConUHacks IX prizes (source: https://conuhacks-ix.devpost.com/ , fetched 2026-11-02)
- 1st Place: 4x PS5 + MLH pins. 2nd: 4x Meta Quest 3S (DRW to announce). 3rd: MSI monitors.
- MLH Best Use of MongoDB Atlas: build a hack using MongoDB Atlas; prize M5GO IoT kit per member.
- MLH Best Use of Streamlit: hack with Streamlit (free-to-deploy Python framework); Arduino Tiny ML Kit per member.
- MLH Best Use of AI powered by Reach Capital: projects should impact learning, health, or work; webcam per member, chat with Reach Capital investors.
- MLH Best Use of Gen AI: use publicly available Generative AI APIs (OpenAI, Anthropic, Hugging Face, Llama, Watson, Gemini) to build a functional application.
- TAILE'D Best Use of Lovable: showcase best usage of Lovable; post on X tagging Lovable; prize interview for Lovable Customer Success role.
- TAILE'D Best Social Media Post: LinkedIn post sharing hackathon experience, project, takeaways; tag Tail'ed and ConUHacks, include team name; Tail'ed hoodie.

## ConUHacks IX prizes (selected)
Source: https://conuhacks-ix.devpost.com/ (fetched 2026-11-02)
- 1st/2nd/3rd place: hardware prizes (PS5 / Meta Quest 3S / MSI monitors) plus MLH pins; no track brief.
- [DRUIDE] Best Use of Language: prize "a lot of goodies"; no challenge text beyond the name.
- [MLH] Best Domain Name from GoDaddy Registry: register a domain with GoDaddy Registry.
- Other MLH: MongoDB Atlas, Streamlit, Reach Capital AI, Gen AI. Also DRW, Sun Life, SAP, BEENOX, Tail'ed (Lovable, social post).
