# Bitcamp: project cards (50 projects)

Facts and short paraphrases only; no cross-project analysis. Full records are in the workbook and JSONL.

## Bitcamp 2025

### Bird Box  (Bitcamp 2025)

- **Prizes:** Best Razzle Dazzle Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Mobile-first Pokemon-Snap-style web game where users photograph local birds, with an ML model scoring photo quality across 200 species.
- **Problem / user:** Birdwatching lacks gamified incentives that make careful observation fun. / casual nature enthusiasts
- **Domain / idea type:** entertainment_games + sustainability_climate / entertainment_or_game
- **Platforms / hardware / AI:** web / False / vision
- **Stack:** langs Python; JavaScript; frontend React; CSS; backend Flask; db SQLite; hosting ngrok
- **Tech/APIs:** PyTorch (ai_model, core); Flask (framework, supporting); React (framework, supporting); ngrok (other, supporting)
- **Sponsor APIs:**  | fit: Event-run Best Razzle Dazzle Hack award; no sponsor tool targeted.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video False, live not_checked, screenshots 25, writeup medium, impact claims False
- **Notes:** Dynamic custom map pins and bird frequency zones; PyTorch classifier; SQLite shared between teammates; demo hosted via ngrok tunnel.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish; prizes.placement
- **Links:** [Devpost](https://devpost.com/software/bird-box-d2eguh)

### BurnoutBuddy  (Bitcamp 2025)

- **Prizes:** [MLH] Best Use of Gemini API [unknown]  (tier: sponsor_winner)
- **Pitch:** Wellbeing dashboard that estimates burnout from Fitbit, GitHub and webcam drowsiness data and suggests recovery actions.
- **Problem / user:** Students juggling deadlines feel burnout creeping in but lack tools that name and fight it. / students and young developers
- **Domain / idea type:** mental_health + health_wellness / data_or_analytics
- **Platforms / hardware / AI:** web / False / vision; llm_chat; recommendation
- **Stack:** langs Python; JavaScript; frontend React; Chart.js; Spline; backend Flask; db MongoDB; hosting 
- **Tech/APIs:** Gemini (ai_model, supporting, sponsor); OpenAI (ai_model, supporting); MediaPipe (ai_model, core); dlib (ai_model, core); Fitbit API (data_source, core); GitHub API (data_source, supporting); Spotify API (other, supporting); MongoDB (database, supporting)
- **Sponsor APIs:** Gemini API | fit: Lists Gemini among its AI components for burnout analysis, targeting the MLH Best Use of Gemini API prize; exact Gemini role is not detailed in the sections read.
- **Repo:** public, commits 29 (before/in/after event: 0/28/1), README solid
- **Demo/writeup:** video False, live none, screenshots 1, writeup medium, impact claims False
- **Notes:** Combines Fitbit data, GitHub activity and real-time webcam drowsiness detection (MediaPipe, dlib) with Spotify and a Spline 3D embed.
- **Team size:** 3 | **Confidence:** medium | unverified: ui_polish; prizes.placement; gemini role
- **Links:** [Devpost](https://devpost.com/software/burnoutbuddy) | [GitHub](https://github.com/CSin007/Bitcamp2025)

### CarbonQapture  (Bitcamp 2025)

- **Prizes:** Best Hack Promoting Public Health - Bloomberg [unknown]  (tier: sponsor_winner)
- **Pitch:** Uses a variational quantum eigensolver simulation plus a neural network to propose metal-organic frameworks for carbon dioxide capture.
- **Problem / user:** The huge design space of porous materials makes finding good CO2-capturing frameworks hard. / materials and climate researchers
- **Domain / idea type:** sustainability_climate + health_wellness / data_or_analytics
- **Platforms / hardware / AI:** web / False / predictive_ml; generative_media
- **Stack:** langs Python; JavaScript; frontend React; backend PyTorch; PennyLane; pandas; NumPy; db ; hosting Vercel
- **Tech/APIs:** PennyLane (framework, core); PyTorch (framework, core); CUDA (other, supporting); React (framework, supporting)
- **Sponsor APIs:**  | fit: Bloomberg public-health framing: page frames impact via carbon capture and climate; no Bloomberg tool used.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 7, writeup long, impact claims True (Claims 98.3 percent ground-state energy prediction accuracy and better CO2 selectivity and uptake than existing frameworks.)
- **Notes:** Quantum VQE (PennyLane, simplified 2-qubit Hamiltonian) feeds a generative neural net; claims 98.3 percent energy prediction accuracy; no GitHub link listed; prize named Public Health though topic is carbon capture.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/carbonqapture)

### CookHub  (Bitcamp 2025)

- **Prizes:** Best Web Hack Using React - Peraton [unknown]  (tier: sponsor_winner)
- **Pitch:** GitHub-style recipe platform where users post, fork and customize CookLang recipes, with a mobile React Native app.
- **Problem / user:** Finding cheap, easy recipes and a place to save and share them is scattered across the web. / home cooks
- **Domain / idea type:** food_nutrition + social_community / twist_on_known_app
- **Platforms / hardware / AI:** mobile_cross / False / False
- **Stack:** langs TypeScript; frontend React Native; Expo; backend Firebase; db Firebase; hosting 
- **Tech/APIs:** React Native / Expo (framework, core); Firebase (database, core); CookLang (other, core); Puppeteer/Cheerio (framework, supporting)
- **Sponsor APIs:**  | fit: Prize is Best Web Hack Using React from Peraton; the project is built with React Native/Expo rather than web React, per Built With.
- **Repo:** public, commits 35 (before/in/after event: 0/34/1), README solid
- **Demo/writeup:** video True, live none, screenshots 22, writeup short, impact claims False
- **Notes:** Forking recipes mirrors repo forking; renders CookLang markdown; scraping via Puppeteer and Cheerio; Firebase backend.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish; prizes.placement
- **Links:** [Devpost](https://devpost.com/software/cookhub) | [GitHub](https://github.com/anhatthezoo/bitcamp2025)

### Cyber Sentinel  (Bitcamp 2025)

- **Prizes:** Best Hardware Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Raspberry Pi appliance plus browser extension that checks websites for threats using YARA rules and Gemini to protect non-technical users.
- **Problem / user:** Less tech-savvy people such as parents and small business owners need simple, affordable online threat protection. / non-technical internet users and small businesses
- **Domain / idea type:** safety_security / hardware_gadget
- **Platforms / hardware / AI:** hardware; browser_extension; web / True / llm_chat
- **Stack:** langs Python; JavaScript; Shell; frontend React; Tailwind CSS; backend Python; db MongoDB; hosting 
- **Tech/APIs:** Raspberry Pi (hardware_part, core); YARA (other, core); Gemini (ai_model, supporting, sponsor); MongoDB (database, supporting, sponsor)
- **Sponsor APIs:** Gemini; MongoDB | fit: Event-run Best Hardware Hack award for a Raspberry Pi threat-detection device.
- **Repo:** public, commits 51 (before/in/after event: 0/39/12), README solid
- **Demo/writeup:** video False, live none, screenshots 13, writeup medium, impact claims False
- **Notes:** Extension collects system stats during page loads, Pi runs YARA malware rules over an SSH-ethernet link; MongoDB stores results.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish; prizes.placement
- **Links:** [Devpost](https://devpost.com/software/cyber-sentinel) | [GitHub](https://github.com/Suvrath421/bitcamp2025)

### DMPN: Developer Monitoring & Productivity Nexus  (Bitcamp 2025)

- **Prizes:** People's Choice Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Productivity monitor that scores a developer's focus using webcam emotion images and screenshots analyzed by a fine-tuned model and OpenAI.
- **Problem / user:** Developers cannot tell whether hours of coding were actually productive. / software developers
- **Domain / idea type:** productivity_workplace + dev_tools / data_or_analytics
- **Platforms / hardware / AI:** web / False / vision; llm_chat
- **Stack:** langs Python; TypeScript; frontend Next.js; Tailwind CSS; backend Flask; WebSocket; db ; hosting 
- **Tech/APIs:** OpenAI (ai_model, core); Fine-tuned emotion model (ai_model, core); Next.js (framework, supporting); Flask (framework, supporting)
- **Sponsor APIs:**  | fit: Event-run People's Choice award; no sponsor tool targeted.
- **Repo:** public, commits 43 (before/in/after event: 0/42/1), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 22, writeup medium, impact claims False
- **Notes:** Combines webcam emotion recognition and screen capture into live productivity scoring over WebSocket; monorepo with architecture diagram.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish; prizes.placement
- **Links:** [Devpost](https://devpost.com/software/dmpn-dev-aura-aio) | [GitHub](http://github.com/VietRocHack/DMPN/)

### Forens.tech  (Bitcamp 2025)

- **Prizes:** Best Digital Forensics Related Hack - Cipher Tech Solutions [unknown]  (tier: sponsor_winner)
- **Pitch:** Web interface that makes memory-dump forensics with Volatility approachable through a deliberately designed user experience.
- **Problem / user:** Digital forensics tools have unapproachable interfaces and confusing workflows. / forensics beginners and security analysts
- **Domain / idea type:** safety_security + dev_tools / dev_tool
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs Python; JavaScript; frontend React; CSS; backend FastAPI; db ; hosting 
- **Tech/APIs:** Volatility (other, core); FastAPI (framework, supporting); React (framework, supporting); Figma (other, supporting)
- **Sponsor APIs:**  | fit: Targeted the Cipher Tech digital-forensics challenge with a memory-dump analysis interface built on Volatility.
- **Repo:** public, commits 5 (before/in/after event: 0/5/0), README solid
- **Demo/writeup:** video False, live none, screenshots 16, writeup medium, impact claims False
- **Notes:** Wraps the Volatility memory-forensics framework behind a React frontend prototyped in Figma; no team member had used Volatility before.
- **Team size:** 3 | **Confidence:** high | unverified: ui_polish; prizes.placement
- **Links:** [Devpost](https://devpost.com/software/forens-tech) | [GitHub](https://github.com/AHumanMaybe/forens-tech)

### HealthBridge  (Bitcamp 2025)

- **Prizes:** Best Social Good Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Interactive map that layers social-determinants-of-health data to find underserved areas for public health agencies and nonprofits.
- **Problem / user:** Health disparities in underserved communities are hard to see across scattered open datasets. / public health agencies and nonprofits
- **Domain / idea type:** health_wellness + civic_legal / data_or_analytics
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs Python; HTML; CSS; frontend Leaflet.js; backend ; db ; hosting 
- **Tech/APIs:** Leaflet.js (maps_geo, core); OpenStreetMap (maps_geo, core); pandas (framework, supporting)
- **Sponsor APIs:**  | fit: Event-run Best Social Good Hack award; no sponsor tool targeted.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live none, screenshots 16, writeup medium, impact claims False
- **Notes:** Cleans state and federal open datasets in pandas and maps hospital access, food deserts, police presence and income with Leaflet and OpenStreetMap.
- **Team size:** 2 | **Confidence:** high | unverified: ui_polish; prizes.placement
- **Links:** [Devpost](https://devpost.com/software/healthbridge-i8ao9x)

### Hiding in Plain Sight  (Bitcamp 2025)

- **Prizes:** Best Cybersecurity Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Fast batch tool that detects hidden data in images from LSB and DCT steganography using statistical tests like chi-square and histograms.
- **Problem / user:** Data hidden inside ordinary image files is hard to detect at scale. / security analysts and forensics investigators
- **Domain / idea type:** safety_security / dev_tool
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs Python; JavaScript; frontend ; backend Flask; Pillow; NumPy; SciPy; db ; hosting 
- **Tech/APIs:** Pillow (other, core); NumPy (other, core); SciPy (other, core); Flask (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 46 (before/in/after event: 0/46/0), README solid
- **Demo/writeup:** video True, live none, screenshots 2, writeup short, impact claims False
- **Notes:** Short writeup; includes UI easter eggs; pure statistical analysis with no ML mentioned.
- **Team size:** 3 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/hiding-in-plain-sight) | [GitHub](https://github.com/braynguyen/Hiding-in-Plain-Sight)

### Jesture  (Bitcamp 2025)

- **Prizes:** [MLH] Best Use of Gemini API [unknown]  (tier: sponsor_winner)
- **Pitch:** Drawing and guessing game controlled by webcam hand gestures where a Gemini model guesses the sketch.
- **Problem / user:** Wanted a playful gesture-driven game inspired by fiction, replacing mouse input with hand tracking. / casual players
- **Domain / idea type:** entertainment_games / entertainment_or_game
- **Platforms / hardware / AI:** desktop / False / vision; llm_chat
- **Stack:** langs Python; frontend Raylib; backend ; db ; hosting 
- **Tech/APIs:** Gemini (Google GenAI) (ai_model, core, sponsor); MediaPipe (ai_model, core); OpenCV (framework, supporting); TensorFlow (framework, supporting); Raylib (framework, core)
- **Sponsor APIs:** Gemini API | fit: Uses Google GenAI to have Gemini guess drawings, core to the game loop, for the MLH Best Use of Gemini API prize.
- **Repo:** public, commits 8 (before/in/after event: 0/7/1), README solid
- **Demo/writeup:** video True, live none, screenshots 16, writeup medium, impact claims False
- **Notes:** Solo build combining MediaPipe hand tracking, Raylib canvas rendering and Google GenAI for guessing drawings.
- **Team size:** 1 | **Confidence:** high | unverified: ui_polish; prizes.placement
- **Links:** [Devpost](https://devpost.com/software/jesture-sa1v02) | [GitHub](https://github.com/jinson-j/jesture)

### Koalafied  (Bitcamp 2025)

- **Prizes:** [MLH] Best Use of .Tech [unknown]  (tier: sponsor_winner)
- **Pitch:** Gamified job application tracker where progress on applications and interviews grows an animated virtual koala world.
- **Problem / user:** Applying to many internships is tedious and boring, making tracking hard to sustain. / students applying for internships and jobs
- **Domain / idea type:** productivity_workplace + entertainment_games / twist_on_known_app
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs JavaScript; frontend React; Material UI; backend Node.js; Express.js; db MongoDB; hosting 
- **Tech/APIs:** .Tech domain (other, supporting, sponsor); MongoDB (database, core); React (framework, core); Express.js (framework, supporting)
- **Sponsor APIs:** .Tech domain | fit: Hosted at a .tech domain (koalafied.tech) for the MLH Best Use of .Tech prize.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 22, writeup long, impact claims False
- **Notes:** MERN app with pure-React animations and physics; Gemini API was planned but is described under what's next; uses a .tech domain.
- **Team size:** 3 | **Confidence:** high | unverified: ui_polish; prizes.placement
- **Links:** [Devpost](https://devpost.com/software/koalafied)

### Lighthouse  (Bitcamp 2025)

- **Prizes:** Best Machine Learning Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Solo project that restarts a pretrained diffusion model from a real noisy image to denoise it or generate creative variations via re-noising.
- **Problem / user:** Photos taken in low light are too noisy to use and hard to edit creatively. / photographers and hobbyists
- **Domain / idea type:** creative_media / creative_tool
- **Platforms / hardware / AI:** other / False / generative_media
- **Stack:** langs Python; frontend ; backend PyTorch; db ; hosting 
- **Tech/APIs:** DDPM (ai_model, core); PyTorch (framework, core)
- **Sponsor APIs:** 
- **Repo:** public, commits 15 (before/in/after event: 0/10/5), README detailed
- **Demo/writeup:** video True, live none, screenshots 2, writeup long, impact claims False
- **Notes:** Skips early diffusion timesteps and uses a custom noise scheduler; trained nothing from scratch, ran on a single consumer GPU.
- **Team size:** 1 | **Confidence:** high | unverified: n_screenshots; platforms
- **Links:** [Devpost](https://devpost.com/software/lighthouse-p1cb0k) | [GitHub](https://github.com/dswl/lighthouse/tree/main)

### NeuroScan.AI  (Bitcamp 2025)

- **Prizes:** Best First Time Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Streamlit app that classifies brain tumors from MRI scans with a fine-tuned MobileNetV2 and generates PDF reports with Gemini treatment suggestions.
- **Problem / user:** Early brain tumor diagnosis matters, and clinicians could use accessible AI support for classification and report writing. / medical professionals and patients
- **Domain / idea type:** health_wellness / data_or_analytics
- **Platforms / hardware / AI:** web / False / vision; predictive_ml; llm_chat
- **Stack:** langs Python; frontend Streamlit; backend TensorFlow; OpenCV; FPDF2; db ; hosting Render
- **Tech/APIs:** TensorFlow MobileNetV2 (ai_model, core); Gemini (ai_model, supporting); Streamlit (framework, core); OpenCV (other, supporting); FPDF2 (other, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 19 (before/in/after event: 0/19/0), README detailed
- **Demo/writeup:** video False, live not_checked, screenshots 7, writeup medium, impact claims True (States 92 percent tumor classification accuracy; no independent validation shown.)
- **Notes:** Combines a trained image classifier with an LLM for treatment text and a doctor review section in a generated PDF; claims 92 percent accuracy.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/neuroscan-ai) | [GitHub](https://github.com/anshulg614/NeuroScan.AI)

### QAOA for the kidney exchange problem  (Bitcamp 2025)

- **Prizes:** Best Advanced Quantum Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Solves the kidney exchange (donor chain) optimization with QAOA simulated in PennyLane and compares against classical integer-programming solvers.
- **Problem / user:** Kidney donation chain matching is an integer-programming problem; the team asked whether a quantum algorithm could help. / quantum optimization researchers
- **Domain / idea type:** health_wellness / data_or_analytics
- **Platforms / hardware / AI:** cli / False / False
- **Stack:** langs Python; frontend ; backend OpenQAOA; PennyLane; PuLP; CPLEX; CBC; Matplotlib; db ; hosting 
- **Tech/APIs:** PennyLane (framework, core); OpenQAOA (framework, core); PuLP (other, core); CPLEX (other, supporting); Classiq (other, token)
- **Sponsor APIs:** 
- **Repo:** public, commits 22 (before/in/after event: 0/17/5), README solid
- **Demo/writeup:** video False, live none, screenshots 2, writeup medium, impact claims True (Asserts possible exponential speedup; no numbers given.)
- **Notes:** Limited to datasets under 30 donor-recipient pairs because of simulation cost; claims possible exponential speedup without showing evidence on the page; slides linked instead of a demo.
- **Team size:** 2 | **Confidence:** high | unverified: platforms; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/kidney-donation-chain-integer-programming-with-qaoa) | [GitHub](https://github.com/9t8/quantum_kidney)

### Quanta  (Bitcamp 2025)

- **Prizes:** Best Advanced Quantum Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Simulates stress on thin materials by solving a finite-element system with a quantum HHL algorithm and a classical fallback, rendered as 3D.
- **Problem / user:** CAD tools like Fusion 360 are slow and cannot model nanomaterials for structural stress prediction. / materials engineers and designers
- **Domain / idea type:** other + education / data_or_analytics
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs Python; TypeScript; frontend React; Vite; Tailwind CSS; Three.js; backend Flask; NumPy; Classiq SDK; db ; hosting 
- **Tech/APIs:** Classiq (other, core); Materials Project API (data_source, core); Three.js (framework, supporting); Blender (other, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 61 (before/in/after event: 0/58/3), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 6, writeup long, impact claims False
- **Notes:** Pulls properties from the Materials Project API; quantum part limited to small matrices so a classical solver is also provided; site includes dinosaur-themed easter eggs.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/quanta-obvusa) | [GitHub](https://github.com/chemystery09/quanta)

### Riffs  (Bitcamp 2025)

- **Prizes:** Best App Dev Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Browser tool that turns a hummed melody into notes, maps them to guitar strings and frets, and shows them in an editable piano roll.
- **Problem / user:** Learning guitar and composing feels intimidating because tools rely on robotic MIDI, confusing tabs or studio setups. / beginner guitarists and music creators
- **Domain / idea type:** creative_media + education / creative_tool
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs TypeScript; frontend Next.js; React; Tailwind CSS; backend ; db ; hosting Vercel
- **Tech/APIs:** pitchy (other, core); Next.js (framework, core); FL Studio samples (other, token)
- **Sponsor APIs:** 
- **Repo:** public, commits 78 (before/in/after event: 0/77/1), README solid
- **Demo/writeup:** video True, live not_checked, screenshots 5, writeup medium, impact claims False
- **Notes:** Entirely client-side with no backend; pitch detection in browser; playback not yet integrated though guitar samples were recorded.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/riffs) | [GitHub](https://github.com/cataladev/riffs)

### Roameo  (Bitcamp 2025)

- **Prizes:** Best Use of GenAI in Business - Cloudforce/Microsoft [unknown]  (tier: sponsor_winner)
- **Pitch:** Conversational travel-planning chatbot that pulls flights, hotels and maps data and builds personalized itineraries.
- **Problem / user:** Comparing flights, stays and activities across many sites makes travel planning stressful. / leisure travelers
- **Domain / idea type:** mobility_transport + retail_consumer / automation_or_agent
- **Platforms / hardware / AI:** web / False / llm_chat; agent_or_tool_use; speech_or_voice
- **Stack:** langs Python; JavaScript; frontend React; Tailwind CSS; backend Flask; FastAPI; n8n; db MongoDB; hosting 
- **Tech/APIs:** OpenAI (ai_model, core); Gemini (ai_model, supporting, sponsor); Browser Use (other, core); n8n (other, supporting); Google Maps (maps_geo, supporting); ElevenLabs (ai_model, supporting, sponsor); MongoDB (database, supporting, sponsor)
- **Sponsor APIs:** Gemini; ElevenLabs; MongoDB | fit: Targeted the Cloudforce/Microsoft Best Use of GenAI in Business prize with a generative AI travel agent; page lists OpenAI and Gemini, no Microsoft Azure product.
- **Repo:** public, commits 1 (before/in/after event: 0/1/0), README none
- **Demo/writeup:** video True, live not_checked, screenshots 22, writeup medium, impact claims False
- **Notes:** Browser-use and n8n automation drive Google Flights and Hotels lookups behind an OpenAI and Gemini chat; ElevenLabs voice and Google Maps tiles included.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish; prizes.placement
- **Links:** [Devpost](https://devpost.com/software/roameo-dtrzau) | [GitHub](https://github.com/Vitthal-Agarwal/travel)

### Schrodinger's Catch: TROUT of This World!  (Bitcamp 2025)

- **Prizes:** Hack That Made You Smile - Alumni Team [unknown]  (tier: track_winner)
- **Pitch:** Meta Quest VR fishing game on an island where fish outcomes use quantum random numbers generated with Qiskit.
- **Problem / user:** Team wanted to try VR and add a novel quantum twist to a relaxing game. / VR gamers
- **Domain / idea type:** entertainment_games / entertainment_or_game
- **Platforms / hardware / AI:** other / True / False
- **Stack:** langs Python; GDScript; frontend Godot; backend Flask; Qiskit; db ; hosting 
- **Tech/APIs:** Godot XR Tools (framework, core); Meta Quest (hardware_part, core); Qiskit (other, core); Flask (framework, supporting)
- **Sponsor APIs:**  | fit: Event-run Hack That Made You Smile award from the alumni team; no sponsor tool targeted.
- **Repo:** public, commits 143 (before/in/after event: 0/143/0), README thin
- **Demo/writeup:** video False, live none, screenshots 13, writeup medium, impact claims False
- **Notes:** Beginner VR build in Godot with XR Tools exported to Meta Quest; Python Flask service supplies quantum random numbers via Qiskit.
- **Team size:** 3 | **Confidence:** high | unverified: ui_polish; prizes.placement; gdscript language
- **Links:** [Devpost](https://devpost.com/software/schrodingers-catch-trout-of-this-world) | [GitHub](https://github.com/NA980593/schrodingers-catch)

### Tariffix  (Bitcamp 2025)

- **Prizes:** [MLH] Best Use of MongoDB Atlas [unknown]  (tier: sponsor_winner)
- **Pitch:** Chrome extension and site that shows shoppers how tariffs affect product prices, with Gemini explanations and MongoDB-backed data.
- **Problem / user:** Consumers do not understand how hidden tariff costs affect everyday purchases. / online shoppers
- **Domain / idea type:** retail_consumer + fintech_finance / twist_on_known_app
- **Platforms / hardware / AI:** browser_extension; web / False / llm_chat
- **Stack:** langs TypeScript; frontend Next.js; React; Tailwind CSS; Vite; backend Cheerio; db MongoDB; hosting 
- **Tech/APIs:** MongoDB (database, core, sponsor); Gemini (ai_model, supporting, sponsor); Chrome extension API (framework, core); Cheerio (framework, supporting)
- **Sponsor APIs:** MongoDB Atlas; Gemini | fit: Uses MongoDB as its database per Built With, targeting MLH Best Use of MongoDB Atlas; page text read does not detail Atlas features.
- **Repo:** public, commits 43 (before/in/after event: 0/37/6), README solid
- **Demo/writeup:** video True, live none, screenshots 49, writeup medium, impact claims False
- **Notes:** Next.js landing, guide and watch pages plus a Chrome extension; scrapes product data with Cheerio; 49 screenshots uploaded.
- **Team size:** 4 | **Confidence:** medium | unverified: ui_polish; prizes.placement; writeup_sections; atlas use
- **Links:** [Devpost](https://devpost.com/software/tariffix) | [GitHub](https://github.com/Adr1an04/Tariffix)

### VisuWorld  (Bitcamp 2025)

- **Prizes:** Prettiest Hack - Alumni Team; [MLH] Best Use of Gemini API [unknown]  (tier: track_winner)
- **Pitch:** Speak a scene aloud and Gemini writes GLSL shader code that renders it as an interactive 3D visual, grounded by a shader-snippet RAG database.
- **Problem / user:** Creating graphics shaders needs specialist code skill; the team wanted anyone to produce visuals just by describing them by voice. / creative users and graphics hobbyists
- **Domain / idea type:** creative_media / creative_tool
- **Platforms / hardware / AI:** web / False / llm_chat; rag_or_search; speech_or_voice; generative_media
- **Stack:** langs GLSL; JavaScript; frontend Next.js; React; Tailwind CSS; three.js; WebGL; backend ; db ChromaDB; hosting 
- **Tech/APIs:** Google Gemini API (ai_model, core, sponsor); ChromaDB (database, core); OpenAI embeddings (ai_model, supporting); Web Speech API (other, core); three.js / WebGL (framework, core); Next.js (framework, supporting); Shadertoy (data_source, supporting)
- **Sponsor APIs:** Google Gemini API | fit: Used Gemini 2.0 Flash and 2.5 Pro to generate GLSL shader code from spoken prompts, augmented by a retrieval database of shader snippets.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 10, writeup medium, impact claims False
- **Notes:** Scraped tens of thousands of Shadertoy snippets, embedded them in ChromaDB for retrieval, then used Gemini 2.0 Flash and 2.5 Pro to generate GLSL from browser speech-to-text.
- **Team size:** 3 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/visuworld)


## Bitcamp 2026

### AGastIa  (Bitcamp 2026)

- **Prizes:** Best Champion of Open Source w/ Featherless - Featherless [unknown]  (tier: sponsor_winner)
- **Pitch:** Uploads of medical reports and scans are turned into plain-language summaries, organ-mapped severity scores, an interactive 3D body view and a causal graph.
- **Problem / user:** Medical reports are dense and jargon-filled, so patients struggle to understand findings and act on them. / patients and clinicians
- **Domain / idea type:** health_wellness + ai_agents_infra / data_or_analytics
- **Platforms / hardware / AI:** web / False / llm_chat; rag_or_search; vision; predictive_ml
- **Stack:** langs Python; TypeScript; JavaScript; frontend React; Vite; Tailwind CSS; backend FastAPI; Celery; SQLAlchemy; Alembic; db PostgreSQL; Redis; hosting 
- **Tech/APIs:** MedGemma (ai_model, core); MedSAM (ai_model, core); Bio_ClinicalBERT (ai_model, core); PaddleOCR (ai_model, core); Gemini API (ai_model, supporting); Hugging Face Transformers (framework, supporting); PyTorch (framework, supporting); Auth0 (auth, supporting); FastAPI (framework, supporting); React (framework, supporting)
- **Sponsor APIs:**  | fit: Targeted the Featherless open-source champion prize; the page lists open models such as MedGemma and MedSAM but does not show Featherless usage.
- **Repo:** private_or_missing, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live none, screenshots 1, writeup medium, impact claims False
- **Notes:** Chains OCR, a clinical-domain LLM, RAG, MedSAM segmentation and MedGemma into one pipeline; page frames it against Bitcamp's ML track and does not visibly mention Featherless.
- **Team size:** 4 | **Confidence:** medium | unverified: ui_polish; sponsor_fit_note; repo_clone_failed
- **Links:** [Devpost](https://devpost.com/software/agastiya) | [GitHub](https://github.com/SriRammSS/AGastIa)

### Apsora Brief  (Bitcamp 2026)

- **Prizes:** Best Data Visualization Experience - Peraton [unknown]  (tier: sponsor_winner)
- **Pitch:** Ranks satellite close-approach events from CelesTrak SOCRATES data, has Claude write a 30-second operator brief, and shows orbits on a 3D Cesium globe with a closest-approach scrubber.
- **Problem / user:** Crowded low Earth orbit raises collision and debris-cascade risk, and raw conjunction data is hard for operators to act on quickly. / satellite operators
- **Domain / idea type:** safety_security + ai_agents_infra / data_or_analytics
- **Platforms / hardware / AI:** web / False / llm_chat
- **Stack:** langs Python; TypeScript; frontend Next.js; React; Cesium.js; Recharts; Tailwind CSS; backend FastAPI; Uvicorn; Pydantic; pandas; SGP4; db ; hosting 
- **Tech/APIs:** Anthropic Claude API (ai_model, core); CelesTrak SOCRATES / GP API (data_source, core); Cesium.js (framework, core); SGP4 (framework, core); FastAPI (framework, supporting); Next.js (framework, supporting); Jina.ai proxy (other, supporting)
- **Sponsor APIs:**  | fit: Targeted Peraton's data visualization prize with a 3D Cesium globe of satellite orbits and ranked conjunction events; the page does not name Peraton tools.
- **Repo:** public, commits 18 (before/in/after event: 0/18/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 13, writeup medium, impact claims False
- **Notes:** Uses real SOCRATES conjunction data with SGP4 orbit propagation, plus a time-of-closest-approach playback scrubber on a Cesium globe; Claude generates the briefs.
- **Team size:** 2 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/oribital-breif) | [GitHub](https://github.com/po-aditya/Apsora-Brief)

### Arcane Shell  (Bitcamp 2026)

- **Prizes:** Best Bitcamp Game Jam Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** First-person wizard game using a Wii Remote as a gesture wand and a 7-inch tablet as a spellbook for crafting spells and mini-games.
- **Problem / user:** Wizard games reduce spellcasting to button presses and lose the feeling of actually casting. / gamers
- **Domain / idea type:** entertainment_games / entertainment_or_game
- **Platforms / hardware / AI:** web; hardware / True / False
- **Stack:** langs TypeScript; frontend Vite; Three.js; backend WebSockets; UDP; db ; hosting 
- **Tech/APIs:** Three.js (framework, core); Wii Remote (hardware_part, core); WiimoteHook (other, core); XInput (other, supporting); Raspberry Pi touchscreen (hardware_part, supporting); MediaPipe (ai_model, unclear)
- **Sponsor APIs:** 
- **Repo:** public, commits 67 (before/in/after event: 0/67/0), README solid
- **Demo/writeup:** video True, live none, screenshots 6, writeup long, impact claims False
- **Notes:** All props, maps, enemies and effects are procedural code with no 3D assets; WiimoteHook UDP bridge for gyro and haptics; 3D-printed grimoire case; builders' first game.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/arcane-shell) | [GitHub](https://github.com/victorliu15/Arcane-Shell)

### BlindSight  (Bitcamp 2026)

- **Prizes:** Best App Dev Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** iPhone indoor navigation for blind users that splits a destination into subgoals with Gemini and guides with LiDAR haptics and spatial audio.
- **Problem / user:** Canes and guide dogs are costly or reactive and lack context to guide someone through complex indoor buildings. / blind and low-vision people
- **Domain / idea type:** accessibility + mobility_transport / social_good
- **Platforms / hardware / AI:** mobile_ios / False / vision; llm_chat
- **Stack:** langs Swift; Python; frontend SwiftUI; backend ARKit; CoreML; PyTorch; db ; hosting 
- **Tech/APIs:** Gemini 3 (ai_model, core); YOLOE (ai_model, core); ARKit (framework, core); CoreHaptics (framework, supporting); AVFoundation (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 3 (before/in/after event: 0/2/1), README detailed
- **Demo/writeup:** video True, live none, screenshots 8, writeup long, impact claims True (Cites roughly 40 million blind people worldwide.)
- **Notes:** Runs on an iPhone 15 Pro with ARKit SLAM, YOLOE exported to CoreML, LiDAR obstacle alerts; thermal throttling handled by sampling frames every second or two.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/blindnav-yzd8fh) | [GitHub](https://github.com/aidenjcheng/blindsight)

### Catan Tactics  (Bitcamp 2026)

- **Prizes:** Neelbauer Agentic Revolution Award (NARA) - Alumni Prize [unknown]  (tier: sponsor_winner)
- **Pitch:** Four AI players with distinct personalities play and negotiate a full game of Catan using a self-play RL value network, an LLM tool-calling layer and AlphaBeta lookahead.
- **Problem / user:** Catan has randomness and hidden information, so rule-based bots lack intuitive play; the author wanted learned plus agentic decision-making. / game AI enthusiasts
- **Domain / idea type:** entertainment_games + ai_agents_infra / automation_or_agent
- **Platforms / hardware / AI:** web / False / agent_or_tool_use; llm_chat; predictive_ml
- **Stack:** langs Python; frontend React; backend Flask; Ollama; PyTorch; NumPy; db PostgreSQL; hosting Docker
- **Tech/APIs:** PyTorch (framework, core); Ollama (ai_model, core); Catanatron (framework, core); Flask (framework, supporting); React (framework, supporting); PostgreSQL (database, supporting); Docker (other, supporting)
- **Sponsor APIs:**  | fit: Targeted the Neelbauer Agentic Revolution Award (alumni prize) with a multi-agent Catan system where LLM agents call tools and negotiate.
- **Repo:** public, commits 300 (before/in/after event: 802/5/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 1, writeup long, impact claims False
- **Notes:** Three-layer agent: RL value network trained by self-play, an LLM that calls analysis tools, and a negotiation system with favor requests and reputation; builds on the open-source Catanatron simulator.
- **Team size:** 1 | **Confidence:** high | unverified: ui_polish; sponsor_fit_note
- **Links:** [Devpost](https://devpost.com/software/catan-tactics) | [GitHub](https://github.com/DarekYu/Catanatron)

### Cherry Canary  (Bitcamp 2026)

- **Prizes:** Best Social Good Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** A chest-worn sensor patch tracks heart rate, breathing and motion to warn COPD and asthma patients before blood oxygen falls, with Gemini-assisted insights.
- **Problem / user:** Pulse oximeters only alarm after oxygen has dropped; COPD and asthma patients get no early warning or inhaler feedback. / COPD and asthma patients
- **Domain / idea type:** health_wellness + accessibility / hardware_gadget
- **Platforms / hardware / AI:** web; hardware / True / llm_chat; predictive_ml
- **Stack:** langs Python; HTML; C++; frontend React; backend Python; db MongoDB; hosting 
- **Tech/APIs:** ESP32-S2 Feather (hardware_part, core); MAX30102 sensor (hardware_part, core); MPU motion sensor (hardware_part, core); Google Gemini Flash (ai_model, supporting); MongoDB (database, supporting); React (framework, supporting); Arduino IDE (other, supporting)
- **Sponsor APIs:**  | fit: Entered for Bitcamp's own Social Good track with a wearable early-warning device for chronic respiratory patients.
- **Repo:** public, commits 41 (before/in/after event: 0/41/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 13, writeup long, impact claims True (Cites US COPD/asthma prevalence, inhaler misuse and readmission rates, and claims detection 10-30 minutes before standard oximeter alarm thresholds.)
- **Notes:** Custom wearable using an ESP32-S2 Feather with MAX30102 and MPU sensors in a 3D-printed housing, detecting heart-rate/breathing compensation patterns rather than SpO2 thresholds.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/cherry-canary) | [GitHub](https://github.com/ShreeyaG3/Cherry_Canary.git)

### Circuitry with Neural Networks  (Bitcamp 2026)

- **Prizes:** Most LIT Hack - Alumni Prize [unknown]  (tier: sponsor_winner)
- **Pitch:** A hardware neural-network visualizer: draw a digit on screen and a soldered LED-strip network lights the activated neurons, with hover to trace causes.
- **Problem / user:** Neural network computation is abstract; the team wanted a physical, visible model of how neurons activate across layers. / students learning machine learning
- **Domain / idea type:** education + creative_media / hardware_gadget
- **Platforms / hardware / AI:** web; hardware / True / predictive_ml
- **Stack:** langs C++; JavaScript; HTML; CSS; frontend HTML; CSS; JavaScript; backend ; db ; hosting 
- **Tech/APIs:** Arduino Uno (hardware_part, core); LED strips (hardware_part, core); JavaScript (framework, supporting)
- **Sponsor APIs:**  | fit: Entered for the Most LIT Hack alumni prize with an LED-strip neural network driven by an Arduino; no sponsor product is named.
- **Repo:** public, commits 4 (before/in/after event: 0/4/0), README solid
- **Demo/writeup:** video False, live none, screenshots 0, writeup medium, impact claims False
- **Notes:** Pivoted from a conductance-based physical neural network to hundreds of hand-soldered LEDs driven by an Arduino Uno using discrete weights, inspired by the Stillwell Brain.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish; sponsor_fit_note
- **Links:** [Devpost](https://devpost.com/software/circuitry-with-neural-networks) | [GitHub](https://github.com/ahamme2330/Neural-Number-Recognizer)

### Clarify  (Bitcamp 2026)

- **Prizes:** Best Digital Forensics Related Hack - Cipher Tech Solutions [unknown]  (tier: sponsor_winner)
- **Pitch:** Project page is nearly empty; entered for the digital forensics prize, apparently a web app (details not stated).
- **Problem / user:** None / None
- **Domain / idea type:** safety_security / other
- **Platforms / hardware / AI:** web / None / None
- **Stack:** langs TypeScript; frontend Next.js; React; backend FastAPI; db ; hosting 
- **Tech/APIs:** Next.js (framework, unclear); FastAPI (framework, unclear); React (framework, unclear); TypeScript (framework, unclear)
- **Sponsor APIs:** 
- **Repo:** None, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live none, screenshots 0, writeup short, impact claims None
- **Notes:** Devpost page has only a one-line next-steps note and a stack list; no description, links or screenshots, so purpose is inferred from the prize name only.
- **Team size:** 5 | **Confidence:** low | unverified: one_line_pitch; problem_statement; target_user; domain_primary; idea_type; platforms; has_hardware; ai_used; ai_types; sponsor_fit_note; ui_polish; has_impact_claims
- **Links:** [Devpost](https://devpost.com/software/clarify-ztm49p)

### CrisisMatch  (Bitcamp 2026)

- **Prizes:** Best Beginner Data Science Track Hack [unknown]  (tier: track_winner)
- **Pitch:** Live world map of ships and aircraft near disasters, with Claude and Gemini agents assessing severity and auto-matching volunteers to needs.
- **Problem / user:** Crisis news leaves viewers passive; there is no tool turning live disaster data into concrete volunteer action. / volunteers and crisis responders
- **Domain / idea type:** civic_legal + safety_security / automation_or_agent
- **Platforms / hardware / AI:** web / False / llm_chat; agent_or_tool_use
- **Stack:** langs TypeScript; frontend React; Vite; Leaflet; backend Node.js; Express; db ; hosting 
- **Tech/APIs:** Claude (ai_model, core); Gemini (ai_model, core); AISStream (data_source, core); OpenSky (data_source, core); Open-Meteo (data_source, supporting); Yahoo Finance (data_source, token); Auth0 (auth, supporting); Leaflet.js (maps_geo, core); CARTO (maps_geo, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 7 (before/in/after event: 0/7/0), README detailed
- **Demo/writeup:** video False, live none, screenshots 0, writeup medium, impact claims False
- **Notes:** Multiple LLM agents run in parallel to score situation severity; AISStream WebSocket ship feed; volunteer names masked; falls back to backup data when feeds lag.
- **Team size:** 4 | **Confidence:** high | unverified: sponsor flags; n_screenshots; has_demo_video; "three AI models" claim vs listed two
- **Links:** [Devpost](https://devpost.com/software/crisismatch) | [GitHub](https://github.com/Bharathisthe/habibi/tree/crisis-match)

### cryptX by Moonshot  (Bitcamp 2026)

- **Prizes:** Best Financial Hack - Capital One; Best App Dev Track Hack - Bitcamp [unknown]  (tier: sponsor_winner)
- **Pitch:** Arduino hardware crypto wallet for Solana testnet with PIN, seed backup and on-device approval, plus a Gemini fraud monitor and live dashboard.
- **Problem / user:** Hardware wallets cost around $150 and the team wanted secure transaction signing and fraud detection on cheap constrained hardware. / crypto users wanting low-cost hardware signing
- **Domain / idea type:** fintech_finance + safety_security / hardware_gadget
- **Platforms / hardware / AI:** hardware; web / True / agent_or_tool_use; predictive_ml
- **Stack:** langs C++; TypeScript; frontend Next.js; React; Tailwind CSS; backend Web Serial API; Web3.js; db MongoDB; hosting Vercel
- **Tech/APIs:** Arduino Uno (hardware_part, core); Solana (payments, core); Gemini (ai_model, core); Web3.js (framework, core); MongoDB (database, supporting)
- **Sponsor APIs:**  | fit: Capital One financial prize: builds a self-custody wallet and fraud-risk layer; no Capital One API named.
- **Repo:** public, commits 48 (before/in/after event: 0/43/5), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 4, writeup long, impact claims False
- **Notes:** Arduino Uno firmware with SipHash challenge-response, EEPROM state and three-attempt wipe; dashboard talks over Web Serial; Gemini agent auto-blacklists suspicious devices.
- **Team size:** 4 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/cryptx-zceo69) | [GitHub](https://github.com/navincodesalot/cryptx/)

### Crystal Forge  (Bitcamp 2026)

- **Prizes:** Best Computational Quantum Track Hack [unknown]  (tier: track_winner)
- **Pitch:** Routes quantum lattice simulations to classical or quantum solvers with an ML classifier and plans measurements focused on superconductivity observables.
- **Problem / user:** Lattice simulations need huge computation and much of the measurement budget is wasted on unimportant observables. / quantum materials researchers
- **Domain / idea type:** other + ai_agents_infra / dev_tool
- **Platforms / hardware / AI:** web / False / predictive_ml
- **Stack:** langs Python; JavaScript; frontend React; Vite; backend FastAPI; db ; hosting 
- **Tech/APIs:** FastAPI (framework, supporting); React (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 18 (before/in/after event: 0/14/4), README detailed
- **Demo/writeup:** video False, live none, screenshots None, writeup medium, impact claims True (Reports 85 percent routing accuracy and more than triple hard-sector coverage versus a naive approach.)
- **Notes:** Two components named CorrMap (routing, 85 percent accuracy) and QProbe (measurement planning); pivoted from generic planner to superconductivity-specific channels.
- **Team size:** 3 | **Confidence:** medium | unverified: n_screenshots; domain_primary
- **Links:** [Devpost](https://devpost.com/software/crystal-forge) | [GitHub](https://github.com/Pvphantom/bitcamp2026-crystal-forge)

### Docket  (Bitcamp 2026)

- **Prizes:** [MLH] Best Use of Auth0 [unknown]  (tier: sponsor_winner)
- **Pitch:** Connects to a developer's GitHub repos, draws an interactive commit/branch graph, and uses Gemini to explain each commit while letting devs add notes on why.
- **Problem / user:** Commit history shows what and who but not why, so reasoning behind changes is lost months later. / software developers and teams
- **Domain / idea type:** dev_tools / dev_tool
- **Platforms / hardware / AI:** web / False / llm_chat
- **Stack:** langs TypeScript; frontend Next.js; backend ; db Supabase; hosting Vercel
- **Tech/APIs:** Auth0 (auth, core, sponsor); Google Gemini (ai_model, core); Supabase (database, supporting); Next.js (framework, supporting); Vercel (cloud, supporting); TerpAI (ai_model, unclear)
- **Sponsor APIs:** Auth0 | fit: Used Auth0 for one-click GitHub sign-in that grants access to the user's public and private repositories.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 16, writeup medium, impact claims False
- **Notes:** SVG-built branch graph with per-commit AI summaries comparing each commit to its predecessor, plus a count of undocumented commits across repos; also lists TerpAI among built-with items.
- **Team size:** 2 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/docket-2r9wke)

### DoortectiveAI  (Bitcamp 2026)

- **Prizes:** People's Choice Hack - Bitcamp; [MLH] Best Use of ElevenLabs [unknown]  (tier: track_winner)
- **Pitch:** A smart door assistant on Raspberry Pi that recognizes faces, talks to visitors by voice, verifies codes, and phones the homeowner when it detects a threat.
- **Problem / user:** Home security cameras only record and notify after the fact; the team wanted a system that verifies and reacts to visitors in real time. / homeowners
- **Domain / idea type:** safety_security + accessibility / hardware_gadget
- **Platforms / hardware / AI:** web; hardware / True / vision; speech_or_voice; llm_chat; agent_or_tool_use
- **Stack:** langs Python; TypeScript; frontend Next.js; backend FastAPI; db ; hosting 
- **Tech/APIs:** ElevenLabs (ai_model, core, sponsor); Google Gemini (ai_model, core); YOLO (ai_model, core); OpenCV (framework, core); Raspberry Pi (hardware_part, core); FastAPI (framework, supporting); Next.js (framework, supporting)
- **Sponsor APIs:** ElevenLabs | fit: Used ElevenLabs for the door assistant's real-time spoken, multilingual voice interaction with visitors.
- **Repo:** private_or_missing, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 25, writeup medium, impact claims True (Cites over 1 million US burglaries reported each year as motivation.)
- **Notes:** Edge setup with Raspberry Pi camera, YOLO/OpenCV detection, Gemini reasoning and ElevenLabs voice, with multilingual support and emergency phone escalation; dashboard shows known and unknown visitors.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish; repo_clone_failed
- **Links:** [Devpost](https://devpost.com/software/doortective) | [GitHub](https://github.com/orgs/Doortective/repositories)

### EchoLocate  (Bitcamp 2026)

- **Prizes:** Best Moonshot Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** A game-style cyber forensics simulation set in a lunar city where players hire AI investigator agents and link evidence to reconstruct how a breach spread.
- **Problem / user:** Investigating attacks means manually tracing activity across many systems; the team explored an interactive interface for assembling that evidence. / security analysts and students
- **Domain / idea type:** safety_security + entertainment_games / entertainment_or_game
- **Platforms / hardware / AI:** web / False / agent_or_tool_use; llm_chat; speech_or_voice
- **Stack:** langs Python; TypeScript; frontend React; Phaser.js; Tiled; Aseprite; backend FastAPI; db ; hosting Vercel
- **Tech/APIs:** Google Gemini (ai_model, core); OpenAI (ai_model, supporting); ElevenLabs (ai_model, supporting, sponsor); Phaser.js (framework, core); FastAPI (framework, supporting); React (framework, supporting); Vercel (cloud, supporting)
- **Sponsor APIs:** ElevenLabs | fit: Entered for Bitcamp's Best Moonshot Hack with a lunar-city cyber investigation simulation using multi-agent AI.
- **Repo:** public, commits 87 (before/in/after event: 0/83/4), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 19, writeup medium, impact claims False
- **Notes:** Phaser game map of infrastructure sectors with an agent-hiring marketplace, incident alerts and a dynamic evidence graph; AI agents investigate simulated logs.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/echolocate-e4k3dg) | [GitHub](https://github.com/SujayCh07/bitcamp)

### eleQt  (Bitcamp 2026)

- **Prizes:** Best Computational Quantum Track Hack [unknown]  (tier: track_winner)
- **Pitch:** Quantum-secure voting protocol using quantum oblivious transfer, QKD and GMW with zero-knowledge proofs, tested on IBM hardware and Qiskit simulation.
- **Problem / user:** Future quantum attacks could break classical election cryptography, so vote tallying needs a trustless, verifiable quantum-safe scheme. / election systems researchers
- **Domain / idea type:** civic_legal + safety_security / new_category
- **Platforms / hardware / AI:** web / False / llm_chat
- **Stack:** langs Python; JavaScript; frontend React; Vite; Tailwind CSS; backend FastAPI; Qiskit; db ; hosting 
- **Tech/APIs:** Qiskit (framework, core); IBM Quantum (cloud, core); Gemini (ai_model, unclear); Claude (ai_model, unclear); FastAPI (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 51 (before/in/after event: 0/49/2), README detailed
- **Demo/writeup:** video True, live none, screenshots 4, writeup medium, impact claims False
- **Notes:** Research-style writeup with motivation, challenges, breakthrough and conclusion; claims implementation on IBM hardware; web demo and slides pictured.
- **Team size:** 3 | **Confidence:** medium | unverified: ai_used; ai_types; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/qrypt) | [GitHub](https://github.com/prakriti-shahi/bitcamp)

### Extract  (Bitcamp 2026)

- **Prizes:** [MLH] Best Use of Solana [unknown]  (tier: sponsor_winner)
- **Pitch:** Records each handoff in the vanilla supply chain as a dual-signed Solana transaction and shows the farm-to-shelf journey on an interactive map.
- **Problem / user:** Consumers cannot verify 'pure' vanilla and farmers are paid little, because the supply chain is opaque and paper-based. / vanilla farmers, buyers and consumers
- **Domain / idea type:** retail_consumer + fintech_finance / new_category
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs Rust; TypeScript; frontend Next.js; React; Tailwind CSS; Leaflet.js; Mapbox; Recharts; backend Express.js; Node.js; node-cron; db PostgreSQL; hosting 
- **Tech/APIs:** Solana (other, core, sponsor); Anchor (framework, core); SPL Memo (other, supporting); Mapbox (maps_geo, supporting); Leaflet.js (maps_geo, supporting); PostgreSQL (database, supporting); Next.js (framework, supporting)
- **Sponsor APIs:** Solana | fit: Wrote supply-chain handoffs on-chain with an Anchor program as dual-signed Solana transactions carrying structured event data.
- **Repo:** public, commits 33 (before/in/after event: 0/33/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 1, writeup medium, impact claims True (Cites up to 80% of 'pure' vanilla being adulterated and a roughly 250x farm-to-retail price markup, attributed to World Bank and FDA data.)
- **Notes:** Anchor (Rust) program stores weight, price, grade, GPS and lab results on Solana via dual-signed transfers between supply chain parties; web app maps each hop.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/vanillatrail) | [GitHub](https://github.com/YetiClimber/Extract)

### GaitGuard  (Bitcamp 2026)

- **Prizes:** Most Philanthropic Hack - Bloomberg [unknown]  (tier: sponsor_winner)
- **Pitch:** A wearable ESP32 and motion-sensor device in a 3D-printed case scores fall risk in real time, shows it on a live dashboard and triggers an alert.
- **Problem / user:** Elderly and stroke or heart patients living alone can lie unattended after falls, and current systems miss early instability signs. / elderly people living independently and their caregivers
- **Domain / idea type:** health_wellness + accessibility / hardware_gadget
- **Platforms / hardware / AI:** web; hardware / True / predictive_ml
- **Stack:** langs Python; C++; JavaScript; HTML; CSS; frontend HTML; CSS; JavaScript; backend Flask; db ; hosting 
- **Tech/APIs:** ESP32 (hardware_part, core); Motion sensors (hardware_part, core); Logistic regression (ai_model, core); Flask (framework, supporting); Arduino (other, supporting)
- **Sponsor APIs:**  | fit: Targeted Bloomberg's Most Philanthropic Hack with a fall-detection wearable aimed at independent-living elderly users; no Bloomberg tool is used.
- **Repo:** public, commits 13 (before/in/after event: 0/11/2), README detailed
- **Demo/writeup:** video False, live none, screenshots 16, writeup medium, impact claims False
- **Notes:** Prototype combines ESP32, motion sensors, LED panel and a logistic-regression fall-probability model with a Flask dashboard; motivated by the author's grandmother's falls.
- **Team size:** 1 | **Confidence:** medium | unverified: ui_polish; ai_types; problem_statement
- **Links:** [Devpost](https://devpost.com/software/gaitguard-fk2tb7) | [GitHub](https://github.com/Schugh26/GaitGuard)

### GhostKode  (Bitcamp 2026)

- **Prizes:** [MLH] Best Use of Auth0 AI Agents [unknown]  (tier: sponsor_winner)
- **Pitch:** Scores each line of a file by how unstable its Git history is, overlays ghost icons, and streams an AI forensic explanation and suggested fix.
- **Problem / user:** New developers inherit fragile code with no context; the reasons live in Git history that is hard to read. / developers onboarding to codebases
- **Domain / idea type:** dev_tools + ai_agents_infra / dev_tool
- **Platforms / hardware / AI:** web / False / llm_chat; agent_or_tool_use; rag_or_search
- **Stack:** langs TypeScript; frontend Next.js; Tailwind CSS; backend ; db ; hosting 
- **Tech/APIs:** Auth0 (auth, core, sponsor); GitHub API (data_source, core); Google Gemini (ai_model, core); OpenAI embeddings (ai_model, supporting); Next.js (framework, supporting)
- **Sponsor APIs:** Auth0 | fit: Used Auth0 for GitHub OAuth login, with a Post Login Action passing the GitHub access token into the session so an AI agent can call the GitHub API on the user's behalf.
- **Repo:** public, commits 4 (before/in/after event: 0/4/0), README solid
- **Demo/writeup:** video True, live none, screenshots 13, writeup medium, impact claims False
- **Notes:** Blends embedding similarity and keyword signals over GitHub blame and commit data to rank unstable lines, then a streaming agent cites real authors and messages with follow-up chat.
- **Team size:** 1 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/ghostkode) | [GitHub](https://github.com/bbmullen72/ghostkode)

### Methods for Computing the ANNNI Model Phase Diagram  (Bitcamp 2026)

- **Prizes:** Best Scientific Quantum Track Hack [unknown]  (tier: track_winner)
- **Pitch:** Quantum-physics project on computing the ANNNI spin-model phase diagram; page only links an external paper-style writeup.
- **Problem / user:** Computing the ANNNI model phase diagram with classical and quantum methods; the page gives no further problem detail. / quantum physics researchers
- **Domain / idea type:** other / data_or_analytics
- **Platforms / hardware / AI:** cli / False / False
- **Stack:** langs Python; frontend ; backend ; db ; hosting 
- **Sponsor APIs:** 
- **Repo:** public, commits 3 (before/in/after event: 0/3/0), README detailed
- **Demo/writeup:** video False, live none, screenshots 1, writeup short, impact claims False
- **Notes:** Devpost page has almost no text and points to an Overleaf writeup; one member notes raising classically solvable size from 8 to 12 spins.
- **Team size:** 2 | **Confidence:** medium | unverified: one_line_pitch; problem_statement; platforms; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/methods-of-computing-the-annni-model-phase-diagram) | [GitHub](https://github.com/9t8/Bitcamp-2026-Quantum)

### MindMirror  (Bitcamp 2026)

- **Prizes:** Best Advanced Data Science Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Analyzes exported ChatGPT/Claude histories with Gemini into a cognitive profile and maps topics to predicted brain activation using Meta's TRIBE v2 model.
- **Problem / user:** People rely heavily on AI chat but have no view of what that dependence reveals about, or does to, their thinking. / heavy AI chat users
- **Domain / idea type:** mental_health + health_wellness / data_or_analytics
- **Platforms / hardware / AI:** web / False / llm_chat; predictive_ml
- **Stack:** langs TypeScript; JavaScript; Python; frontend Next.js; React; Tailwind; Three.js; D3; Recharts; backend FastAPI; Node.js; PyTorch; db ; hosting 
- **Tech/APIs:** Google Gemini (ai_model, core); TRIBE v2 (ai_model, core); Claude (ai_model, token); Next.js (framework, supporting); FastAPI (framework, supporting); PyTorch (framework, supporting); Three.js (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 41 (before/in/after event: 0/20/21), README detailed
- **Demo/writeup:** video True, live none, screenshots 10, writeup long, impact claims False
- **Notes:** Runs text-only TRIBE v2 fMRI-prediction inference in a separate Python service and renders a 3D cortical heatmap; chat export parsed in-browser; also radar chart and topic bubble map.
- **Team size:** 4 | **Confidence:** high | unverified: sponsor flags; n_screenshots; Claude depth
- **Links:** [Devpost](https://devpost.com/software/mindmirror-2aizuh) | [GitHub](https://github.com/Raghav-Chakravarthy/MindMirror)

### Nara - Autonomous Red Teaming Agent  (Bitcamp 2026)

- **Prizes:** Best Champion of Open Source w/ Featherless - Featherless; Neelbauer Agentic Revolution Award (NARA) - Alumni Prize [unknown]  (tier: sponsor_winner)
- **Pitch:** A CLI that runs four AI agents to scan code, plan a MITRE ATT&CK kill chain, exploit an isolated Docker target and report defensive advice.
- **Problem / user:** Static scanners list vulnerabilities without showing real exploitation, so learners and teams can't tell what LLM-claimed exploits actually work. / security students and red/blue teams
- **Domain / idea type:** safety_security + ai_agents_infra / automation_or_agent
- **Platforms / hardware / AI:** cli / False / agent_or_tool_use; llm_chat
- **Stack:** langs Python; frontend Rich; prompt-toolkit; backend Flask; Docker; db ; hosting Docker
- **Tech/APIs:** Featherless AI (Phi-4-mini) (ai_model, supporting, sponsor); Anthropic Claude API (ai_model, core); Ollama (Qwen2.5) (ai_model, supporting); Semgrep (other, core); Bandit (other, core); Docker (other, core); TerpAI (UMD) (ai_model, unclear); noVNC / TigerVNC (other, supporting)
- **Sponsor APIs:** Featherless AI | fit: Listed Featherless-hosted Phi-4-mini among its models for the Champion of Open Source prize, and built a multi-agent system targeting the NARA agentic award.
- **Repo:** public, commits 85 (before/in/after event: 0/83/2), README detailed
- **Demo/writeup:** video True, live none, screenshots 13, writeup long, impact claims False
- **Notes:** Scanner, planner, exploiter and reporting agents work inside a sandboxed Ubuntu container with noVNC desktop; mixes Claude API with local Ollama Qwen and Featherless-hosted Phi-4-mini.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/nara-autonomous-red-teaming-agent) | [GitHub](https://github.com/HackedRico/obv-nara-box)

### QuantumQuest QCNN  (Bitcamp 2026)

- **Prizes:** Best Scientific Quantum Track Hack [unknown]  (tier: track_winner)
- **Pitch:** Quantum convolutional neural network that classifies Hamiltonian parameters into phases, built with JAX and PennyLane.
- **Problem / user:** Classify quantum many-body phases from Hamiltonian parameters; the writeup is sparse and points to a separate document. / quantum physics researchers
- **Domain / idea type:** other + ai_agents_infra / data_or_analytics
- **Platforms / hardware / AI:** cli / False / predictive_ml
- **Stack:** langs Python; frontend ; backend JAX; PennyLane; Optax; db ; hosting 
- **Tech/APIs:** PennyLane (framework, core); JAX (framework, core); Optax (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live none, screenshots 12, writeup short, impact claims False
- **Notes:** Writeup is placeholder-style and tells readers to read an external linked document; code is on Codeberg, not GitHub.
- **Team size:** 3 | **Confidence:** medium | unverified: one_line_pitch; problem_statement; platforms; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/quantumquest-qcnn)

### QWave  (Bitcamp 2026)

- **Prizes:** Best Digital Forensics Related Hack - Cipher Tech Solutions [unknown]  (tier: sponsor_winner)
- **Pitch:** Hybrid quantum-classical tool that simulates noise on audio with Qiskit to tell natural noise from adversarial perturbations, plus a Gmail-attachment monitoring pipeline.
- **Problem / user:** Error correction fixes quantum noise but cannot tell whether it is natural or maliciously crafted, leaving a blind spot for audio-borne attacks. / security teams handling audio inputs
- **Domain / idea type:** safety_security / dev_tool
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs Python; frontend Streamlit; Matplotlib; backend Qiskit; Qiskit Aer; NumPy; SciPy; pandas; db ; hosting Google Cloud Run; Docker
- **Tech/APIs:** Qiskit (framework, core); Qiskit Aer (framework, core); Streamlit (framework, supporting); Google Cloud Run (cloud, supporting); Gmail SMTP/IMAP (other, supporting); SciPy (framework, supporting)
- **Sponsor APIs:**  | fit: Targeted Cipher Tech's digital forensics prize with a detector that analyzes audio noise signatures to flag adversarial manipulation.
- **Repo:** public, commits 10 (before/in/after event: 0/10/0), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 28, writeup long, impact claims False
- **Notes:** Uses Qiskit noise-channel simulation and Jensen-Shannon divergence to classify noise, with a Streamlit UI on Cloud Run and an MVP that scans incoming Gmail audio attachments automatically.
- **Team size:** 3 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/quanterp) | [GitHub](https://github.com/shreya222mishra/bitcamp-2026)

### Recall  (Bitcamp 2026)

- **Prizes:** Most Philanthropic Hack - Bloomberg [unknown]  (tier: sponsor_winner)
- **Pitch:** iOS app for early-stage dementia that recognizes faces through the camera and shows who the person is and what was last discussed, plus recorded chats and memory games.
- **Problem / user:** People with dementia struggle to recognize loved ones and recall past conversations, eroding confidence and connection. / early-stage dementia patients and families
- **Domain / idea type:** health_wellness + accessibility / twist_on_known_app
- **Platforms / hardware / AI:** mobile_ios / False / vision; llm_chat
- **Stack:** langs Swift; Python; frontend Swift; Xcode; backend Flask; Ollama; db ; hosting 
- **Tech/APIs:** InsightFace (ai_model, core); Ollama (ai_model, supporting); Flask (framework, supporting); Swift / Xcode (framework, core)
- **Sponsor APIs:**  | fit: Targeted Bloomberg's Most Philanthropic Hack with a face-recognition memory aid for dementia patients; no Bloomberg tool is used.
- **Repo:** public, commits 29 (before/in/after event: 0/28/1), README detailed
- **Demo/writeup:** video True, live none, screenshots 19, writeup medium, impact claims True (Cites more than 50 million people worldwide living with dementia.)
- **Notes:** Swift prototype with InsightFace recognition and a Flask plus Ollama backend for conversation summaries; team notes AR glasses as the intended future form but limited to mobile.
- **Team size:** 3 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/recall-1wr8y9) | [GitHub](https://github.com/akhilapnuri/RecallMobileApp)

### Sleeply  (Bitcamp 2026)

- **Prizes:** Best First Time Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Interactive sleep visualizer that models a night from user inputs and shows stage timeline, 3D brain activity, brainwave graphs and a sleep score.
- **Problem / user:** Brain activity during sleep is hard to picture, and sleep visualization tools are not intuitive or free. / general users curious about sleep and brainwaves
- **Domain / idea type:** health_wellness + education / creative_tool
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs ; frontend React; Vite; Three.js; React Three Fiber; backend ; db ; hosting Vercel
- **Tech/APIs:** Three.js (framework, core); React Three Fiber (framework, core); React (framework, core)
- **Sponsor APIs:** 
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 6, writeup long, impact claims False
- **Notes:** Solo build with 18 color themes and a tutorial; sleep is simulated from questionnaire inputs rather than measured; no repo listed.
- **Team size:** 1 | **Confidence:** high | unverified: n_screenshots
- **Links:** [Devpost](https://devpost.com/software/sleeply)

### Still Here  (Bitcamp 2026)

- **Prizes:** Best Use of Netcore - Netcore [unknown]  (tier: sponsor_winner)
- **Pitch:** A one-tap daily check-in PWA that escalates through push, email, SMS to emergency contacts and a non-emergency wellness check if the user does not respond.
- **Problem / user:** People living alone could go unnoticed for days after an incident, and existing safety products feel clinical and subscription-based. / young adults living alone
- **Domain / idea type:** safety_security + health_wellness / twist_on_known_app
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs Python; JavaScript; frontend Vanilla JS PWA; backend FastAPI; Celery; Redis; SQLAlchemy; db Supabase Postgres; hosting Docker Compose; Caddy
- **Tech/APIs:** Twilio (telecom, core); Resend (other, supporting); Firebase FCM (other, supporting); AWS SNS (cloud, supporting); Supabase (database, supporting); Auth0 (auth, token, sponsor); Celery / Redis (framework, core); FastAPI (framework, supporting)
- **Sponsor APIs:**  | fit: Entered for the Netcore prize with a notification-escalation product (push, email, SMS); the page does not name a Netcore product.
- **Repo:** private_or_missing, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 10, writeup medium, impact claims True (Cites 36 million Americans living alone.)
- **Notes:** Configurable grace period (for trips) before an escalation chain run by Celery Beat timers; also offers API keys for IoT integrations and installs as a PWA without an app store.
- **Team size:** 1 | **Confidence:** high | unverified: ui_polish; sponsor_fit_note; repo_clone_failed
- **Links:** [Devpost](https://devpost.com/software/still-here) | [GitHub](https://github.com/xyzmr114/stillhere)

### Terrametric  (Bitcamp 2026)

- **Prizes:** Real World Prize - Ambrook; Best Champion of Open Source w/ Featherless - Featherless; Best Intermediate Data Science Track Hack - Bitcamp [unknown]  (tier: sponsor_winner)
- **Pitch:** Farm console that scores crop stress from satellite signals, forecasts yield and losses, and prescribes irrigation, with a Qwen-based agronomy copilot.
- **Problem / user:** Satellite data can flag crop stress weeks early but does not reach farmers as timely, actionable decisions. / farmers and agronomists
- **Domain / idea type:** sustainability_climate + fintech_finance / data_or_analytics
- **Platforms / hardware / AI:** web / False / predictive_ml; llm_chat; agent_or_tool_use; rag_or_search
- **Stack:** langs Python; TypeScript; GLSL; frontend Next.js; React; backend FastAPI; Uvicorn; XGBoost; db SQLite; hosting Vercel
- **Tech/APIs:** XGBoost (ai_model, core); Qwen 2.5 (ai_model, core, sponsor); NASA SMAP (data_source, core); USDA extension reports (data_source, supporting); FastAPI (framework, supporting)
- **Sponsor APIs:** Featherless | fit: Open-source Qwen 2.5 powers the agronomy copilot (Featherless prize); page does not name Featherless itself.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots None, writeup medium, impact claims False
- **Notes:** Fuses optical indices with NASA SMAP radar-based soil moisture to handle cloud cover; XGBoost stress model then a dollar-loss model; 3D globe; copilot has 11 tools. No repo listed.
- **Team size:** 3 | **Confidence:** medium | unverified: n_screenshots; sponsor_apis_used
- **Links:** [Devpost](https://devpost.com/software/terrametric)

### Thats My Echo  (Bitcamp 2026)

- **Prizes:** [MLH] Best Domain Name from GoDaddy Registry [unknown]  (tier: sponsor_winner)
- **Pitch:** A 2D Unity platformer where you play a breath of wind and place echoes that replay your movements, waking an enemy that reacts to them.
- **Problem / user:** Platformers reset failures as if nothing happened; the team wanted deaths and past attempts to persist and matter in the level. / platformer players
- **Domain / idea type:** entertainment_games + creative_media / entertainment_or_game
- **Platforms / hardware / AI:** desktop; web / False / False
- **Stack:** langs C#; frontend Unity; backend ; db ; hosting itch.io
- **Tech/APIs:** Unity (framework, core); GoDaddy Registry domain (.us) (other, core, sponsor); Procreate / Photoshop (other, supporting); itch.io (other, supporting)
- **Sponsor APIs:** GoDaddy Registry | fit: Listed the game at a GoDaddy Registry domain (catecholl.us) for the Best Domain Name prize.
- **Repo:** public, commits 4 (before/in/after event: 0/4/0), README solid
- **Demo/writeup:** video True, live not_checked, screenshots 16, writeup short, impact claims False
- **Notes:** Echo mechanic records and replays player movement; hand-drawn art in Procreate/Photoshop; also hosted on itch.io under a GoDaddy Registry domain (catecholl.us).
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/thatsmyecho) | [GitHub](https://github.com/Parth12358/ThatsMyEcho)

### Tseda  (Bitcamp 2026)

- **Prizes:** Best Machine Learning Track Hack - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Generates novel drug-candidate compounds from a described disease or molecule, then scores candidates for risk with a fine-tuned ML model and an in-browser chemical editor.
- **Problem / user:** Preclinical drug design and synthesis planning is slow, repetitive and costly, with no guarantee a candidate is useful. / drug discovery researchers
- **Domain / idea type:** health_wellness + ai_agents_infra / dev_tool
- **Platforms / hardware / AI:** web / False / llm_chat; predictive_ml
- **Stack:** langs TypeScript; Python; frontend React; Next.js; Tailwind; ChemDoodle; backend Python; db ; hosting 
- **Tech/APIs:** Anthropic Claude API (ai_model, core); Google Gemini (ai_model, supporting); MLM-FG (ai_model, core); ChemBERTa (ai_model, unclear); ChemDoodle (other, core); Google Stitch (other, token); Next.js (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 89 (before/in/after event: 0/89/0), README detailed
- **Demo/writeup:** video False, live none, screenshots 8, writeup long, impact claims True (Says one drug costs billions and decades, with over a third of resources going to preclinical work.)
- **Notes:** Pairs LLM compound generation with MLM-FG risk indicators and a ChemDoodle drawing canvas with MOL import; team swapped from ChemBERTa after it lacked needed indicators.
- **Team size:** 4 | **Confidence:** high | unverified: sponsor flags; n_screenshots; has_demo_video
- **Links:** [Devpost](https://devpost.com/software/tseda) | [GitHub](https://github.com/LittleWhole/Tseda)

### X - Protocol  (Bitcamp 2026)

- **Prizes:** Bitcamp Unwrapped - Bitcamp [unknown]  (tier: track_winner)
- **Pitch:** Scans nearby Bluetooth devices, shows them as orbiting nodes on a star map, and has GPT-4o-mini write invitation letters that visitors open by scanning a QR code.
- **Problem / user:** People in crowded rooms are physically near each other yet invisible and unconnected; the author wanted a consent-first way to surface proximity. / people in shared physical spaces
- **Domain / idea type:** social_community / new_category
- **Platforms / hardware / AI:** web; mobile_cross / False / llm_chat; generative_media
- **Stack:** langs Python; JavaScript; frontend React; Vite; Canvas; backend FastAPI; asyncio; WebSocket; Bleak; db ; hosting Cloudflare
- **Tech/APIs:** OpenAI GPT-4o-mini (ai_model, core); Google Gemini (ai_model, supporting); Bleak (BLE) (other, core); GoDaddy domain (other, supporting, sponsor); Cloudflare (cloud, supporting); JetBrains (other, token, sponsor); FastAPI (framework, supporting); React (framework, supporting)
- **Sponsor APIs:** GoDaddy Registry | fit: Won Bitcamp's own Unwrapped prize; also lists a GoDaddy domain (xprotocol.us) and JetBrains among its tools.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live not_checked, screenshots 19, writeup medium, impact claims False
- **Notes:** Python Bleak BLE scanner maps RSSI distance to node orbit on a canvas star map; AI letters, QR portal chat and a session footprint panel; page lists GoDaddy and JetBrains among built-with items.
- **Team size:** 1 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/x-ai)
