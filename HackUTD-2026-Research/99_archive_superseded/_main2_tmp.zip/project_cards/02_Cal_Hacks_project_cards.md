# Cal Hacks: project cards (23 projects)

Facts and short paraphrases only; no cross-project analysis. Full records are in the workbook and JSONL.

## Cal Hacks 11.0 (2024)

### Blockify  (Cal Hacks 11.0 (2024))

- **Prizes:** Winner Cal Hacks / Berkeley RDI: Berkeley RDI Web3 Prize [unknown]; Winner Sui: Reimagine the internet with Sui [unknown]  (tier: sponsor_winner)
- **Pitch:** Blockchain royalty platform where artists attach Sui smart contracts to uploaded music so payouts trigger automatically from Spotify stream counts.
- **Problem / user:** Artists lose ownership and most revenue to labels and distributors, and royalty payments are slow and opaque. / independent music artists
- **Domain / idea type:** creative_media + fintech_finance / new_category
- **Platforms / hardware / AI:** web / False / False
- **Stack:** langs Move; JavaScript; frontend React; backend Node.js; db ; hosting 
- **Tech/APIs:** Sui blockchain (other, core, sponsor); Move (framework, core, sponsor); Sui SDK / wallets (other, core, sponsor); Spotify API (data_source, core); React (framework, supporting); Node.js (framework, supporting)
- **Sponsor APIs:** Sui | fit: Targeted the Sui challenge by writing Move smart contracts on Sui and integrating Sui wallets/SDK to pay royalties.
- **Repo:** public, commits 5 (before/in/after event: 5/0/0), README none
- **Demo/writeup:** video True, live none, screenshots 1, writeup medium, impact claims False
- **Notes:** Smart contracts written in Move on Sui; Spotify API stream data meant to trigger wallet payments; first blockchain project for both teammates.
- **Team size:** 2 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/blockify-x2owt7) | [GitHub](https://github.com/ChiragSeth14/CalHacks)

### Duet: Brainwaves -> Live Music  (Cal Hacks 11.0 (2024))

- **Prizes:** Winner Cal Hacks: 1st Overall [1st]  (tier: overall_top3)
- **Pitch:** EEG headset reads focus and relaxation and a Gemini-driven live composer turns them into adaptive Sonic Pi music, aimed at kids with developmental disabilities.
- **Problem / user:** Children with developmental disabilities, especially non-verbal ones, lack tools to express emotion and creativity through music. / children with developmental disabilities, music therapists
- **Domain / idea type:** accessibility + creative_media / creative_tool
- **Platforms / hardware / AI:** web; hardware / True / llm_chat; generative_media
- **Stack:** langs Python; Ruby; JavaScript; frontend Next.js; three.js; backend Python; Emotiv Cortex library; Sonic Pi; db SingleStore; hosting 
- **Tech/APIs:** Emotiv EEG headset (hardware_part, core); Google Gemini (ai_model, core); Sonic Pi (framework, core); SingleStore (database, supporting, sponsor); Next.js (framework, supporting); three.js (framework, supporting)
- **Sponsor APIs:** SingleStore
- **Repo:** public, commits 12 (before/in/after event: 12/0/0), README solid
- **Demo/writeup:** video None, live none, screenshots 5, writeup long, impact claims True (Cites 1 in 10 US children with developmental disabilities and a 15.59% projected music therapy market growth rate.)
- **Notes:** LLM acts as a live composer each few seconds using recent EEG state, available instruments and its prior output; Sonic Pi plays it; Three.js 3D brain visualiser.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; n_screenshots; SingleStore is_sponsor; ui_polish; event dates from memory
- **Links:** [Devpost](https://devpost.com/software/duet-0tbkxe) | [GitHub](https://github.com/daniel04wawng/duet-frontend ; https://github.com/soapantelope/duet-backend)

### GhostWriter  (Cal Hacks 11.0 (2024))

- **Prizes:** Winner Cal Hacks: 2nd Overall [2nd]  (tier: overall_top3)
- **Pitch:** Listens to live office-hour conversation and automatically inserts the useful points into the right lines of course notes using transcription, retrieval and LLM edits.
- **Problem / user:** Short-staffed teaching assistants struggle to keep course notes and documentation updated while helping students. / teaching assistants and instructors
- **Domain / idea type:** education + productivity_workplace / automation_or_agent
- **Platforms / hardware / AI:** web / False / llm_chat; rag_or_search; speech_or_voice
- **Stack:** langs Python; frontend Reflex; React; backend Reflex; Python; db ChromaDB; hosting 
- **Tech/APIs:** Deepgram live transcription (ai_model, core); Google Gemini (summaries, embeddings) (ai_model, core); ChromaDB (database, core); Groq (llama3-70b) (ai_model, core); Reflex (framework, core)
- **Sponsor APIs:** 
- **Repo:** public, commits 24 (before/in/after event: 24/0/0), README solid
- **Demo/writeup:** video None, live none, screenshots 4, writeup long, impact claims False
- **Notes:** Inserts generated markdown at line-level points using unique tokens in the source text; embedding distance thresholds decide whether to skip, append or create a note.
- **Team size:** 2 | **Confidence:** medium | unverified: has_demo_video; ui_polish; event dates from memory; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/ghostwriter-491kuy) | [GitHub](https://github.com/rqchao/calhacks24)

### MafiAI  (Cal Hacks 11.0 (2024))

- **Prizes:** Winner Cal Hacks: Hack on AI [unknown]  (tier: track_winner)
- **Pitch:** Party game of Mafia in which LLM-driven characters discuss and vote to work out who the mafia are.
- **Problem / user:** Not stated on the page; the project applies LLM agents to a social deduction game. / casual game players
- **Domain / idea type:** entertainment_games + ai_agents_infra / entertainment_or_game
- **Platforms / hardware / AI:** web / False / llm_chat; agent_or_tool_use; speech_or_voice
- **Stack:** langs Python; TypeScript; frontend React; backend Python; WebSockets; db ; hosting 
- **Tech/APIs:** Groq (ai_model, unclear); Gemini (ai_model, unclear); Cartesia (ai_model, unclear); React (framework, supporting); WebSockets (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 15 (before/in/after event: 15/0/0), README thin
- **Demo/writeup:** video True, live none, screenshots 2, writeup short, impact claims False
- **Notes:** Page is a one-line blurb with no sections; stack named as Python, React, TypeScript, websockets plus Cartesia, Groq and Gemini.
- **Team size:** 1 | **Confidence:** medium | unverified: ui_polish; problem_statement
- **Links:** [Devpost](https://devpost.com/software/mafiai) | [GitHub](https://github.com/KevinL10/mafia)

### Resililink  (Cal Hacks 11.0 (2024))

- **Prizes:** Winner Cal Hacks: Hack for Impact [unknown]; Winner Skylo: Seamlessly Switch from Cellular to Satellite [unknown]  (tier: sponsor_winner)
- **Pitch:** LoRa mesh network of cheap ESP32 nodes whose satellite-equipped super node relays messages via Skylo to a server that texts recipients through Twilio and returns an acknowledgment.
- **Problem / user:** During hurricanes and other disasters, cell and internet service fails and people cannot contact family or responders. / people in disaster-prone regions and emergency contacts
- **Domain / idea type:** telecom_networking + safety_security / hardware_gadget
- **Platforms / hardware / AI:** hardware; web / True / False
- **Stack:** langs Python; JavaScript; frontend React; Vite; backend Python; MQTT; Protocol Buffers; db ; hosting Microsoft Azure
- **Tech/APIs:** Skylo satellite connectivity (telecom, core, sponsor); LoRa radio / ESP32 (hardware_part, core); Twilio SMS (telecom, core); Microsoft Azure (cloud, supporting); MQTT (framework, supporting); Protocol Buffers (framework, supporting); Raspberry Pi (hardware_part, supporting); React/Vite (framework, supporting)
- **Sponsor APIs:** Skylo | fit: Targeted the Skylo challenge by using a Skylo satellite modem on a super node to bridge LoRa mesh traffic to the internet over MQTT.
- **Repo:** public, commits 5 (before/in/after event: 5/0/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 4, writeup long, impact claims False
- **Notes:** Custom protobuf protocol within a 256-byte packet limit; Skylo satellite modem evaluation board with poorly documented AT commands; MQTT to an Azure-hosted server; nodes are one LoRa radio plus ESP32.
- **Team size:** 2 | **Confidence:** high | unverified: ui_polish; live_demo_url
- **Links:** [Devpost](https://devpost.com/software/resilink) | [GitHub](https://github.com/12458/calhacks)

### SnackSnap - recycle to feed your pet  (Cal Hacks 11.0 (2024))

- **Prizes:** Winner Cal Hacks: 3rd Overall [3rd]  (tier: overall_top3)
- **Pitch:** iOS app where you photograph yourself recycling, Gemini validates the photo, and you feed a digital pet and earn XP rewards.
- **Problem / user:** Recycling feels inconvenient so people throw recyclables in the trash; a pet game makes it rewarding. / everyday consumers, recycling-minded phone users
- **Domain / idea type:** sustainability_climate + entertainment_games / twist_on_known_app
- **Platforms / hardware / AI:** mobile_ios / False / vision
- **Stack:** langs Swift; frontend SwiftUI; backend Firebase; db Firebase; hosting Firebase Storage
- **Tech/APIs:** Google Gemini 1.5 Pro (ai_model, core); Firebase (cloud, supporting); Firebase Storage (cloud, supporting); SwiftUI (framework, core)
- **Sponsor APIs:** 
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live none, screenshots 5, writeup medium, impact claims False
- **Notes:** Gemini image recognition gates the pet-feeding mechanic; XP redeemable for rewards such as early product access.
- **Team size:** 2 | **Confidence:** medium | unverified: has_demo_video; ui_polish; event dates from memory; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/snacksnap-lw4b9q)


## Cal Hacks 12.0 (2025)

### Bob  (Cal Hacks 12.0 (2025))

- **Prizes:** Winner Cal Hacks: Most Creative Hack [unknown]  (tier: track_winner)
- **Pitch:** Agentic AR glasses on Snap Spectacles that watch the wearer's task, answer by voice and highlight objects to guide repairs and builds.
- **Problem / user:** There is a shortage of skilled tradespeople; guidance that watches a physical task in real time could help novices do simple technical work. / homeowners, trade trainees and technicians
- **Domain / idea type:** education + ai_agents_infra / hardware_gadget
- **Platforms / hardware / AI:** hardware; other / True / llm_chat; agent_or_tool_use; vision; speech_or_voice
- **Stack:** langs Python; TypeScript; frontend Lens Studio; backend Python; WebSockets; db ; hosting 
- **Tech/APIs:** Snap Spectacles / Lens Studio (hardware_part, core); Gemini Live (ai_model, core); YOLOE-11 (ai_model, core); Google Generative AI SDK (Search, Maps) (ai_model, supporting); Slack SDK (other, supporting); Gmail via SMTP (other, supporting); WebSockets (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 93 (before/in/after event: 0/93/0), README solid
- **Demo/writeup:** video True, live none, screenshots 1, writeup long, impact claims True (Cites US shortfall of 70,000 electricians and 642,000 mechanics and age share of tradespeople.)
- **Notes:** Spectacles stream video/audio to a Python WebSocket server that proxies Gemini Live; YOLOE-11 text-prompted detection draws bounding-box overlays; tools include Gmail, Slack, Search and Maps.
- **Team size:** 3 | **Confidence:** high | unverified: ui_polish; team_size; is_sponsor
- **Links:** [Devpost](https://devpost.com/software/bob-vj43mq) | [GitHub](https://github.com/raghavrajsah/tethyr/)

### Expungo  (Cal Hacks 12.0 (2025))

- **Prizes:** Winner Promise: Public Impact Prize (sponsored by Promise) [unknown]; Winner Cal Hacks: Greatest Social Impact [unknown]  (tier: sponsor_winner)
- **Pitch:** Web platform that reads uploaded court or RAP sheets, judges criminal record expungement eligibility against state law, talks users through it by voice and fills forms.
- **Problem / user:** Expungement information is hard to find and the official process is long and confusing for people with old convictions. / people seeking record expungement
- **Domain / idea type:** civic_legal + ai_agents_infra / social_good
- **Platforms / hardware / AI:** web / False / llm_chat; rag_or_search; vision; speech_or_voice; agent_or_tool_use
- **Stack:** langs Python; TypeScript; frontend Next.js; Tailwind CSS; backend FastAPI; LangChain; Pydantic; db ChromaDB; hosting 
- **Tech/APIs:** Google Gemini API (ai_model, core); OpenAI GPT-4 (ai_model, core); LiveKit Agents (framework, core); ChromaDB (database, core); LangChain (framework, supporting); FastAPI (framework, supporting); Next.js (framework, supporting)
- **Sponsor APIs:**  | fit: Entered for the Promise public impact prize by building an expungement-eligibility and form-filling assistant; the page does not show use of a Promise product.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video True, live none, screenshots 1, writeup long, impact claims False
- **Notes:** RAG over expungement statutes for all 50 states in ChromaDB, Gemini PDF parsing of scanned RAP sheets, LiveKit voice agent; all data kept in memory with no database.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish; is_sponsor
- **Links:** [Devpost](https://devpost.com/software/clearpathai)

### FaceTimeOS: AI Mac Agent  (Cal Hacks 12.0 (2025))

- **Prizes:** Winner Cal Hacks: 1st Overall [1st]  (tier: overall_top3)
- **Pitch:** Call or iMessage your Mac and a Claude-orchestrated agent answers, runs computer-use tasks, speaks progress back and texts a confirming screenshot.
- **Problem / user:** Remote desktop tools are clunky and visual; people away from their Mac need quick conversational access to files, apps and scripts. / Mac users away from their computer, developers running long scripts
- **Domain / idea type:** ai_agents_infra + productivity_workplace / automation_or_agent
- **Platforms / hardware / AI:** desktop / False / llm_chat; agent_or_tool_use; speech_or_voice
- **Stack:** langs Python; JavaScript; frontend Electron; React; Tailwind CSS; backend Flask; REST; db ; hosting 
- **Tech/APIs:** Claude (ai_model, core, sponsor); Fish Audio (ai_model, core, sponsor); Fetch.ai (other, core, sponsor); Groq (ai_model, supporting, sponsor); Electron (framework, core); Flask (framework, supporting); Hugging Face (ai_model, token)
- **Sponsor APIs:** Claude; Fish Audio; Fetch.ai; Groq
- **Repo:** public, commits 114 (before/in/after event: 0/101/13), README detailed
- **Demo/writeup:** video None, live none, screenshots 4, writeup long, impact claims False
- **Notes:** Uses Fish Audio virtual mic and speaker devices to pipe live FaceTime call audio to the agent and speak replies back, with no official FaceTime API.
- **Team size:** 3 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates from memory; n_screenshots
- **Links:** [Devpost](https://devpost.com/software/facetime-macos-ai-agent) | [GitHub](https://github.com/ThePickleGawd/calhacks-25)

### Hardware Context Protocol (MCP for Hardware)  (Cal Hacks 12.0 (2025))

- **Prizes:** Winner Crater: Play-Do Prize [unknown]; Winner Cal Hacks: Best Hardware Hack [unknown]  (tier: sponsor_winner)
- **Pitch:** SDK and protocol letting LLMs discover and control hardware nodes over a custom TCP pub/sub layer, demoed with an inverse-kinematics robot arm that picks ingredients.
- **Problem / user:** LLMs lack a standard way to sense and act in the physical world, such as household tasks like preparing food. / robotics and hardware developers
- **Domain / idea type:** dev_tools + ai_agents_infra / dev_tool
- **Platforms / hardware / AI:** hardware; desktop / True / llm_chat; agent_or_tool_use; vision
- **Stack:** langs Python; frontend ; backend Flask; TCP; db ; hosting 
- **Tech/APIs:** SOARM101 robot arm (hardware_part, core); OpenCV / AprilTags (framework, core); ASI:One (ai_model, unclear); Flask (framework, supporting); Custom TCP pub/sub layer (framework, core)
- **Sponsor APIs:**  | fit: Won the Crater Play-Do prize with an LLM-driven robot arm demo; the page does not state what Crater required.
- **Repo:** public, commits 95 (before/in/after event: 0/95/0), README solid
- **Demo/writeup:** video True, live none, screenshots 4, writeup long, impact claims False
- **Notes:** JSON hardware-node definitions generate a TCP networking layer; SOARM101 arm needed a custom inverse kinematics solver and simulator; AprilTags with OpenCV supply object positions.
- **Team size:** 4 | **Confidence:** medium | unverified: ui_polish; is_sponsor; sponsor_fit_note
- **Links:** [Devpost](https://devpost.com/software/hardware-context-protocol) | [GitHub](https://github.com/danielzyy/calhacks2025)

### Orbit  (Cal Hacks 12.0 (2025))

- **Prizes:** Winner Fetch AI: Best Use of Fetch AI [unknown]  (tier: sponsor_winner)
- **Pitch:** Multi-agent assistant that listens to meetings and voice commands, turns them into structured actions and executes them via Jira, email and calendar integrations.
- **Problem / user:** Meetings produce action items that rarely get done; note-taking tools record work but do not carry it out. / professionals and teams in meetings
- **Domain / idea type:** productivity_workplace + ai_agents_infra / automation_or_agent
- **Platforms / hardware / AI:** web; bot_or_chat / True / llm_chat; agent_or_tool_use; speech_or_voice
- **Stack:** langs Python; frontend ; backend Python; db ; hosting Fetch.ai Agentverse
- **Tech/APIs:** Fetch.ai Agentverse (other, core, sponsor); Sim.ai (ai_model, core); Composio MCP (framework, core); Omi mic (hardware_part, supporting); Model Context Protocol (framework, core)
- **Sponsor APIs:** Fetch.ai Agentverse | fit: Targeted Best Use of Fetch AI by hosting the autonomous Orbit agent on Fetch.ai Agentverse for persistence and agent collaboration.
- **Repo:** public, commits 11 (before/in/after event: 0/11/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 2, writeup long, impact claims True (Cites 11.3 weekly meeting hours, 57% of week on communication, $29,000 annual cost per employee, and pricing of $20-30 per user.)
- **Notes:** Middleware agent called Nexus connects to any MCP server via Composio; agent hosted on Fetch.ai Agentverse; Omi mic gives voice-triggered commands; writeup includes go-to-market and pricing.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/orbit-n97hqz) | [GitHub](https://github.com/Ganeshmohank/orbit.git)

### Physical Digital Darts (Wii Darts)  (Cal Hacks 12.0 (2025))

- **Prizes:** Winner Cal Hacks: Best Beginner Hack [unknown]  (tier: track_winner)
- **Pitch:** 3D-printed dart with an accelerometer and Arduino that captures a throwing motion and launches a dart on a Python-simulated dartboard.
- **Problem / user:** The team wanted an accessible, immersive Wii-style game that links physical motion to a digital game. / casual gamers
- **Domain / idea type:** entertainment_games / hardware_gadget
- **Platforms / hardware / AI:** hardware; desktop / True / False
- **Stack:** langs Python; Rust; frontend Pygame; backend PySerial; db ; hosting 
- **Tech/APIs:** MPU6050 accelerometer/gyro (hardware_part, core); Arduino Nano (hardware_part, core); Pygame (framework, core); PySerial (framework, supporting); 3D-printed casing (hardware_part, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 36 (before/in/after event: 0/36/0), README detailed
- **Demo/writeup:** video True, live none, screenshots 6, writeup medium, impact claims False
- **Notes:** MPU6050 drift handled with a custom filter and double-tap recalibration; Arduino Nano sends roll/pitch/yaw over serial to a Pygame simulator; team repaired three broken venue 3D printers.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish
- **Links:** [Devpost](https://devpost.com/software/digital-physical-darts-wii-darts) | [GitHub](https://github.com/commonkestrel/physical-digital-darts)

### Ted.AI  (Cal Hacks 12.0 (2025))

- **Prizes:** Winner Cal Hacks: 2nd Overall [2nd]; Winner LiveKit: Most Creative Project [unknown]  (tier: overall_top3)
- **Pitch:** Sensor-laden teddy bear that senses hugs, motion and heart rate, talks with an LLM to calm children, and feeds a clinician dashboard.
- **Problem / user:** Children with anxiety, ADHD or loneliness lack an empathetic companion that helps regulate emotions; parents and clinicians lack visibility. / children with emotional struggles, parents, educators, clinicians
- **Domain / idea type:** mental_health + education / hardware_gadget
- **Platforms / hardware / AI:** hardware; web / True / llm_chat; speech_or_voice; predictive_ml
- **Stack:** langs Python; frontend React; D3.js; backend Flask; LangChain; MQTT; db MongoDB; InfluxDB; Firebase; hosting AWS; Docker
- **Tech/APIs:** ESP32 with pulse, touch and MPU6050 sensors (hardware_part, core); OpenAI Whisper (ai_model, core); OpenAI GPT (ai_model, core); RoBERTa (ai_model, supporting); LangChain (framework, supporting); MQTT (other, supporting); Fetch.ai (other, unclear, sponsor); Gemini (ai_model, unclear); LiveKit (other, unclear, sponsor); AWS (cloud, unclear)
- **Sponsor APIs:** LiveKit; Fetch.ai | fit: LiveKit prize listed; the writeup does not describe LiveKit use, though Fetch.ai appears in Built With.
- **Repo:** none_listed, commits None (before/in/after event: None/None/None), README None
- **Demo/writeup:** video None, live none, screenshots None, writeup long, impact claims False
- **Notes:** ESP32 bear with pulse, touch and accelerometer sensors; fuses sensor data over MQTT; dashboard shows simulated brain-region activations. Long stack list incl. TensorFlow Lite Micro, InfluxDB.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; n_screenshots; ui_polish; sponsor_apis_used; event dates from memory
- **Links:** [Devpost](https://devpost.com/software/ted-ai-x8537t)


## Cal Hacks 13.0 (2026)

### Arigami  (Cal Hacks 13.0 (2026))

- **Prizes:** Winner Cal Hacks Best Beginner Hack [unknown]  (tier: track_winner)
- **Pitch:** Chrome/Edge extension that rewrites the current page into a layout for focus, motor-impairment or screen-reader needs, with optional AI redesign and head-tracking navigation.
- **Problem / user:** Websites are hard for people with motor impairments or other accessibility needs to use independently. / people with motor impairments, attention or vision accessibility needs
- **Domain / idea type:** accessibility + dev_tools / creative_tool
- **Platforms / hardware / AI:** browser_extension / False / llm_chat; vision
- **Stack:** langs JavaScript; frontend Chrome Manifest V3 extension; Figma; backend ; db ; hosting Figma Sites
- **Tech/APIs:** Claude (ai_model, supporting); Apify (other, supporting); Figma (other, supporting); Chrome Manifest V3 (framework, core)
- **Sponsor APIs:** 
- **Repo:** public, commits 5 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 1, writeup long, impact claims False
- **Notes:** Three accessibility modes; scroll gradient and head-tracking replace a planned eye-tracker; AI redesign path uses Apify scraping plus Claude; designs prototyped in Figma and code written with Claude.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish; event_start; event_end
- **Links:** [Devpost](https://devpost.com/software/arigami-web-accessibility) | [GitHub](https://github.com/yassinabdelal-ipynb/access)

### Eve: event finances handled  (Cal Hacks 13.0 (2026))

- **Prizes:** [Hyphenate] The Hyphenated Enterprise: Autonomous Systems for Finance [unknown]  (tier: sponsor_winner)
- **Pitch:** Permission-limited AI agent that processes hackathon travel claims, prizes, tax forms and sponsor-portal paperwork, leaving payment release to a human controller.
- **Problem / user:** Hackathon organizers lack tooling for reimbursements and prize payouts, causing months-long delays and missed tax-form requirements for winners. / hackathon and event organizers
- **Domain / idea type:** fintech_finance + ai_agents_infra / automation_or_agent
- **Platforms / hardware / AI:** web / False / llm_chat; agent_or_tool_use; vision
- **Stack:** langs TypeScript; Python; frontend Next.js; React; Tailwind CSS; shadcn/ui; backend Next.js server actions; Drizzle; Better Auth; Vercel Workflow; db PostgreSQL (PlanetScale); hosting Vercel
- **Tech/APIs:** Claude (Anthropic SDK, computer use) (ai_model, core); Vercel AI SDK (framework, supporting); E2B desktop sandbox (cloud, core); Vercel Workflow (cloud, supporting); PlanetScale Postgres (database, core); Better Auth (auth, supporting); Next.js (framework, supporting)
- **Sponsor APIs:**  | fit: Targeted the Hyphenate autonomous-finance challenge with an agent that prepares payouts, tax withholding and ledger entries under role-limited permissions.
- **Repo:** public, commits 184 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 6, writeup long, impact claims True (Reports catching all 40 planted problems in a seeded 300-person event with 160 claims and 25 prizes.)
- **Notes:** Claude computer use on an E2B desktop fills university finance portals but stops before Submit; amounts and tax math are deterministic code; tested on seeded event with 40 planted problems, all caught; money movement simulated.
- **Team size:** 3 | **Confidence:** high | unverified: ui_polish; event_start; event_end; sponsor_apis_used; team_size
- **Links:** [Devpost](https://devpost.com/software/eve-event-finances-handled) | [GitHub](https://github.com/uijincho/eve)

### FortWatch  (Cal Hacks 13.0 (2026))

- **Prizes:** Cal Hacks Best Hardware Hack [unknown]  (tier: track_winner)
- **Pitch:** Low-cost ESP32-S3 wristband that classifies nearby sounds on-device and shows and vibrates alerts for deaf users, with a live event dashboard.
- **Problem / user:** Deaf people lack an affordable alternative to smartwatches for noticing important sounds like doorbells and car horns when out alone. / deaf and hard-of-hearing people
- **Domain / idea type:** accessibility + health_wellness / hardware_gadget
- **Platforms / hardware / AI:** hardware; web / True / predictive_ml
- **Stack:** langs C++; Python; TypeScript; frontend Arduino GFX; backend Node.js; SpacetimeDB; db SpacetimeDB; hosting Mana
- **Tech/APIs:** ESP32-S3 (Waveshare touch LCD) (hardware_part, core); YAMNet / TensorFlow (ai_model, core); ESC-50 dataset (data_source, supporting); SpacetimeDB (database, supporting); Mana (cloud, supporting); Claude Code (ai_model, supporting); OpenSCAD 3D case (hardware_part, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 67 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video True, live not_checked, screenshots 6, writeup long, impact claims True (States Claude Code wrote over 85% of the code and parts could cost as little as $10.)
- **Notes:** YAMNet-based classifier runs on the ESP32-S3 twice a second with audio never leaving the device; 10 sound classes tuned on ESC-50; urgency-coded vibration; SpacetimeDB dashboard on Mana; writeup says Claude Code wrote over 85% of code.
- **Team size:** 4 | **Confidence:** high | unverified: ui_polish; event_start; event_end
- **Links:** [Devpost](https://devpost.com/software/fortwatch) | [GitHub](http://github.com/joaquinGiorgis/calhack/)

### half full  (Cal Hacks 13.0 (2026))

- **Prizes:** Winner Cal Hacks Third Overall [3rd]  (tier: overall_top3)
- **Pitch:** Mobile-first PWA delivering a small daily edition of hopeful news with AI illustrations, narration, source receipts and a reaction jar.
- **Problem / user:** Doom-framed news and chopped-up social clips overwhelm young people, who stop following current events. / Gen Z news readers
- **Domain / idea type:** creative_media + social_community / twist_on_known_app
- **Platforms / hardware / AI:** web / False / llm_chat; rag_or_search; generative_media; speech_or_voice
- **Stack:** langs TypeScript; frontend Next.js; React; Motion; GSAP; PWA; backend Node.js; Apify Actor; db Firestore; hosting Vercel
- **Tech/APIs:** Anthropic Claude (ai_model, core, sponsor); Apify (data_source, core, sponsor); Recraft (ai_model, core); Cartesia (ai_model, core, sponsor); Firebase Auth and Firestore (auth, supporting); Runway (ai_model, supporting); Vercel (cloud, supporting); Next.js (framework, core)
- **Sponsor APIs:** Anthropic Claude; Apify; Cartesia
- **Repo:** public, commits 50 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video None, live not_checked, screenshots 10, writeup long, impact claims False
- **Notes:** Custom Apify Actor gathers evidence per story and the pipeline can reject under-supported stories; finite 3-5 story edition ends with a 'caught up' screen, plus crossword and illustrated reactions.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates
- **Links:** [Devpost](https://devpost.com/software/half-full) | [GitHub](https://github.com/rainazab/half-full)

### muselet  (Cal Hacks 13.0 (2026))

- **Prizes:** Cal Hacks Best Solo Hack [unknown]  (tier: track_winner)
- **Pitch:** Voice-triggered Mac agent that runs entirely on Apple Silicon, using a fast fine-tuned router and a local planner to click, type and verify outcomes.
- **Problem / user:** Cloud computer-use agents are slow and send the whole screen off the machine, a privacy and cost problem. / Mac power users and people who find mouse and keyboard hard to use
- **Domain / idea type:** ai_agents_infra + accessibility / automation_or_agent
- **Platforms / hardware / AI:** desktop / False / llm_chat; agent_or_tool_use; speech_or_voice; vision
- **Stack:** langs Swift; Python; frontend SwiftUI; backend Python; WebSocket; db ; hosting local Apple Silicon
- **Tech/APIs:** Qwen3.5-4B + LoRA (MLX) (ai_model, core); Parakeet TDT v2 / FluidAudio (ai_model, core); Tinker (training) (cloud, supporting); macOS Accessibility API (framework, core); eyes-4b vision model (ai_model, supporting); SwiftUI (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 481 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video True, live none, screenshots 5, writeup long, impact claims True (Reports 94.5% router accuracy, ~60 ms median latency, under $150 training cost and zoom grounding gain from 36.0% to 63.5%.)
- **Notes:** Router is Qwen3.5-4B with a self-trained LoRA scoring 43 actions in one pass (reports ~60 ms, 94.5% on route_v2); local planner, speech and OCR; ghost cursor shows intent; risky actions need spoken confirmation.
- **Team size:** 1 | **Confidence:** high | unverified: ui_polish; event_start; event_end
- **Links:** [Devpost](https://devpost.com/software/museles) | [GitHub](http://github.com/ardahk/muselet)

### Orbit Health  (Cal Hacks 13.0 (2026))

- **Prizes:** Cal Hacks Best Planet-First Social Impact Hack [unknown]  (tier: track_winner)
- **Pitch:** Village pod with camera, mic and pulse oximeter runs a nurse-style voice triage, then a satellite-aware planner ships medicines to rural Zambian clinics before roads flood.
- **Problem / user:** Rural Zambian villages cannot signal what medicine they need and stock does not reach clinics before rainy-season road closures. / rural villagers in Zambia, clinic staff, health logistics planners
- **Domain / idea type:** health_wellness + sustainability_climate / data_or_analytics
- **Platforms / hardware / AI:** web; hardware / True / llm_chat; speech_or_voice; vision; predictive_ml
- **Stack:** langs TypeScript; Python; frontend Next.js 15; backend SpacetimeDB reducers; Next.js API routes; TensorFlow; db SpacetimeDB; hosting local laptop
- **Tech/APIs:** SpacetimeDB (database, core, sponsor); Grok Voice (xAI) (ai_model, core); Jev (TypeSafe) (ai_model, core); Claude (ai_model, supporting, sponsor); NASA and Copernicus satellite data (data_source, core); OpenStreetMap / OSRM (maps_geo, core); Seeed XIAO nRF52840 with MAX30101 and Grove Vision AI V2 (hardware_part, core); HumBug mosquito models (ai_model, supporting)
- **Sponsor APIs:** SpacetimeDB; Claude | fit: Planet-First track win; the only sponsor mentions are SpacetimeDB as the full backend and Claude for wording and second-opinion camera checks.
- **Repo:** public, commits 86 (before/in/after event: None/None/None), README solid
- **Demo/writeup:** video None, live none, screenshots 3, writeup long, impact claims True (Cites Zambia malaria cases and clinic stockout statistics, and simulated planner savings of 833 to 83 movements and 112,849 km.)
- **Notes:** Solo build; maps 23,206 villages from satellite roof counts, uses keyless satellite data, SpacetimeDB reducers as the whole backend, firmware on real boards, mosquito wingbeat classifier.
- **Team size:** 1 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates
- **Links:** [Devpost](https://devpost.com/software/orbit-health) | [GitHub](https://github.com/philiprmocanu-cell/triage-pod)

### Rouge - Sees Your Screen and Points the Way  (Cal Hacks 13.0 (2026))

- **Prizes:** Cal Hacks Hacker's Choice [unknown]  (tier: track_winner)
- **Pitch:** Windows desktop assistant drawn as an animated ribbon that points at on-screen controls, performs browser tasks, explains errors and answers from local documents.
- **Problem / user:** Voice assistants talk about your work rather than working with you on the screen you are looking at. / Windows desktop users
- **Domain / idea type:** productivity_workplace + ai_agents_infra / automation_or_agent
- **Platforms / hardware / AI:** desktop / False / llm_chat; agent_or_tool_use; rag_or_search; vision; speech_or_voice
- **Stack:** langs JavaScript; C#; PowerShell; frontend Electron; WebGL; Canvas; backend Node.js; db ; hosting 
- **Tech/APIs:** Anthropic Claude (Haiku/Sonnet/Opus) (ai_model, core); Windows UI Automation (C#/PowerShell) (framework, core); Electron (framework, core); Qwen3.5 (local) (ai_model, supporting); BM25 local search (other, supporting); Serper API (data_source, supporting); WebGL (framework, supporting)
- **Sponsor APIs:** 
- **Repo:** public, commits 65 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video True, live none, screenshots 3, writeup long, impact claims True (Reports idle CPU drop from about 34% to 7% of a core and window lookups 35x faster (71ms to 2ms).)
- **Notes:** Reads Windows UI Automation controls instead of screenshots; routes between Haiku, Sonnet and Opus per request; user-supplied API keys encrypted locally; reports idle CPU cut from about 34% to 7%.
- **Team size:** 3 | **Confidence:** high | unverified: ui_polish; event_start; event_end
- **Links:** [Devpost](https://devpost.com/software/rouge-cm8jig) | [GitHub](https://github.com/RithikGobinath/rouge)

### Silent Voice  (Cal Hacks 13.0 (2026))

- **Prizes:** Cal Hacks Second Overall [2nd]; [Cartesia] Best Use of Cartesia [unknown]  (tier: overall_top3)
- **Pitch:** Reads silent mouthing via camera lip reading and face EMG, uses Claude to predict dialogue, and speaks in the user's cloned voice over a live phone call.
- **Problem / user:** People who lose their voice box after laryngectomy cannot speak in their own voice; existing devices give robotic sound. / laryngectomy patients and their families
- **Domain / idea type:** accessibility + health_wellness / hardware_gadget
- **Platforms / hardware / AI:** hardware; desktop / True / llm_chat; speech_or_voice; vision; predictive_ml
- **Stack:** langs Python; frontend dashboard; backend PyTorch; MediaPipe; KenLM; ZeroMQ; Twilio; db ; hosting local laptop with RTX 5060
- **Tech/APIs:** Cartesia Sonic and Ink (ai_model, core, sponsor); Claude (Haiku and Opus) (ai_model, core, sponsor); Auto-AVSR (ai_model, core); EMG sensor pads with Arduino (hardware_part, core); Twilio (telecom, core); PyTorch (framework, supporting); MediaPipe (framework, supporting)
- **Sponsor APIs:** Cartesia; Claude | fit: Used Cartesia Sonic for streaming cloned-voice output with emotion and Cartesia Ink for caller transcription over a live phone call.
- **Repo:** public, commits 129 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video None, live none, screenshots 6, writeup long, impact claims True (Cites ~190,000 yearly voice-box cancer cases and measured error rates, latency and accuracy figures from its own tests.)
- **Notes:** Fuses a retrained lip reader, a custom EMG model on four face pads, and Claude next-word prediction every 100 ms; claims 9.8% word error on a new session and ~0.7 s latency; runs on one laptop with Twilio call demo.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates
- **Links:** [Devpost](https://devpost.com/software/silent-voice-s1f74p) | [GitHub](https://github.com/thaimtl/Silent-Voice)

### Sophi - The Physical Augmentation Walker  (Cal Hacks 13.0 (2026))

- **Prizes:** Winner Cal Hacks First Overall [1st]  (tier: overall_top3)
- **Pitch:** Walker with a voice agent, distance-sensing haptics, robotic arms, lift and GPS, plus a caregiver companion app.
- **Problem / user:** Falls and mobility limits threaten independence of elderly and disabled people, and caregivers lack ways to check in. / elderly and mobility-impaired people, blind users, caregivers
- **Domain / idea type:** accessibility + health_wellness / hardware_gadget
- **Platforms / hardware / AI:** hardware; web; mobile_cross / True / llm_chat; agent_or_tool_use; speech_or_voice
- **Stack:** langs TypeScript; Python; C++; frontend Next.js; React; Leaflet.js; backend Node.js; Zod; PlatformIO; db PostgreSQL; Supabase; SpacetimeDB; hosting Render
- **Tech/APIs:** Claude (Anthropic) (ai_model, core, sponsor); Cartesia (ai_model, core, sponsor); SpacetimeDB (database, core, sponsor); Raspberry Pi 5 and ESP32 modules (hardware_part, core); SO-101 robot arms (hardware_part, core); Supabase (database, supporting); OpenStreetMap / Leaflet (maps_geo, supporting); Stripe (payments, token); Piper TTS (ai_model, unclear)
- **Sponsor APIs:** Claude; Cartesia; SpacetimeDB
- **Repo:** public, commits 331 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video None, live not_checked, screenshots 14, writeup long, impact claims True (Cites 340 million blind or low-vision people and 1.7 billion people with mobility restrictions as the addressable population.)
- **Notes:** Raspberry Pi 5 plus three ESP32s, four soldered boards and 30+ 3D-printed parts; SO-101 arms driven by a custom iPhone-based harness after other control options proved unreliable.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates
- **Links:** [Devpost](https://devpost.com/software/sophi) | [GitHub](https://github.com/mzhao1599/sophi)

### Standard Response  (Cal Hacks 13.0 (2026))

- **Prizes:** Cal Hacks Best People-First Social Impact Hack [unknown]; [Microsoft] Built for the Real World (1st), Customer Impact Award (2nd) [unknown]; [Convex] Best use of Convex [unknown]; [Apify] Best Use of Apify [unknown]; [Moss] Best Use of Moss [unknown]; [Anthropic] Claude for Public Benefit [unknown]  (tier: track_winner)
- **Pitch:** Voice agent phones every home in a wildfire evacuation zone, triages who cannot leave, and dispatches accessible vehicles or neighbors, promising help only once a driver accepts.
- **Problem / user:** Disabled residents were left behind in the Eaton Fire because no one had staff to call everyone and coordinate available vans. / paratransit agencies, dispatchers, disabled and elderly residents, neighbors
- **Domain / idea type:** safety_security + accessibility / automation_or_agent
- **Platforms / hardware / AI:** web; bot_or_chat / False / llm_chat; agent_or_tool_use; speech_or_voice; rag_or_search; predictive_ml
- **Stack:** langs TypeScript; Python; frontend Next.js; React; Tailwind CSS; backend Node.js; Convex; OR-Tools; SimPy; OSMnx; Twilio; WebSockets; db Convex; hosting Fly.io; DigitalOcean; Vercel
- **Tech/APIs:** Claude (Haiku, Sonnet, Opus) (ai_model, core, sponsor); Cartesia Ink and Sonic (ai_model, core, sponsor); Moss (data_source, core, sponsor); Convex (database, core, sponsor); Apify Actor (data_source, core, sponsor); Twilio (telecom, core); Mana (other, supporting, sponsor); OR-Tools and custom ALNS solver (other, core); OSMnx / OpenStreetMap (maps_geo, core); DigitalOcean (cloud, supporting); Fly.io (cloud, supporting)
- **Sponsor APIs:** Claude; Cartesia; Moss; Convex; Apify; Mana | fit: Social impact track win; writeup has a per-sponsor section describing Claude, Cartesia, Moss, Convex, Apify and Mana each doing a specific job.
- **Repo:** public, commits 300 (before/in/after event: None/None/None), README detailed
- **Demo/writeup:** video None, live not_checked, screenshots 16, writeup long, impact claims True (Simulation results on Eaton Fire night (641 of 662 on time vs 39), voice-exam scores, 0.86 s median turn latency, and firefighter quotes.)
- **Notes:** Eaton Fire night simulation over real records (claims 641 of 662 households out on time vs 39 modeled today); promise guard enforced in code; custom Apify Actor; Mana-written tests; team visited fire stations.
- **Team size:** 4 | **Confidence:** medium | unverified: has_demo_video; ui_polish; is_sponsor flags; event dates
- **Links:** [Devpost](https://devpost.com/software/standard-response) | [GitHub](https://github.com/Imhaohao/calhacks)
